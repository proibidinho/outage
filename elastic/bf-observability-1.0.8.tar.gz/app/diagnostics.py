"""Interpretação determinística do diagnóstico do Solar (usada pelo painel e pelo validate_splunk)."""
from __future__ import annotations


def diagnose_solar(access_rows: list[dict] | None, field_rows: list[dict] | None) -> dict:
    """Retorna {"conclusion": str, "details": [str], "sourcetypes": [...]} a partir das duas buscas fixas."""
    details: list[str] = []
    sts = [{"sourcetype": r.get("sourcetype"), "eventos": r.get("eventos"), "ultimo": r.get("ultimo")}
           for r in (access_rows or [])]
    if access_rows is None:
        return {"conclusion": "Diagnóstico não executado (falha na busca de acesso ao índice).", "details": [], "sourcetypes": []}
    if not access_rows:
        return {"conclusion": "O usuário do token NÃO enxerga dados em index=solar nos últimos 7 dias: provável falta de "
                              "permissão no índice para o papel (role) do token. O Splunk retorna vazio, sem erro. "
                              "Solicite ao administrador do Splunk acesso de leitura ao index=solar para esse usuário.",
                "details": [], "sourcetypes": []}
    details.append("Sourcetypes visíveis em index=solar: " + ", ".join(f"{s['sourcetype']} ({s['eventos']})" for s in sts))
    soql = [s for s in sts if str(s["sourcetype"]).lower().startswith("queries") and str(s["sourcetype"]).lower().endswith("soql")]
    f = (field_rows or [{}])[0] if field_rows else {}
    ev = int(float(f.get("eventos") or 0))
    if not soql or ev == 0:
        return {"conclusion": "O índice é acessível, mas não há eventos com sourcetype \"queries*SOQL\" nas últimas 24 h. "
                              "Verifique o nome correto do sourcetype na lista acima e ajuste queries/solar_business_metrics.spl.",
                "details": details, "sourcetypes": sts}
    details.append(f"queries*SOQL (24 h): {ev} eventos · com start: {f.get('com_start')} · com query: {f.get('com_query')} · "
                   f"com value: {f.get('com_value')} · queries distintas: {f.get('queries_distintas')} · "
                   f"{f.get('primeiro')} → {f.get('ultimo')}")
    missing = [k for k in ("start", "query", "value") if str(f.get(f"com_{k}", "0")) in ("0", "0.0", "")]
    if missing:
        return {"conclusion": "Há eventos, mas sem o(s) campo(s) " + ", ".join(missing) + ": a consulta Solar precisa usar "
                              "os nomes reais dos campos (ou a extração de campos não está visível no contexto de app do token; "
                              "teste BF_SPLUNK_APP).", "details": details, "sourcetypes": sts}
    return {"conclusion": "Há eventos com start, query e value nas últimas 24 h, mas nenhum dentro das janelas da campanha: "
                          "confira se o campo start cai no período do lookup (fuso/formato de start) e se a coleta Solar já "
                          "estava ativa na campanha.", "details": details, "sourcetypes": sts}
