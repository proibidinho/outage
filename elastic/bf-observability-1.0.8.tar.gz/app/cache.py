"""Cache local em SQLite (último resultado válido por campanha/fonte + histórico de coletas)."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS source_cache (
  campaign TEXT NOT NULL, source TEXT NOT NULL, collected_at REAL NOT NULL,
  rows INTEGER, payload TEXT NOT NULL, PRIMARY KEY (campaign, source));
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, collected_at REAL NOT NULL, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT, campaign TEXT, source TEXT, started_at REAL, finished_at REAL,
  ok INTEGER, rows INTEGER, duration_ms INTEGER, error_kind TEXT, error TEXT);
CREATE INDEX IF NOT EXISTS ix_coll ON collections (source, started_at);
"""


class Cache:
    def __init__(self, path: str):
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._lock = threading.Lock()
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._conn.commit()

    def put_source(self, campaign: str, source: str, data: dict) -> None:
        with self._lock:
            self._conn.execute(
                "REPLACE INTO source_cache VALUES (?,?,?,?,?)",
                (campaign, source, time.time(), data.get("rows", 0), json.dumps(data, ensure_ascii=False)),
            )
            self._conn.commit()

    def get_source(self, campaign: str, source: str) -> tuple[float, dict] | None:
        with self._lock:
            r = self._conn.execute(
                "SELECT collected_at, payload FROM source_cache WHERE campaign=? AND source=?", (campaign, source)
            ).fetchone()
        return (r[0], json.loads(r[1])) if r else None

    def put_kv(self, k: str, data) -> None:
        with self._lock:
            self._conn.execute("REPLACE INTO kv VALUES (?,?,?)", (k, time.time(), json.dumps(data, ensure_ascii=False)))
            self._conn.commit()

    def get_kv(self, k: str):
        with self._lock:
            r = self._conn.execute("SELECT collected_at, payload FROM kv WHERE k=?", (k,)).fetchone()
        return (r[0], json.loads(r[1])) if r else None

    def log_collection(self, **c) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO collections (campaign, source, started_at, finished_at, ok, rows, duration_ms, error_kind, error)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (c.get("campaign"), c["source"], c["started_at"], c["finished_at"], int(c["ok"]), c.get("rows"),
                 c.get("duration_ms"), c.get("error_kind"), c.get("error")),
            )
            self._conn.execute("DELETE FROM collections WHERE id NOT IN (SELECT id FROM collections ORDER BY id DESC LIMIT 2000)")
            self._conn.commit()

    def collection_stats(self, since_s: float = 86400) -> dict:
        with self._lock:
            rows = self._conn.execute(
                "SELECT source, COUNT(*), SUM(ok), AVG(duration_ms), MAX(CASE WHEN ok=1 THEN finished_at END)"
                " FROM collections WHERE started_at >= ? GROUP BY source", (time.time() - since_s,)
            ).fetchall()
        return {
            r[0]: {"attempts": r[1], "success": r[2] or 0,
                   "success_rate": round((r[2] or 0) / r[1], 3) if r[1] else None,
                   "avg_duration_ms": int(r[3]) if r[3] is not None else None, "last_success": r[4]}
            for r in rows
        }
