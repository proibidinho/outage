#!/usr/bin/env bash
# Instala/atualiza o painel no servidor RHEL 9 a partir do pacote (imagem já compilada, sem internet).
# Uso (root):  ./install.sh [porta]        porta publicada no servidor; padrão 8765
set -euo pipefail
cd "$(dirname "$0")"
PORT="${1:-8765}"
VERSION="$(cat VERSION)"
ENV_DIR=/etc/bf-observability
ENV_FILE="$ENV_DIR/bf-observability.env"

[ "$(id -u)" -eq 0 ] || { echo "[ERRO] Execute como root (sudo ./install.sh)."; exit 1; }
command -v podman >/dev/null || { echo "[ERRO] Podman não encontrado: dnf install -y podman"; exit 1; }

echo "== Carregando imagem bf-observability:$VERSION"
podman load -i bf-observability-image.tar.gz

install -d -m 750 "$ENV_DIR"
if [ ! -f "$ENV_FILE" ]; then
  install -m 600 bf-observability.env "$ENV_FILE"
  sed -i "s|^BF_PUBLIC_URL=@AUTO@|BF_PUBLIC_URL=http://$(hostname -f):$PORT|" "$ENV_FILE"
  echo "== Criado $ENV_FILE (Splunk, proxy e URL já preenchidos)."
  grep -Eq '^COCKPIT_SOURCE_SPLUNK_TOKEN=.+' "$ENV_FILE" \
    || echo "   Falta só o token:  vi $ENV_FILE   → COCKPIT_SOURCE_SPLUNK_TOKEN=..."
else
  echo "== Mantido $ENV_FILE existente (não sobrescrito)."
fi

sed -e "s/@VERSION@/$VERSION/" -e "s/@PORT@/$PORT/" bf-observability.container > /etc/containers/systemd/bf-observability.container
systemctl daemon-reload

if grep -Eq '^COCKPIT_SOURCE_SPLUNK_TOKEN=.+' "$ENV_FILE"; then
  systemctl restart bf-observability
  sleep 5
  systemctl --no-pager --lines=0 status bf-observability || true
  echo "== Painel: http://$(hostname -f):$PORT"
else
  echo "== Depois de preencher o token:  systemctl start bf-observability"
fi
if command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; then
  firewall-cmd --query-port="$PORT/tcp" >/dev/null || echo "== Libere a porta: firewall-cmd --permanent --add-port=$PORT/tcp && firewall-cmd --reload"
fi
