# Black Friday Business Observability: instalação no servidor (RHEL 9, container)

Este pacote traz o painel já compilado em uma imagem **Red Hat UBI 9** (Python 3.12). O servidor **não precisa de internet** para instalar, apenas de acesso ao Splunk.

## Conteúdo

| Arquivo | Para que serve |
|---|---|
| `bf-observability-image.tar.gz` | Imagem do container (~100 MB) |
| `install.sh` | Instala ou atualiza a imagem e o serviço |
| `bf-observability.container` | Definição do serviço (Podman Quadlet/systemd) |
| `bf-observability.env` | Configuração **já preenchida** (Splunk, proxy, modo servidor); falta só o token |
| `VERSION` | Versão do pacote |

## Pré-requisitos

- RHEL 9.2 ou superior com Podman (`dnf install -y podman`)
- Saída do servidor para o Splunk (`<host>.splunkcloud.com:8089`), direta ou via proxy corporativo
- Um token do Splunk com leitura nos índices `icn` e `solar` e no lookup `comparativoDatasEspeciais.csv`

## Instalação (como root)

```bash
tar -xzf bf-observability-*-ubi9.tar.gz
cd bf-observability-*-ubi9
./install.sh                         # opcional: ./install.sh 8080 para usar outra porta
vi /etc/bf-observability/bf-observability.env     # preencha SOMENTE o token: COCKPIT_SOURCE_SPLUNK_TOKEN=...
systemctl start bf-observability
```

O painel fica em `http://<servidor>:8765`. O serviço inicia junto com o servidor e reinicia sozinho se cair. Libere a porta no firewall para a rede interna:

```bash
firewall-cmd --permanent --add-port=8765/tcp && firewall-cmd --reload
```

## Configuração (`/etc/bf-observability/bf-observability.env`)

O pacote já traz preenchidos: Splunk `https://claro.splunkcloud.com:8089`, proxy `http://10.29.177.37:8080`, `NO_PROXY=localhost,127.0.0.1` e modo `server`. O `install.sh` completa `BF_PUBLIC_URL` com o nome do servidor (`http://<hostname -f>:<porta>`). **Só o token é preenchido por quem instala**: ele nunca vai no pacote. Ajuste qualquer valor abaixo se o servidor usar outro proxy ou nome.

| Variável | Valor |
|---|---|
| `COCKPIT_SOURCE_SPLUNK_BASE_URL` | ex.: `https://claro.splunkcloud.com:8089` |
| `COCKPIT_SOURCE_SPLUNK_TOKEN` | token do Splunk (o arquivo fica com permissão 600, só root lê) |
| `BF_MODE` | `server` (já preenchido) |
| `BF_PUBLIC_URL` | URL que o time usa, ex.: `http://bfpainel.claro.corp:8765` (opcional; vai no resumo do WhatsApp/Teams) |
| `HTTPS_PROXY` | proxy corporativo, se a saída para o Splunk passar por um (ex.: `http://10.29.177.37:8080`) |
| `NO_PROXY` | com proxy, use `localhost,127.0.0.1` (mantém a verificação de saúde interna fora do proxy) |

Após alterar: `systemctl restart bf-observability`.

**Timeout com o Splunk:** os `export http_proxy=...` do terminal **não** valem para o serviço; o proxy precisa estar neste arquivo. Para descobrir onde a conexão trava: `podman exec bf-observability python -m scripts.diag_rede`.

**Proxy com inspeção TLS (CA corporativa):** descomente a linha `Volume=` indicada em `/etc/containers/systemd/bf-observability.container`, defina `BF_SPLUNK_CA_BUNDLE=/etc/pki/ca-corporativa.crt` no `.env` e rode `systemctl daemon-reload && systemctl restart bf-observability`.

## Operação

```bash
systemctl status bf-observability                 # estado
journalctl -u bf-observability -f                 # logs
podman healthcheck run bf-observability           # verificação de saúde
podman exec bf-observability python -m scripts.validate_splunk   # diagnóstico da integração com o Splunk
podman exec bf-observability python -m scripts.diag_rede         # timeout/conexão: testa proxy, DNS, TCP, TLS e HTTP
```

**Atualizar para uma nova versão:** extraia o novo pacote e rode `./install.sh` de novo. A configuração em `/etc/bf-observability/` e o cache são mantidos.

**Remover:** `systemctl stop bf-observability && rm /etc/containers/systemd/bf-observability.container && systemctl daemon-reload`.

## Observações

- O painel **não tem login**: mantenha o acesso restrito à rede interna.
- Roda como usuário sem privilégios (UID 1001), sem gravar nada fora dos volumes `bf-observability-data` (cache) e `bf-observability-logs`.
- Consulta o Splunk **somente para leitura**, a cada 5 minutos, com uma busca por fonte, compartilhada entre todos os usuários.
