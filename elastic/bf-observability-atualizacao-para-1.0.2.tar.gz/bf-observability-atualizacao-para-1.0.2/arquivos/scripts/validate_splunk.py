"""Validação técnica das consultas no ambiente real (Etapa 2 da especificação).

    python -m scripts.validate_splunk [--campaign black_friday]

Executa (somente leitura): lookup, consulta ICN original, variante horária,
consulta Solar e o perfil de QUANTIDADE. Gera docs/validacao_splunk_<data>.md com
ESTRUTURA e ESTATÍSTICAS agregadas (sem despejar dados brutos, sem credenciais).
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo

from app import normalize as N
from app.config import ROOT, load_catalog, load_settings
from app.queries import load_query, parse_campaigns, pick_default_campaign, render, render_lookup
from app.splunk_client import SplunkClient, SplunkError


def fields(rows):
    c = Counter()
    for r in rows:
        c.update(r.keys())
    return ", ".join(f"{k}" for k, _ in c.most_common())


async def run(campaign: str | None) -> str:
    s = load_settings()
    if s.missing:
        return "ERRO: variáveis ausentes no .env: " + ", ".join(s.missing)
    tz = ZoneInfo(s.timezone)
    cat = load_catalog(s.catalog_path)
    cl = SplunkClient(s)
    out = [f"# Validação Splunk — {datetime.now(tz):%d/%m/%Y %H:%M}", ""]
    try:
        info = await cl.ping()
        out.append(f"- Conectividade/autenticação: OK (versão {info.get('version')}, {info['latency_ms']} ms)")
    except SplunkError as e:
        out.append(f"- Conectividade/autenticação: FALHA ({e.kind}: {e})")
        return "\n".join(out)

    off = datetime.now(tz).strftime("%z")
    lk = await cl.search(render_lookup(load_query(s.queries_dir, "lookup"), off), label="lookup")
    camps = parse_campaigns(lk.rows, tz, cat.get("campaign_labels", {}))
    out += ["", "## Lookup comparativoDatasEspeciais.csv", f"- Linhas: {len(lk.rows)} · campos: {fields(lk.rows)}"]
    for c in camps:
        out.append(f"- `{c.id}` → anos {c.years} · utilizável: {c.usable}")
        for w in c.windows:
            out.append(f"  - inicio=`{w.raw_start}` fim=`{w.raw_end}` → {w.start} … {w.end}")
        for i in c.issues:
            out.append(f"  - ⚠ {i}")
    cid = campaign or pick_default_campaign(camps, s.default_campaign, datetime.now(tz))
    camp = next((c for c in camps if c.id == cid and c.usable), None)
    if not camp:
        out.append(f"\nERRO: campanha `{cid}` sem janela válida. Nenhuma busca de dados executada.")
        return "\n".join(out)
    allowed = {c.id for c in camps if c.usable}
    out += ["", f"## Campanha validada: `{camp.id}`"]

    async def q(name):
        try:
            return await cl.search(render(load_query(s.queries_dir, name), camp.id, allowed, off), label=name)
        except SplunkError as e:
            out.append(f"- {name}: FALHA ({e.kind}: {e})")
            return None

    orig, hourly, solar, prof, solar_h = await asyncio.gather(q("icn_original"), q("icn_hourly"), q("solar"), q("icn_profile"),
                                                             q("solar_hourly"))
    if orig:
        out += ["", "## ICN — consulta original", f"- {len(orig.rows)} linhas em {orig.duration_ms} ms · campos: {fields(orig.rows)}",
                f"- Amostra de `_time`: `{orig.rows[0].get('_time') if orig.rows else '-'}` · `time` (ano do bloco): "
                f"{sorted({r.get('time') for r in orig.rows})}"]
    if hourly:
        n = N.normalize_icn(hourly.rows, camp, tz)
        out += ["", "## ICN — variante horária", f"- {len(hourly.rows)} linhas em {hourly.duration_ms} ms · campos: {fields(hourly.rows)}",
                f"- Sourcetypes: {n['keys']}", f"- Pontos normalizados: {len(n['points'])} · erros: {n['errors'] or 'nenhum'}"]
        miss = [i["match"] for i in cat["indicators"] if i["source"] == "icn" and i["match"] not in n["keys"]]
        out.append(f"- Sourcetypes do catálogo sem dados: {miss or 'nenhum'}")
        if orig:
            tot = N.icn_daily_totals(orig.rows)
            hr: dict = {}
            for p in n["points"]:
                hr.setdefault(p["key"], {}).setdefault(str(p["year"]), 0.0)
                hr[p["key"]][str(p["year"])] += p["value"]
            out.append("- Reconciliação (original × horária, por sourcetype/ano):")
            for k in sorted(tot):
                for y in sorted(tot[k]):
                    a, b = tot[k][y], hr.get(k, {}).get(y)
                    out.append(f"  - {k} {y}: {a:.0f} × {b if b is None else round(b)}")
    if prof:
        out += ["", "## ICN — perfil de QUANTIDADE (incremental × acumulado)",
                "| sourcetype | eventos | DT_MOVIMENTO distintos | mín | máx | média | quedas sequenciais |", "|---|---|---|---|---|---|---|"]
        for r in prof.rows:
            out.append(f"| {r.get('sourcetype')} | {r.get('eventos')} | {r.get('dt_movimento_distintos')} | {r.get('qtd_min')} | "
                       f"{r.get('qtd_max')} | {r.get('qtd_media')} | {r.get('quedas_sequenciais')} |")
        out.append("\nInterpretação: muitas quedas sequenciais e valores pequenos ⇒ QUANTIDADE incremental por evento "
                   "(soma é válida). Poucas quedas e valores crescentes ⇒ acumulado (soma gera dupla contagem).")
    if solar:
        out += ["", "## Solar — consulta original", f"- {len(solar.rows)} linhas em {solar.duration_ms} ms · campos: {fields(solar.rows)}",
                f"- Amostra de `start`: `{solar.rows[0].get('start') if solar.rows else '-'}`"]
    if solar_h:
        n = N.normalize_solar_hourly(solar_h.rows, camp, tz)
        out += ["", "## Solar — variante horária (usada pelo painel)",
                f"- {len(solar_h.rows)} linhas em {solar_h.duration_ms} ms · queries: {len(n['keys'])} · erros: {n['errors'] or 'nenhum'}", "",
                "| query | pontos | anos | mín | máx | dias monotônicos | sugestão |", "|---|---|---|---|---|---|---|"]
        for p in N.profile_solar(n):
            out.append(f"| `{p['key'][:60]}` | {p['points']} | {p['years']} | {p['min']} | {p['max']} | {p['monotonic_days']} | {p['hint']} |")
        out.append("\nDias monotônicos = dias em que o valor só cresce ao longo das medições: confirma agregação 'last' (acumulado do dia).")

    # ------------------------------------------------ diagnósticos fixos (sem $class$)
    async def fixed(name):
        try:
            return await cl.search(load_query(s.queries_dir, name), label=name)
        except SplunkError as e:
            out.append(f"- {name}: FALHA ({e.kind}: {e})")
            return None

    acc, flds, lag = await asyncio.gather(fixed("solar_index_access"), fixed("solar_fields"), fixed("icn_ingestion_lag"))
    from app.diagnostics import diagnose_solar
    d = diagnose_solar(acc.rows if acc else None, flds.rows if flds else None)
    out += ["", "## Diagnóstico Solar (sem filtro de campanha)", f"**Conclusão:** {d['conclusion']}"]
    out += [f"- {x}" for x in d["details"]]
    if lag is not None:
        out += ["", "## Atraso de ingestão ICN (últimas 4 horas)", "| sourcetype | último evento | atraso médio (min) | p95 (min) | máximo (min) |", "|---|---|---|---|---|"]
        out += [f"| {r.get('sourcetype')} | {r.get('ultimo_evento')} | {r.get('atraso_medio_min')} | {r.get('atraso_p95_min')} | "
                f"{r.get('atraso_max_min')} |" for r in lag.rows]
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--campaign")
    a = ap.parse_args()
    txt = asyncio.run(run(a.campaign))
    path = ROOT / "docs" / f"validacao_splunk_{datetime.now():%Y%m%d_%H%M}.md"
    path.write_text(txt, encoding="utf-8")
    print(txt)
    print(f"\nRelatório salvo em {path}")
    return 0 if not txt.startswith("ERRO") else 1


if __name__ == "__main__":
    sys.exit(main())
