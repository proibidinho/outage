"""Diagnóstico de rede até o Splunk, etapa por etapa, do jeito que a aplicação conecta.

    python -m scripts.diag_rede          (no servidor: .venv/bin/python -m scripts.diag_rede)
    podman exec bf-observability python -m scripts.diag_rede     (instalação em container)

Etapas: configuração → proxy do ambiente → DNS (IPv4/IPv6) → TCP por endereço → TLS → HTTP com token
(com e sem o proxy do ambiente). Somente leitura; o token nunca é exibido.
"""
from __future__ import annotations

import socket
import ssl
import sys
import time
from urllib.parse import urlparse

import certifi
import httpx

from app.config import load_settings
from app.splunk_client import _env_proxy

OK, FAIL, WARN = "[ok]  ", "[FALHA]", "[aviso]"


def t(start: float) -> str:
    return f"{(time.monotonic() - start) * 1000:.0f} ms"


def main() -> int:
    s = load_settings()
    print("== 1. Configuração")
    if s.missing:
        print(FAIL, "variáveis ausentes:", ", ".join(s.missing))
        return 1
    u = urlparse(s.splunk_base_url)
    host, port = u.hostname, u.port or (443 if u.scheme == "https" else 80)
    print(OK, f"Splunk: {u.scheme}://{host}:{port} · autenticação {s.splunk_auth_scheme} · token carregado (não exibido)")
    if s.splunk_ca_bundle:
        print(OK, f"CA personalizada: {s.splunk_ca_bundle}")

    print("\n== 2. Proxy do ambiente (usado automaticamente pela aplicação)")
    proxy = _env_proxy(s.splunk_base_url)
    print((WARN if proxy else OK), f"a aplicação conecta {'VIA PROXY ' + proxy if proxy else 'DIRETO (sem proxy)'}")

    print("\n== 3. DNS")
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror as e:
        print(FAIL, "não resolve:", e)
        return 1
    addrs = []
    for fam, _, _, _, sa in infos:
        if (fam, sa[0]) not in [(a[0], a[1][0]) for a in addrs]:
            addrs.append((fam, sa))
    for fam, sa in addrs:
        print(OK, ("IPv6 " if fam == socket.AF_INET6 else "IPv4 ") + sa[0], "(1º usado)" if (fam, sa) == addrs[0] else "")

    print("\n== 4. TCP + TLS por endereço (direto, timeout 10 s)")
    ctx = ssl.create_default_context(cafile=s.splunk_ca_bundle or certifi.where())
    tls_ok = False
    for fam, sa in addrs:
        label = sa[0]
        st = time.monotonic()
        try:
            raw = socket.create_connection(sa[:2], timeout=10)
        except OSError as e:
            print(FAIL, f"{label}: TCP falhou em {t(st)} ({type(e).__name__}: {e})")
            continue
        tcp = t(st)
        st = time.monotonic()
        try:
            with ctx.wrap_socket(raw, server_hostname=host) as tls:
                cert = tls.getpeercert()
                issuer = dict(x[0] for x in cert.get("issuer", ())).get("organizationName", "?")
                print(OK, f"{label}: TCP {tcp} · TLS {t(st)} · {tls.version()} · emissor do certificado: {issuer}")
                tls_ok = True
        except ssl.SSLCertVerificationError as e:
            print(FAIL, f"{label}: TCP {tcp} · certificado NÃO confiável ({e.verify_message}). "
                        "Provável inspeção TLS corporativa: configure BF_SPLUNK_CA_BUNDLE com a CA da empresa.")
        except (socket.timeout, TimeoutError):
            print(FAIL, f"{label}: TCP {tcp} · TLS TRAVOU após {t(st)}: o TCP abre mas o handshake não completa "
                        "(firewall/inspeção bloqueando ou problema de MTU).")
        except OSError as e:
            print(FAIL, f"{label}: TCP {tcp} · TLS falhou em {t(st)} ({type(e).__name__}: {e})")
        finally:
            raw.close()

    print("\n== 5. HTTP GET /services/server/info com o token (timeout 20 s)")
    verify = s.splunk_ca_bundle or True
    results = {}
    for name, trust in (("como a aplicação (respeita proxy do ambiente)", True), ("direto (ignora proxy do ambiente)", False)):
        if not trust and not proxy:
            continue
        st = time.monotonic()
        try:
            with httpx.Client(verify=verify, trust_env=trust, timeout=20) as c:
                r = c.get(f"{s.splunk_base_url}/services/server/info", params={"output_mode": "json"},
                          headers={"Authorization": f"{s.splunk_auth_scheme} {s.splunk_token}"})
            msg = {200: "OK", 401: "token inválido/expirado", 403: "sem permissão"}.get(r.status_code, "")
            print(OK if r.status_code == 200 else FAIL, f"{name}: HTTP {r.status_code} {msg} em {t(st)}")
            results[trust] = r.status_code
        except httpx.HTTPError as e:
            print(FAIL, f"{name}: {type(e).__name__} após {t(st)}")
            results[trust] = type(e).__name__

    print("\n== Conclusão")
    if results.get(True) == 200:
        print("A conexão da aplicação funciona agora. Reinicie o serviço e clique em Atualizar.")
    elif proxy and results.get(False) == 200:
        print(f"O proxy do ambiente ({proxy}) bloqueia/atrasa o Splunk, mas a conexão direta funciona.\n"
              f"Solução: adicione {host} ao NO_PROXY do serviço, ex.: NO_PROXY={host} no .env/arquivo de ambiente "
              "e reinicie.")
    elif not tls_ok:
        print("O TLS não completa de nenhum endereço: libere a porta 8089 com inspeção TLS desativada para o host, "
              "verifique MTU, ou configure a CA corporativa (BF_SPLUNK_CA_BUNDLE).")
    elif addrs and addrs[0][0] == socket.AF_INET6 and any(f == socket.AF_INET for f, _ in addrs):
        print("O primeiro endereço é IPv6: se só o IPv4 funciona acima, desative IPv6 para este host ou priorize IPv4 "
              "(/etc/gai.conf: precedence ::ffff:0:0/96 100).")
    else:
        print("Rede e TLS ok, mas o HTTP falha: verifique allowlist de IP do Splunk Cloud para a API (porta 8089) "
              "e o token.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
