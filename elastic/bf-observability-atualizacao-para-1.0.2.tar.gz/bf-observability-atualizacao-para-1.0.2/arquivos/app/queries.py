"""Consultas SPL versionadas em arquivos + tratamento seguro do parâmetro $class$.

O valor da campanha só é aceito se (1) existir no lookup comparativoDatasEspeciais.csv
com status=1 e janela válida e (2) obedecer a um padrão restrito de caracteres.
Isso impede injeção de SPL e buscas sem restrição temporal.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

CAMPAIGN_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_\-. ]{0,63}$")

QUERY_FILES = {
    "lookup": "campaigns_lookup.spl",
    "icn_original": "icn_business_metrics.spl",
    "icn_hourly": "icn_business_metrics_hourly.spl",
    "solar": "solar_business_metrics.spl",
    "solar_hourly": "solar_business_metrics_hourly.spl",
    "icn_profile": "validation/icn_quantidade_profile.spl",
    "solar_index_access": "validation/solar_index_access.spl",
    "solar_fields": "validation/solar_fields.spl",
    "icn_ingestion_lag": "validation/icn_ingestion_lag.spl",
}


class InvalidCampaign(ValueError):
    pass


def load_query(queries_dir: str, name: str) -> str:
    return (Path(queries_dir) / QUERY_FILES[name]).read_text(encoding="utf-8")


OFFSET_RE = re.compile(r"^[+-]\d{4}$")
_BLOCK_RE = re.compile(r'\|\s*eval block = "\(earliest="\.inicio\." latest="\.fim\."\)"')


def _epoch_expr(field: str, offset: str) -> str:
    # epoch: mantém; "%m/%d/%Y:%H:%M:%S": converte no fuso fixo; outro formato: usa o valor original
    return (f'if(match({field}, "^[0-9.]+$"), {field}, '
            f'coalesce(round(strptime({field}." {offset}", "%m/%d/%Y:%H:%M:%S %z"), 0), {field}))')


def pin_timezone(spl: str, offset: str) -> str:
    """Fixa o fuso das janelas do lookup no subsearch, independentemente do fuso do usuário do token.

    O Splunk interpreta earliest/latest no formato %m/%d/%Y:%H:%M:%S no fuso do USUÁRIO; aqui o
    próprio Splunk converte inicio/fim para epoch usando o offset da aplicação (ex.: -0300).
    Os arquivos .spl permanecem inalterados; a transformação ocorre só na montagem da busca.
    """
    if not OFFSET_RE.match(offset):
        raise ValueError("offset de fuso inválido")
    new = (f'| eval ini_epoch = {_epoch_expr("inicio", offset)}, fim_epoch = {_epoch_expr("fim", offset)}\n'
           f'    | eval block = "(earliest=".ini_epoch." latest=".fim_epoch.")"')
    out, n = _BLOCK_RE.subn(lambda m: new, spl)
    if n == 0:
        raise ValueError("subsearch de janelas não encontrado para fixar o fuso")
    return out


def render(spl: str, campaign: str, allowed: set[str], tz_offset: str | None = None) -> str:
    if not isinstance(campaign, str) or not CAMPAIGN_RE.match(campaign):
        raise InvalidCampaign("Valor de campanha com formato inválido")
    if campaign not in allowed:
        raise InvalidCampaign("Campanha não encontrada no lookup com janela válida")
    if "$class$" not in spl:
        raise ValueError("Consulta sem o parâmetro $class$")
    spl = spl.replace("$class$", campaign)
    return pin_timezone(spl, tz_offset) if tz_offset else spl


def render_lookup(spl: str, tz_offset: str) -> str:
    if not OFFSET_RE.match(tz_offset):
        raise ValueError("offset de fuso inválido")
    return spl.replace("$tz_offset$", tz_offset)


# ------------------------------------------------------------------ lookup
SPLUNK_TIME_FORMATS = ("%m/%d/%Y:%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d")


def parse_lookup_time(raw: object, tz: ZoneInfo) -> datetime | None:
    """Interpreta inicio/fim do lookup. Retorna None para formatos relativos/desconhecidos."""
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    if re.fullmatch(r"\d{9,11}(\.\d+)?", s):
        return datetime.fromtimestamp(float(s), tz)
    try:
        dt = datetime.fromisoformat(s)
        return dt.astimezone(tz) if dt.tzinfo else dt.replace(tzinfo=tz)
    except ValueError:
        pass
    for f in SPLUNK_TIME_FORMATS:
        try:
            return datetime.strptime(s, f).replace(tzinfo=tz)
        except ValueError:
            continue
    return None


@dataclass
class Window:
    start: datetime | None
    end: datetime | None
    raw_start: str
    raw_end: str

    @property
    def year(self) -> int | None:
        return self.start.year if self.start else None

    @property
    def valid(self) -> bool:
        return bool(self.start and self.end and self.end > self.start)

    def to_dict(self) -> dict:
        return {
            "start": self.start.isoformat() if self.start else None,
            "end": self.end.isoformat() if self.end else None,
            "raw_start": self.raw_start,
            "raw_end": self.raw_end,
            "year": self.year,
            "valid": self.valid,
        }


@dataclass
class Campaign:
    id: str
    label: str
    windows: list[Window] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)

    @property
    def valid_windows(self) -> list[Window]:
        return sorted((w for w in self.windows if w.valid), key=lambda w: w.start)

    @property
    def years(self) -> list[int]:
        return sorted({w.year for w in self.valid_windows})

    @property
    def usable(self) -> bool:
        return bool(self.valid_windows) and bool(CAMPAIGN_RE.match(self.id))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "label": self.label,
            "years": self.years,
            "usable": self.usable,
            "windows": [w.to_dict() for w in self.windows],
            "issues": self.issues,
        }


def campaign_label(cid: str, labels: dict[str, str]) -> str:
    if cid in labels:
        return labels[cid]
    return re.sub(r"[_\-]+", " ", cid).strip().title()


def parse_campaigns(rows: list[dict], tz: ZoneInfo, labels: dict[str, str]) -> list[Campaign]:
    """Prefere inicio_epoch/fim_epoch calculados pelo próprio Splunk (no fuso do usuário do token),
    garantindo que as janelas do painel sejam exatamente as janelas buscadas pelo subsearch."""
    out: dict[str, Campaign] = {}
    tz_warning = None
    splunk_tz = next((str(r["splunk_tz"]) for r in rows if r.get("splunk_tz")), None)
    if splunk_tz:
        local = datetime.now(tz).strftime("%z")
        if splunk_tz != local:
            tz_warning = (f"Informativo: o usuário do token no Splunk está no fuso {splunk_tz}, diferente de "
                          f"{tz.key} ({local}). As janelas do lookup são fixadas em {local} pela aplicação, "
                          "então isso não afeta os números.")
    for r in rows:
        status = str(r.get("status", "")).strip()
        periodo = str(r.get("periodo", "")).strip()
        if status != "1" or not periodo:
            continue
        c = out.setdefault(periodo, Campaign(periodo, campaign_label(periodo, labels)))
        rs, re_ = str(r.get("inicio", "")), str(r.get("fim", ""))
        w = Window(parse_lookup_time(r.get("inicio_epoch"), tz) or parse_lookup_time(rs, tz),
                   parse_lookup_time(r.get("fim_epoch"), tz) or parse_lookup_time(re_, tz), rs, re_)
        if not w.valid:
            c.issues.append(f"Janela não interpretável: inicio={rs!r} fim={re_!r}")
        c.windows.append(w)
    for c in out.values():
        if tz_warning:
            c.issues.append(tz_warning)
        if not CAMPAIGN_RE.match(c.id):
            c.issues.append("Valor de periodo com caracteres não permitidos; campanha bloqueada")
        yrs = [w.year for w in c.valid_windows]
        if len(yrs) != len(set(yrs)):
            c.issues.append("Mais de uma janela no mesmo ano: dias tratados por posição relativa na janela")
    return sorted(out.values(), key=lambda c: c.id)


def pick_default_campaign(campaigns: list[Campaign], preferred: str, now: datetime) -> str | None:
    usable = [c for c in campaigns if c.usable]
    if not usable:
        return None
    ids = {c.id for c in usable}
    if preferred and preferred in ids:
        return preferred
    bf = [c for c in usable if re.search(r"black", c.id, re.I)]
    pool = bf or usable
    # prioriza a campanha com janela mais próxima de "agora"
    def dist(c: Campaign) -> float:
        return min(abs((w.start - now).total_seconds()) for w in c.valid_windows)

    return min(pool, key=dist).id
