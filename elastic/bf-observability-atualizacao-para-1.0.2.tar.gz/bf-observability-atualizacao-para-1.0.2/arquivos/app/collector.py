"""Orquestração das coletas: uma busca consolidada por fonte e por ciclo.

* Controle de concorrência: um ciclo por vez (novas solicitações durante uma coleta
  em andamento são ignoradas e informadas como "em andamento").
* Isolamento de falhas: ICN e Solar são coletados e cacheados de forma independente.
* Em falha, o último resultado válido (SQLite) continua sendo servido, marcado como desatualizado.
"""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime
from zoneinfo import ZoneInfo

from . import normalize as N
from .cache import Cache
from .config import Settings
from .observability import METRICS, event, sanitize
from .queries import Campaign, Window, load_query, parse_campaigns, pick_default_campaign, render, render_lookup
from .splunk_client import SplunkClient, SplunkError

log = logging.getLogger("bf.collector")
LOOKUP_TTL_S = 3600
SOURCES = ("icn", "solar")


def _campaign_from_dict(d: dict, tz: ZoneInfo) -> Campaign:
    c = Campaign(d["id"], d["label"], issues=list(d.get("issues", [])))
    for w in d["windows"]:
        c.windows.append(Window(
            datetime.fromisoformat(w["start"]).astimezone(tz) if w["start"] else None,
            datetime.fromisoformat(w["end"]).astimezone(tz) if w["end"] else None,
            w["raw_start"], w["raw_end"]))
    return c


class Collector:
    def __init__(self, settings: Settings, catalog: dict, cache: Cache, client: SplunkClient):
        self.s = settings
        self.catalog = catalog
        self.cache = cache
        self.client = client
        self.tz = ZoneInfo(settings.timezone)
        self.lock = asyncio.Lock()
        self.cycle = 0
        self.campaigns: list[Campaign] = []
        self.lookup_at: float | None = None
        self.lookup_error: str | None = None
        self.default_campaign: str | None = None
        self.status: dict[str, dict] = {
            s: {"status": "never", "last_attempt": None, "last_success": None, "error": None,
                "error_kind": None, "rows": None, "duration_ms": None, "campaign": None} for s in SOURCES}
        self.splunk = {"status": "unknown", "checked_at": None, "error": None}
        self.reconciliation: dict | None = None
        self.profiles: dict = {}
        self.solar_diag: dict | None = None
        self.data_version = 0
        self.active: str | None = None
        self.memo: dict[tuple, dict] = {}  # payloads já calculados (por versão dos dados)
        self.clock = lambda: datetime.now(self.tz)
        self._load_lookup_cache()

    @property
    def tz_offset(self) -> str:
        """Offset do fuso da aplicação (ex.: -0300), usado para fixar as janelas nas buscas."""
        return self.clock().strftime("%z")

    # --------------------------------------------------------- campanhas
    def _load_lookup_cache(self) -> None:
        hit = self.cache.get_kv("lookup")
        if hit:
            at, data = hit
            self.campaigns = [_campaign_from_dict(d, self.tz) for d in data]
            self.lookup_at = at
            self.default_campaign = pick_default_campaign(self.campaigns, self.s.default_campaign, self.clock())
        rec = self.cache.get_kv("reconciliation")
        if rec:
            self.reconciliation = rec[1]

    def campaign(self, cid: str | None) -> Campaign | None:
        cid = cid or self.default_campaign
        return next((c for c in self.campaigns if c.id == cid and c.usable), None)

    @property
    def allowed(self) -> set[str]:
        return {c.id for c in self.campaigns if c.usable}

    async def refresh_lookup(self, force: bool = False) -> None:
        if not force and self.lookup_at and time.time() - self.lookup_at < LOOKUP_TTL_S and self.campaigns:
            METRICS.inc("cache_hit")
            return
        METRICS.inc("cache_miss")
        try:
            res = await self.client.search(render_lookup(load_query(self.s.queries_dir, "lookup"), self.tz_offset),
                                           label="lookup")
            camps = parse_campaigns(res.rows, self.tz, self.catalog.get("campaign_labels", {}))
            self.campaigns = camps
            self.lookup_at = time.time()
            self.lookup_error = None
            self.cache.put_kv("lookup", [c.to_dict() for c in camps])
            self.default_campaign = pick_default_campaign(camps, self.s.default_campaign, self.clock())
            self.splunk.update(status="ok", checked_at=time.time(), error=None)
            event(log, "lookup carregado", campaigns=len(camps), usable=len(self.allowed))
        except SplunkError as exc:
            self.lookup_error = f"{exc.kind}: {exc}"
            self.splunk.update(status=exc.kind, checked_at=time.time(), error=str(exc))
            if not self.campaigns:
                raise

    # ------------------------------------------------------------ coleta
    async def refresh(self, campaign: str | None = None, *, force_lookup: bool = False) -> dict:
        if self.lock.locked():
            METRICS.inc("refresh_skipped_running")
            return {"status": "running"}
        async with self.lock:
            t0 = time.time()
            self.cycle += 1
            METRICS.inc("refresh_cycles")
            if not self.s.configured:
                msg = "Variáveis ausentes no .env: " + ", ".join(self.s.missing)
                self.splunk.update(status="configuracao", checked_at=time.time(), error=msg)
                for s in SOURCES:
                    self.status[s].update(status="error", error=msg, error_kind="configuracao", last_attempt=t0)
                return {"status": "error", "error": msg}
            try:
                await self.refresh_lookup(force=force_lookup)
            except SplunkError as exc:
                for s in SOURCES:
                    self.status[s].update(status="error", error=str(exc), error_kind=exc.kind, last_attempt=t0)
                return {"status": "error", "error": f"Falha ao ler o lookup: {exc}"}
            camp = self.campaign(campaign)
            if camp is None:
                msg = "Campanha sem janela válida no lookup; nenhuma busca executada."
                for s in SOURCES:
                    self.status[s].update(status="error", error=msg, error_kind="campanha", last_attempt=t0)
                return {"status": "error", "error": msg}

            self.active = camp.id
            jobs = {"icn": self._collect_icn(camp), "solar": self._collect_solar(camp)}
            results = list(await asyncio.gather(*jobs.values(), return_exceptions=True))
            n = self.s.icn_reconcile_every
            if n and results[0] is True and (self.cycle - 1) % n == 0:
                jobs["reconcile"] = None
                try:
                    results.append(await self._reconcile(camp))
                except Exception as exc:  # reconciliação nunca invalida a coleta
                    results.append(exc)
            out = {}
            for name, r in zip(jobs.keys(), results):
                if isinstance(r, Exception) and not isinstance(r, SplunkError):
                    event(log, "erro inesperado na coleta", logging.ERROR, job=name, error=sanitize(repr(r)))
                    if name in SOURCES:
                        self.status[name].update(status="error", error="erro interno de processamento",
                                                 error_kind="normalizacao")
                out[name] = "ok" if r is True else "error"
            self.data_version += 1
            ok_any = any(self.status[s]["status"] == "ok" for s in SOURCES)
            self.splunk.update(status="ok" if ok_any else self.splunk["status"], checked_at=time.time())
            return {"status": "ok" if all(out.get(s) == "ok" for s in SOURCES) else "partial",
                    "campaign": camp.id, "jobs": out, "duration_ms": int((time.time() - t0) * 1000)}

    async def _run_source(self, camp: Campaign, source: str, query_name: str, normalizer) -> bool:
        st = self.status[source]
        t0 = time.time()
        st.update(last_attempt=t0, campaign=camp.id)
        try:
            spl = render(load_query(self.s.queries_dir, query_name), camp.id, self.allowed, self.tz_offset)
            res = await self.client.search(spl, label=f"{source}:{query_name}")
            norm = normalizer(res.rows)
            norm["collected_at"] = time.time()
            norm["sid_messages"] = res.messages[:5]
            self.cache.put_source(camp.id, source, norm)
            METRICS.inc(f"rows_{source}", len(res.rows))
            METRICS.inc("normalization_errors", sum(norm["errors"].values()))
            st.update(status="ok", last_success=time.time(), error=None, error_kind=None,
                      rows=len(res.rows), duration_ms=res.duration_ms, points=len(norm["points"]),
                      normalization_errors=norm["errors"])
            self.cache.log_collection(campaign=camp.id, source=source, started_at=t0, finished_at=time.time(),
                                      ok=True, rows=len(res.rows), duration_ms=res.duration_ms)
            return True
        except SplunkError as exc:
            st.update(status="error", error=str(exc), error_kind=exc.kind)
            self.cache.log_collection(campaign=camp.id, source=source, started_at=t0, finished_at=time.time(),
                                      ok=False, duration_ms=int((time.time() - t0) * 1000),
                                      error_kind=exc.kind, error=str(exc))
            raise

    def _time_fields(self) -> dict[str, str]:
        return {i["match"]: i["time_field"] for i in self.catalog.get("indicators", [])
                if i.get("source") == "solar" and i.get("time_field")}

    async def _collect_icn(self, camp: Campaign) -> bool:
        def norm(rows):
            n = N.normalize_icn(rows, camp, self.tz)
            n["ingestion"] = N.ingestion_summary(n, self.tz)
            return n
        return await self._run_source(camp, "icn", "icn_hourly", norm)

    async def _collect_solar(self, camp: Campaign) -> bool:
        def norm(rows):
            n = N.normalize_solar_hourly(rows, camp, self.tz)
            self.profiles[camp.id] = N.profile_solar(n)
            n["profile"] = self.profiles[camp.id]
            return n
        ok = await self._run_source(camp, "solar", "solar_hourly", norm)
        if self.status["solar"].get("rows") == 0 and (
                not self.solar_diag or time.time() - self.solar_diag["at"] > 3600):
            await self._diagnose_solar()
        elif self.status["solar"].get("rows"):
            self.solar_diag = None
        return ok

    async def _diagnose_solar(self) -> None:
        """Busca Solar sem resultados: executa 2 buscas leves (tstats + 24 h) e registra a conclusão."""
        from .diagnostics import diagnose_solar
        res = {}
        for name in ("solar_index_access", "solar_fields"):
            try:
                res[name] = (await self.client.search(load_query(self.s.queries_dir, name), label=f"diag:{name}")).rows
            except SplunkError as exc:
                res[name] = None
                event(log, "diagnóstico solar falhou", logging.WARNING, query=name, error=str(exc))
        self.solar_diag = {"at": time.time(), **diagnose_solar(res["solar_index_access"], res["solar_fields"])}

    async def _reconcile(self, camp: Campaign) -> bool:
        """Executa a consulta ICN ORIGINAL e confronta os totais com a variante horária."""
        spl = render(load_query(self.s.queries_dir, "icn_original"), camp.id, self.allowed, self.tz_offset)
        res = await self.client.search(spl, label="icn:original(reconciliacao)")
        orig = N.icn_daily_totals(res.rows)
        hit = self.cache.get_source(camp.id, "icn")
        hourly: dict[str, dict[str, float]] = {}
        if hit:
            for p in hit[1]["points"]:
                hourly.setdefault(p["key"], {})
                y = str(p["year"])
                hourly[p["key"]][y] = hourly[p["key"]].get(y, 0.0) + p["value"]
        items = []
        for key in sorted(set(orig) | set(hourly)):
            for y in sorted(set(orig.get(key, {})) | set(hourly.get(key, {}))):
                a, b = orig.get(key, {}).get(y), hourly.get(key, {}).get(y)
                diff = None if (a in (None, 0) or b is None) else (b - a) / a * 100
                items.append({"key": key, "year": y, "original": a, "hourly": b,
                              "diff_pct": None if diff is None else round(diff, 3),
                              "ok": diff is not None and abs(diff) < 0.5})
        self.reconciliation = {"campaign": camp.id, "at": time.time(), "rows_original": len(res.rows),
                               "items": items, "note": "Totais por sourcetype e ano: consulta original × variante horária. "
                               "Diferenças pequenas podem ocorrer no ano em curso (coletas em momentos distintos)."}
        self.cache.put_kv("reconciliation", self.reconciliation)
        return True

    # ------------------------------------------------------------ leitura
    def source_data(self, campaign: str) -> dict[str, dict | None]:
        out = {}
        for s in SOURCES:
            hit = self.cache.get_source(campaign, s)
            METRICS.inc("cache_hit" if hit else "cache_miss")
            out[s] = hit[1] if hit else None
        return out

    def sources_status(self, campaign: str | None) -> dict:
        now = time.time()
        out = {}
        for s in SOURCES:
            st = dict(self.status[s])
            hit = self.cache.get_source(campaign, s) if campaign else None
            st["cached_at"] = hit[0] if hit else None
            st["data_age_s"] = int(now - hit[0]) if hit else None
            if st["status"] == "error" and hit:
                st["status"] = "stale"  # mostrando último resultado válido
            elif st["status"] == "never" and hit:
                st["status"] = "cached"
            out[s] = st
        return out

    async def scheduler(self) -> None:
        if self.s.refresh_interval_s <= 0:
            return
        while True:
            try:
                await self.refresh(self.active)
            except Exception as exc:  # nunca derruba o loop
                event(log, "falha no agendador", logging.ERROR, error=sanitize(repr(exc)))
            await asyncio.sleep(self.s.refresh_interval_s)
