"""API REST local + servidor do frontend.

O frontend nunca fala com o Splunk: só consome estes endpoints. Nenhum endpoint
aceita SPL; todos os parâmetros são validados.
"""
from __future__ import annotations

import asyncio
import base64
import json
import re
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from . import report
from .cache import Cache
from .collector import Collector
from .config import ROOT, load_catalog, load_settings
from .engine import STATUS_LABEL, resolve_catalog
from .observability import METRICS, sanitize, setup_logging
from .queries import CAMPAIGN_RE, QUERY_FILES, load_query
from .service import build_dashboard, strip_internal
from .splunk_client import SplunkClient

VERSION = "1.0.2"
SOURCES = {"all", "icn", "solar"}
STATUSES = {"all", "alerts", "ok", "warn", "bad", "unavailable", "stale"}
SORTS = {"default", "worst", "best"}


def create_app(settings=None, transport=None, start_scheduler: bool = True) -> FastAPI:
    settings = settings or load_settings()
    log = setup_logging(settings.log_path)
    catalog = load_catalog(settings.catalog_path)
    cache = Cache(settings.db_path)
    client = SplunkClient(settings, transport=transport)
    col = Collector(settings, catalog, cache, client)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        task = asyncio.create_task(col.scheduler()) if start_scheduler else None
        log.info("aplicação iniciada", extra={"fields": settings.public()})
        yield
        if task:
            task.cancel()

    app = FastAPI(title="Black Friday Business Observability", version=VERSION, lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)
    app.state.col = col
    allowed_hosts = ["127.0.0.1", "localhost", "testserver"]
    if settings.host not in ("127.0.0.1", "localhost"):
        allowed_hosts.append("*")  # exposição na rede somente com BF_HOST explícito
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=allowed_hosts)

    @app.middleware("http")
    async def headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["X-Frame-Options"] = "DENY"
        if "content-security-policy" not in resp.headers:
            resp.headers["Content-Security-Policy"] = (
                "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
                "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
        if request.url.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        log.error("erro interno", extra={"fields": {"path": request.url.path, "error": sanitize(repr(exc))}})
        return JSONResponse({"detail": "Erro interno ao processar a solicitação."}, status_code=500)

    # ---------------------------------------------------------- validação
    def v_campaign(c: str | None) -> str | None:
        if c is None or c == "":
            return None
        if not CAMPAIGN_RE.match(c) or c not in col.allowed:
            raise HTTPException(400, "Campanha inválida")
        return c

    def v_choice(v: str, allowed: set, name: str) -> str:
        if v not in allowed:
            raise HTTPException(400, f"Parâmetro {name} inválido")
        return v

    def v_segment(v: str) -> str:
        if v != "all" and v not in catalog.get("segments", []):
            raise HTTPException(400, "Segmento inválido")
        return v

    def dash(campaign, year, ref_year, day, cutoff):
        c = v_campaign(campaign)
        if c and col.active != c and not col.lock.locked() and col.cache.get_source(c, "icn") is None:
            asyncio.get_running_loop().create_task(col.refresh(c))  # primeira carga da campanha
        return build_dashboard(col, campaign=c, year=year, ref_year=ref_year, day=day, cutoff=cutoff)


    # ----------------------------------------------------------- endpoints
    @app.get("/api/health")
    async def health():
        return {"status": "ok", "version": VERSION, "splunk": col.splunk["status"],
                "configured": settings.configured, "missing": settings.missing,
                "collecting": col.lock.locked()}

    @app.get("/api/campaigns")
    async def campaigns():
        return {"default": col.default_campaign, "lookup_at": col.lookup_at, "lookup_error": col.lookup_error,
                "campaigns": [c.to_dict() for c in col.campaigns]}

    @app.get("/api/indicators")
    async def indicators(campaign: str | None = None):
        c = v_campaign(campaign) or col.default_campaign
        data = col.source_data(c) if c else {}
        keys = {s: (d["keys"] if d else []) for s, d in data.items()}
        return {"indicators": resolve_catalog(catalog, keys), "defaults": catalog.get("defaults", {})}

    @app.get("/api/dashboard")
    async def dashboard(campaign: str | None = None, year: int | None = Query(None, ge=2000, le=2100), ref_year: int | None = Query(None, ge=2000, le=2100),
                        day: int | None = Query(None, ge=0, le=60), cutoff: int | None = Query(None, ge=1, le=24)):
        return dash(campaign, year, ref_year, day, cutoff)

    @app.get("/api/indicators/{ind_id}/history")
    async def history(ind_id: str, campaign: str | None = None, year: int | None = Query(None, ge=2000, le=2100), ref_year: int | None = Query(None, ge=2000, le=2100),
                      day: int | None = Query(None, ge=0, le=60), cutoff: int | None = Query(None, ge=1, le=24)):
        if not re.fullmatch(r"[A-Za-z0-9_]{1,64}", ind_id):
            raise HTTPException(400, "Indicador inválido")
        p = dash(campaign, year, ref_year, day, cutoff)
        for i in p.get("indicators", []):
            if i["id"] == ind_id:
                return {"selection": p.get("selection"), "indicator": i}
        raise HTTPException(404, "Indicador não encontrado")

    @app.get("/api/sources/status")
    async def sources_status(campaign: str | None = None):
        c = v_campaign(campaign) or col.active or col.default_campaign
        return {"campaign": c, "splunk": col.splunk, "sources": col.sources_status(c),
                "collecting": col.lock.locked(), "cycle": col.cycle}

    def filtered(campaign, year, ref_year, day, cutoff, source, segment, status, sort):
        p = dash(campaign, year, ref_year, day, cutoff)
        if p.get("status") != "ok":
            raise HTTPException(409, "Sem dados disponíveis para a campanha")
        ref = p["selection"]["ref_year"]
        inds = report.apply_filters(p["indicators"], ref, source=v_choice(source, SOURCES, "source"),
                                    segment=v_segment(segment), status=v_choice(status, STATUSES, "status"),
                                    sort=v_choice(sort, SORTS, "sort"))
        ids = {i["id"] for i in inds}
        ins = [x for x in p["insights"].get(str(ref), []) if x["indicator_id"] is None or x["indicator_id"] in ids]
        return p, inds, ins

    @app.get("/api/reports/executive")
    async def executive(campaign: str | None = None, year: int | None = Query(None, ge=2000, le=2100), ref_year: int | None = Query(None, ge=2000, le=2100),
                        day: int | None = Query(None, ge=0, le=60), cutoff: int | None = Query(None, ge=1, le=24), source: str = "all", segment: str = "all",
                        status: str = "all", sort: str = "default", style: str = "whatsapp"):
        p, inds, ins = filtered(campaign, year, ref_year, day, cutoff, source, segment, status, sort)
        style = v_choice(style, {"whatsapp", "teams"}, "style")
        return {"text": report.executive_text(p, inds, ins, fmt_style=style, public_url=settings.public_url),
                "count": len(inds)}

    @app.post("/api/refresh")
    async def refresh(campaign: str | None = None):
        c = v_campaign(campaign)
        if col.lock.locked():
            return {"status": "running"}
        asyncio.get_running_loop().create_task(col.refresh(c, force_lookup=True))
        return {"status": "started"}

    @app.get("/api/export/csv")
    async def export_csv(campaign: str | None = None, year: int | None = Query(None, ge=2000, le=2100), ref_year: int | None = Query(None, ge=2000, le=2100),
                         day: int | None = Query(None, ge=0, le=60), cutoff: int | None = Query(None, ge=1, le=24), source: str = "all", segment: str = "all",
                         status: str = "all", sort: str = "default"):
        p, inds, _ = filtered(campaign, year, ref_year, day, cutoff, source, segment, status, sort)
        name = f"{p['campaign']['id']}_{p['selection']['year']}_{p['generated_at'][:16].replace(':', '')}.csv"
        return Response(report.to_csv(p, inds), media_type="text/csv; charset=utf-8",
                        headers={"Content-Disposition": f'attachment; filename="{name}"'})

    @app.get("/api/export/html")
    async def export_html(campaign: str | None = None, year: int | None = Query(None, ge=2000, le=2100), ref_year: int | None = Query(None, ge=2000, le=2100),
                          day: int | None = Query(None, ge=0, le=60), cutoff: int | None = Query(None, ge=1, le=24), source: str = "all", segment: str = "all",
                          status: str = "all", sort: str = "default"):
        p, inds, ins = filtered(campaign, year, ref_year, day, cutoff, source, segment, status, sort)
        snap = strip_internal(p)
        snap["report_text"] = report.executive_text(p, inds, ins)
        snap["filters"] = {"source": source, "segment": segment, "status": status, "sort": sort}
        html = snapshot_html(Path(settings.frontend_dir), snap)
        name = f"{p['campaign']['id']}_{p['selection']['year']}_snapshot_{p['generated_at'][:16].replace(':', '')}.html"
        return HTMLResponse(html, headers={"Content-Disposition": f'attachment; filename="{name}"',
                                           "Content-Security-Policy": "default-src 'none'; img-src data:; "
                                           "style-src 'unsafe-inline'; script-src 'unsafe-inline'"})

    @app.get("/api/model")
    async def model():
        """Seção técnica da aba Modelo de Dados (sem credenciais)."""
        c = col.active or col.default_campaign
        hit = col.cache.get_source(c, "solar") if c else None
        icn = col.cache.get_source(c, "icn") if c else None
        return {
            "settings": settings.public(),
            "metrics": METRICS.snapshot(),
            "collections_24h": col.cache.collection_stats(),
            "reconciliation": col.reconciliation,
            "solar_profile": (hit[1].get("profile") if hit else None),
            "icn_ingestion": (icn[1].get("ingestion") if icn else None),
            "solar_diagnosis": col.solar_diag,
            "normalization": {s: (h[1]["errors"], h[1].get("error_samples", [])) for s, h in
                              (("icn", icn), ("solar", hit)) if h},
            "catalog": catalog,
            "status_labels": STATUS_LABEL,
            "queries": {k: load_query(settings.queries_dir, k) for k in QUERY_FILES},
            "campaign": c,
        }

    # ------------------------------------------------------------ frontend
    fe = Path(settings.frontend_dir)

    @app.get("/", include_in_schema=False)
    async def index():
        return FileResponse(fe / "index.html")

    app.mount("/static", StaticFiles(directory=fe), name="static")
    return app


def snapshot_html(fe: Path, snap: dict) -> str:
    """HTML autônomo: CSS, JS, logo e dados embutidos; sem credenciais nem chamadas de rede."""
    html = (fe / "index.html").read_text(encoding="utf-8")
    css = (fe / "app.css").read_text(encoding="utf-8")
    js = (fe / "app.js").read_text(encoding="utf-8")
    logo = base64.b64encode((fe / "coee-aiops.png").read_bytes()).decode()
    data = json.dumps(snap, ensure_ascii=False).replace("</", "<\\/").replace("<!--", "<\\!--")
    html = html.replace('<link rel="stylesheet" href="/static/app.css">', f"<style>{css}</style>")
    html = html.replace("/static/coee-aiops.png", f"data:image/png;base64,{logo}")
    js = js.replace("</script", "<\\/script")
    html = html.replace('<script src="/static/app.js"></script>',
                        "<script>window.__SNAPSHOT__=" + data + ";</script>\n<script>" + js + "</script>")
    return html


