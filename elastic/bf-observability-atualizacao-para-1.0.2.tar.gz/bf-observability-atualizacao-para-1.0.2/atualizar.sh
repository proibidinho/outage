#!/usr/bin/env bash
# Atualiza o painel no servidor aplicando só os arquivos alterados sobre a imagem instalada.
# Sem internet e sem pip. Mantém a imagem anterior para rollback. Uso (root): ./atualizar.sh
set -euo pipefail
cd "$(dirname "$0")"
NEW="$(cat VERSAO_NOVA)"
ENV_FILE="${ENV_FILE:-/etc/bf-observability/bf-observability.env}"
QUADLET="${QUADLET:-/etc/containers/systemd/bf-observability.container}"
[ -f "$QUADLET" ] || { echo "[ERRO] $QUADLET não encontrado (instale com o pacote completo)."; exit 1; }
BASE="$(sed -n 's|^Image=localhost/bf-observability:\(.*\)$|\1|p' "$QUADLET" | head -1)"
[ "$BASE" != "$NEW" ] || { echo "== Já está na versão $NEW."; exit 0; }
grep -qx "$BASE" VERSOES_BASE || { echo "[ERRO] versão instalada '$BASE' não suportada por este pacote (aceita: $(tr '\n' ' ' < VERSOES_BASE))."; exit 1; }
echo "== Versão instalada: $BASE → nova: $NEW"
DRY="${DRY_RUN:-}"   # DRY_RUN=1: só compila e ajusta arquivos, sem systemctl

[ -n "$DRY" ] || [ "$(id -u)" -eq 0 ] || { echo "[ERRO] Execute como root (sudo ./atualizar.sh)."; exit 1; }
command -v podman >/dev/null || { echo "[ERRO] Podman não encontrado."; exit 1; }
podman image exists "localhost/bf-observability:$BASE" || { echo "[ERRO] imagem base localhost/bf-observability:$BASE não encontrada neste servidor."; exit 1; }

echo "== 1/4 Compilando localhost/bf-observability:$NEW sobre $BASE (sem internet)"
podman build --pull=never --format docker --build-arg "BASE_TAG=$BASE" -f Containerfile.atualizacao -t "localhost/bf-observability:$NEW" .

echo "== 2/4 Configuração ($ENV_FILE): só acrescenta o que falta; token e valores existentes são mantidos"
[ -f "$ENV_FILE" ] || { echo "[ERRO] $ENV_FILE não existe (instale com o pacote completo)."; exit 1; }
cp -p "$ENV_FILE" "$ENV_FILE.bak-$BASE"
while IFS='=' read -r k v; do
  [ -n "$k" ] || continue
  if grep -Eq "^$k=.+" "$ENV_FILE"; then echo "   mantido: $k"; continue; fi
  [ "$k" = "BF_PUBLIC_URL" ] && v="http://$(hostname -f):$(sed -n 's/^PublishPort=\([0-9]*\):.*/\1/p' "$QUADLET" 2>/dev/null | head -1)"
  [ "$k" = "BF_PUBLIC_URL" ] && [[ "$v" == *: ]] && v="${v}8765"
  sed -i "/^#\?\s*$k=/d" "$ENV_FILE"; printf '%s=%s\n' "$k" "$v" >> "$ENV_FILE"; echo "   adicionado: $k=$v"
done < novas-variaveis.env
grep -Eq '^COCKPIT_SOURCE_SPLUNK_TOKEN=.+' "$ENV_FILE" || echo "   [AVISO] token vazio: preencha COCKPIT_SOURCE_SPLUNK_TOKEN em $ENV_FILE"

echo "== 3/4 Apontando o serviço para a versão $NEW"
cp -p "$QUADLET" "$QUADLET.bak-$BASE"
sed -i "s|^Image=localhost/bf-observability:.*|Image=localhost/bf-observability:$NEW|" "$QUADLET"
# proxy somente do arquivo de configuração (não herdar variáveis de proxy do ambiente do podman)
grep -q -- '--http-proxy=false' "$QUADLET" || sed -i '/^EnvironmentFile=/a PodmanArgs=--http-proxy=false' "$QUADLET"

if [ -n "$DRY" ]; then echo "== 4/4 (DRY_RUN) serviço não reiniciado"; exit 0; fi
echo "== 4/4 Reiniciando"
systemctl daemon-reload && systemctl restart bf-observability && sleep 8
curl -fs "http://127.0.0.1:$(sed -n 's/^PublishPort=\([0-9]*\):.*/\1/p' "$QUADLET" | head -1)/api/health" && echo && echo "[ok] Atualizado para $NEW." \
  || { echo "[AVISO] o painel não respondeu: veja journalctl -u bf-observability -n 50"; }
echo "Rollback: sed -i 's|:$NEW$|:$BASE|' $QUADLET && systemctl daemon-reload && systemctl restart bf-observability"
