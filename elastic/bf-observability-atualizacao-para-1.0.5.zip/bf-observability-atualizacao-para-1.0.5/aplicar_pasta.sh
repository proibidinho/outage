#!/usr/bin/env bash
# Aplica a atualização numa instalação EM PASTA (ex.: /opt/bf-observability com .venv e serviço systemd).
# Faz backup dos arquivos substituídos, copia os novos, acrescenta ao .env variáveis ausentes e reinicia.
# Uso (root):  ./aplicar_pasta.sh [/opt/bf-observability]
set -euo pipefail
cd "$(dirname "$0")"
DEST="${1:-/opt/bf-observability}"
NEW="$(cat VERSAO_NOVA)"
[ -f "$DEST/app/main.py" ] || { echo "[ERRO] $DEST não parece a pasta do painel (app/main.py ausente)."; exit 1; }
ATUAL="$(sed -n 's/^VERSION = "\(.*\)"/\1/p' "$DEST/app/main.py")"
[ "$ATUAL" != "$NEW" ] || { echo "== Já está na versão $NEW."; exit 0; }
grep -qx "$ATUAL" VERSOES_BASE || { echo "[ERRO] versão instalada '$ATUAL' não suportada (aceita: $(tr '\n' ' ' < VERSOES_BASE))."; exit 1; }
echo "== Versão instalada: $ATUAL → nova: $NEW"

BK="$DEST/backup-$ATUAL-$(date +%Y%m%d-%H%M%S)"
echo "== 1/3 Backup dos arquivos que serão substituídos em $BK"
(cd arquivos && find . -type f) | while read -r f; do
  if [ -f "$DEST/$f" ]; then mkdir -p "$BK/$(dirname "$f")"; cp -p "$DEST/$f" "$BK/$f"; fi
done
echo "== 2/3 Copiando $(cd arquivos && find . -type f | wc -l) arquivos"
cp -r arquivos/. "$DEST/"

ENVF="$DEST/.env"
if [ -f "$ENVF" ]; then
  cp -p "$ENVF" "$BK/.env" 2>/dev/null || true
  while IFS='=' read -r k v; do
    [ -n "$k" ] || continue
    grep -Eq "^$k=.+" "$ENVF" && continue
    [ "$k" = "BF_PUBLIC_URL" ] && v="http://$(hostname -f):8765"
    printf '%s=%s\n' "$k" "$v" >> "$ENVF"; echo "   .env: adicionado $k=$v"
  done < novas-variaveis.env
fi

echo "== 3/3 Reiniciando"
if systemctl list-unit-files bf-observability.service >/dev/null 2>&1 && systemctl cat bf-observability >/dev/null 2>&1; then
  systemctl restart bf-observability && sleep 6
else
  echo "   Serviço systemd não encontrado: reinicie manualmente (./stop.sh && ./start.sh)."
fi
curl -fs http://127.0.0.1:8765/api/health && echo && echo "[ok] Atualizado para $NEW." || echo "[AVISO] o painel ainda não respondeu; confira os logs."
echo "Rollback: cp -r $BK/. $DEST/ && systemctl restart bf-observability"
