/* Black Friday Business Observability · frontend
 * Fala apenas com a API local (/api/*). Nunca acessa o Splunk nem recebe credenciais.
 * Em modo snapshot (window.__SNAPSHOT__) funciona offline com os dados embutidos.
 */
'use strict';
const SNAP = window.__SNAPSHOT__ || null;
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MINUS = '−';
const nf0 = new Intl.NumberFormat('pt-BR', {maximumFractionDigits: 0});
const nf2 = new Intl.NumberFormat('pt-BR', {maximumFractionDigits: 2});
function fmt(v, unit){
  if (v == null || !isFinite(v)) return '—';
  if (unit === 'percentual') return nf2.format(v) + '%';
  if (unit === 'moeda') return (v<0?MINUS:'') + 'R$ ' + new Intl.NumberFormat('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2}).format(Math.abs(v));
  const s = (unit === 'quantidade' || Number.isInteger(v)) ? nf0.format(Math.abs(Math.round(v))) : nf2.format(Math.abs(v));
  return (v < 0 && s !== '0' ? MINUS : '') + s;
}
const signed = (v, u) => v == null ? '—' : (v > 0 ? '+' : '') + fmt(v, u);
const fmtK = n => { if (n == null) return '—'; const a = Math.abs(n); return a >= 1e6 ? (n/1e6).toFixed(1).replace('.',',')+'M' : a >= 1000 ? (n/1000).toFixed(1).replace('.',',')+'k' : String(Math.round(n)); };
const pctTxt = p => p == null ? 'n/a' : (p>0?'+':p<0?MINUS:'') + Math.abs(p).toFixed(1).replace('.',',') + '%';
const ARROW = p => p >= 0 ? '▲' : '▼';
const hh = b => String(b + 1).padStart(2, '0') + 'h';
const dtf = iso => { if (!iso) return '—'; const d = new Date(typeof iso === 'number' ? iso*1000 : iso);
  return d.toLocaleString('pt-BR', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit', timeZone: TZ()}).replace(',', ''); };
const tmf = iso => { if (!iso) return '—'; const d = new Date(typeof iso === 'number' ? iso*1000 : iso);
  return d.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit', timeZone: TZ()}); };
const TZ = () => (DATA && DATA.timezone) || 'America/Sao_Paulo';
const LABEL = { ok:'Acima', warn:'Atenção', bad:'Crítico', no_data:'Sem dados', no_reference:'Sem referência',
  zero_reference:'Referência zero', partial_reference:'Referência parcial', stale:'Desatualizado', error:'Erro de coleta',
  pending:'Pendente de classificação', future:'Não iniciado', daily_reference:'Ref. diária' };
const DATA_LABEL = Object.assign({}, LABEL, { ok:'OK' });
const SEG_ALL = 'all';

/* ===== estado ===== */
const ST = { campaign:null, year:null, ref:null, day:null, cutoff:null, source:'all', seg:SEG_ALL, status:'all',
             sort:'default', sel:null, tab:'exec' };
let DATA = null, MODEL = null, pollT = null, reloadT = null;

/* ===== API ===== */
function qs(extra){
  const p = new URLSearchParams();
  if (ST.campaign) p.set('campaign', ST.campaign);
  if (ST.year) p.set('year', ST.year);
  if (ST.day != null) p.set('day', ST.day);
  if (ST.cutoff) p.set('cutoff', ST.cutoff);
  if (extra) for (const [k, v] of Object.entries(extra)) p.set(k, v);
  return p.toString();
}
function filterParams(){
  return { ref_year: ST.ref || '', source: tabSource(), segment: ST.seg, status: ST.status, sort: ST.sort };
}
async function api(path, opt){
  const r = await fetch(path, Object.assign({headers:{'Accept':'application/json'}}, opt || {}));
  if (!r.ok){ let m = r.status; try { m = (await r.json()).detail || m; } catch(e){} throw new Error(m); }
  return r.json();
}
async function load(){
  if (SNAP){ DATA = SNAP; afterLoad(); return; }
  try {
    DATA = await api('/api/dashboard?' + qs());
    afterLoad();
  } catch(e){ toast('Falha ao carregar dados: ' + e.message); }
  schedule();
}
function afterLoad(){
  const s = DATA.selection;
  if (DATA.campaign){
    ST.campaign = DATA.campaign.id;
    if (s){ ST.year = s.year; ST.day = s.day;
      if (!ST.ref || !s.ref_years.includes(ST.ref)) ST.ref = s.ref_year; }
  }
  render();
}
function schedule(){
  clearTimeout(reloadT);
  // a coleta é feita pelo backend (BF_REFRESH_INTERVAL_SECONDS); a tela apenas relê o cache
  const fast = DATA && DATA.collecting;
  reloadT = setTimeout(load, fast ? 3000 : 30000);
}

/* ===== derivação (mesmas regras de report.apply_filters) ===== */
const tabSource = () => ST.tab === 'icn' ? 'icn' : ST.tab === 'solar' ? 'solar' : ST.source;
const comp = d => (d.comparisons || {})[String(ST.ref)] || {};
const perf = d => d.pending ? null : (['ok','warn','bad'].includes(comp(d).status) ? comp(d).status : null);
function cls(d){
  if (d.pending) return 'pend';
  return perf(d) || 'na';
}
function stLabel(d){
  if (d.pending) return LABEL.pending;
  const p = perf(d); if (p) return LABEL[p];
  if (['error','no_data','future'].includes(d.data_status)) return LABEL[d.data_status];
  return LABEL[comp(d).data_status] || LABEL[d.data_status] || 'Sem dados';
}
function base(source){
  let a = (DATA && DATA.indicators) || [];
  if (source !== 'all') a = a.filter(x => x.source === source);
  if (ST.seg !== SEG_ALL) a = a.filter(x => x.segment === ST.seg);
  return a;
}
function visible(source){
  let a = base(source);
  const s = ST.status;
  if (s === 'alerts') a = a.filter(x => ['warn','bad'].includes(perf(x)));
  else if (['ok','warn','bad'].includes(s)) a = a.filter(x => perf(x) === s);
  else if (s === 'unavailable') a = a.filter(x => !perf(x));
  else if (s === 'stale') a = a.filter(x => x.data_status === 'stale');
  if (ST.sort === 'worst' || ST.sort === 'best'){
    const has = a.filter(x => comp(x).eff != null && !x.pending), rest = a.filter(x => !(comp(x).eff != null && !x.pending));
    has.sort((x, y) => ST.sort === 'worst' ? comp(x).eff - comp(y).eff : comp(y).eff - comp(x).eff);
    a = has.concat(rest);
  }
  return a;
}
function summary(list){
  const nonPend = list.filter(x => !x.pending);
  const cmp = nonPend.filter(x => perf(x));
  const c = {ok:0, warn:0, bad:0}; cmp.forEach(x => c[perf(x)]++);
  const below = cmp.filter(x => comp(x).eff < 0).length;
  const byEff = [...cmp].sort((a, b) => comp(a).eff - comp(b).eff);
  return { n: cmp.length, below, c, na: nonPend.length - cmp.length, pend: list.length - nonPend.length,
           stale: list.filter(x => x.data_status === 'stale').length,
           worst: byEff[0] && comp(byEff[0]).eff < 0 ? byEff[0] : null,
           best: byEff.length && comp(byEff[byEff.length-1]).eff >= 0 ? byEff[byEff.length-1] : null };
}

/* ===== cores por posição relativa (atual / -1 / -2) ===== */
function yearsShown(){ const ys = (DATA.campaign && DATA.campaign.years) || []; return ys.slice(-3); }
function colorOf(y){ const cur = DATA.selection.year; const d = cur - y; return d <= 0 ? 'var(--y26)' : d === 1 ? 'var(--y25)' : 'var(--y24)'; }

/* ===== cabeçalho ===== */
function renderHeader(){
  const camp = DATA && DATA.campaign, s = DATA && DATA.selection;
  const title = camp ? `${camp.label} ${s.year} · Visão Executiva` : 'Business Observability · Visão Executiva';
  $('#h-title').textContent = title; document.title = title;
  const sp = DATA ? DATA.splunk.status : 'unknown';
  const dot = SNAP ? '' : sp === 'ok' ? 'ok' : sp === 'unknown' ? '' : 'bad';
  const spTxt = SNAP ? 'Snapshot estático' : sp === 'ok' ? 'Splunk conectado' : sp === 'unknown' ? 'Splunk: verificando' :
    sp === 'configuracao' ? 'Splunk: configuração ausente' : 'Splunk: falha (' + sp + ')';
  const srcs = DATA ? Object.entries(DATA.sources || {}).map(([k, v]) => {
      const m = {ok:'ok', cached:'ok', stale:'desatualizado', error:'erro', never:'sem coleta'}[v.status] || v.status;
      return `${k.toUpperCase()} ${m}`; }).join(' · ') : '';
  const last = DATA && DATA.last_success ? dtf(DATA.last_success) : '—';
  const cut = s ? s.cutoff_label : '—';
  $('#h-meta').innerHTML = `<span><i class="dot ${dot}"></i>${esc(spTxt)}</span><span>${esc(srcs)}</span>` +
    `<span>Atualizado ${esc(last)}</span><span>Corte ${esc(cut)}</span>` +
    (DATA && DATA.collecting ? '<span><i class="spin">↻</i> coletando…</span>' : '');
  const b = $('#btn-refresh'); b.hidden = !!SNAP; b.disabled = !!(DATA && DATA.collecting);
}

/* ===== controles ===== */
function renderControls(){
  const s = DATA.selection;
  const refs = s ? s.ref_years.slice(0, 3) : [];
  $('#ctl-base').innerHTML = refs.length ? refs.map(y => `<button type="button" aria-pressed="${ST.ref===y}" data-base="${y}">vs ${y}</button>`).join('')
    : '<button type="button" disabled>sem referência</button>';
  const segs = [[SEG_ALL,'Todos'], ...(DATA.segments || []).filter(g => (DATA.indicators||[]).some(i => i.segment === g)).map(g => [g, g])];
  $('#ctl-seg').innerHTML = segs.map(([k, l]) => `<button type="button" class="chip" aria-pressed="${ST.seg===k}" data-seg="${esc(k)}">${esc(l)}</button>`).join('') +
    `<button type="button" class="chip" aria-pressed="${ST.status==='alerts'}" data-alerts="1">Só alertas</button>`;
  $('#ctl-sort').innerHTML = [['default','Padrão'],['worst','Pior variação'],['best','Melhor variação']].map(([k,l]) =>
    `<button type="button" aria-pressed="${ST.sort===k}" data-sort="${k}">${l}</button>`).join('');
  const opt = (v, l, sel) => `<option value="${esc(v)}"${sel ? ' selected' : ''}>${esc(l)}</option>`;
  const dis = SNAP ? ' disabled' : '';
  let h = '';
  h += `<label><span class="lbl">Campanha</span><select id="f-camp"${dis}>${(DATA.campaigns||[]).map(c => opt(c.id, c.label, c.id===ST.campaign)).join('')}</select></label>`;
  if (DATA.campaign){
    h += `<label><span class="lbl">Ano</span><select id="f-year"${dis}>${DATA.campaign.all_years.slice().reverse().map(y => opt(y, y, y===ST.year)).join('')}</select></label>`;
    if (s.days.length > 1) h += `<label><span class="lbl">Dia</span><select id="f-day"${dis}>${s.days.map(d => opt(d.index, dayLabel(d), d.index===ST.day)).join('')}</select></label>`;
    h += `<label><span class="lbl">Corte</span><select id="f-cut"${dis}>${opt('', 'Automático (' + s.cutoff_label + ')', !ST.cutoff)}${Array.from({length:24}, (_, i) => opt(i+1, 'até ' + String(i+1).padStart(2,'0') + 'h', ST.cutoff===i+1)).join('')}</select></label>`;
  }
  if (ST.tab === 'exec') h += `<div><span class="lbl">Fonte</span><span class="seg">${[['all','Todos'],['icn','ICN'],['solar','Solar']].map(([k,l]) => `<button type="button" aria-pressed="${ST.source===k}" data-source="${k}">${l}</button>`).join('')}</span></div>`;
  h += `<label><span class="lbl">Status</span><select id="f-status">${[['all','Todos'],['alerts','Só alertas'],['ok','Acima'],['warn','Atenção'],['bad','Crítico'],['unavailable','Sem dados / sem comparação'],['stale','Desatualizado']].map(([k,l]) => opt(k, l, ST.status===k)).join('')}</select></label>`;
  $('#ctl-adv').innerHTML = h;
}
function dayLabel(d){
  const cur = d.dates[String(ST.year)];
  const wd = cur ? new Date(cur + 'T12:00:00').toLocaleDateString('pt-BR', {weekday:'short', day:'2-digit', month:'2-digit'}) : '';
  return `Dia ${d.index + 1}${wd ? ' · ' + wd : ''}`;
}

/* ===== hero ===== */
function renderHero(){
  const el = $('#hero');
  if (!DATA.campaign){ el.innerHTML = emptyMsg(); $('#insights').hidden = true; return; }
  el.innerHTML = heroHTML(ST.source);
  renderInsights();
}
function heroHTML(source){
  const list = base(source), m = summary(list), ref = ST.ref;
  const seg = (n, col, cls) => n ? `<i class="${cls||''}" style="flex:${n};background:${col}" title="${n}"></i>` : '';
  const big = ref ? `${m.below} de ${m.n}<span>indicadores abaixo de ${ref}</span>` : `—<span>sem ano de referência disponível</span>`;
  return `
    <div class="big">${big}</div>
    <div class="stack" role="img" aria-label="${m.c.ok} acima, ${m.c.warn} em atenção, ${m.c.bad} críticos, ${m.na} sem dados">
      ${seg(m.c.ok,'var(--ok)')}${seg(m.c.warn,'var(--warn)')}${seg(m.c.bad,'var(--bad)')}${seg(m.na,'var(--y24)','na')}</div>
    <div class="legend">
      <span><i class="sw" style="background:var(--ok)"></i><b>${m.c.ok}</b> Acima</span>
      <span><i class="sw" style="background:var(--warn)"></i><b>${m.c.warn}</b> Atenção</span>
      <span><i class="sw" style="background:var(--bad)"></i><b>${m.c.bad}</b> Crítico</span>
      <span><i class="sw" style="background:var(--y24)"></i><b>${m.na}</b> Sem dados suficientes</span>
      ${m.stale ? `<span><i class="sw" style="background:var(--warn-bg);outline:1px solid var(--warn)"></i><b>${m.stale}</b> Desatualizados</span>` : ''}
      ${m.pend ? `<span><b>${m.pend}</b> Pendentes de classificação</span>` : ''}
    </div>
    <div class="hl">
      <div>Maior queda<strong>${m.worst ? esc(m.worst.name) + ' ' + pctTxt(comp(m.worst).pct) : 'Nenhum indicador abaixo da referência'}</strong></div>
      <div>Maior crescimento<strong>${m.best ? esc(m.best.name) + ' ' + pctTxt(comp(m.best).pct) : 'Nenhum acima da referência'}</strong></div>
    </div>`;
}
function emptyMsg(){
  const sp = DATA.splunk || {};
  if (SNAP) return '<div class="msg">Snapshot sem dados de campanha.</div>';
  if (sp.status === 'configuracao') return `<div class="msg"><b>Configuração do Splunk ausente.</b><br>Defina <code>COCKPIT_SOURCE_SPLUNK_BASE_URL</code> e <code>COCKPIT_SOURCE_SPLUNK_TOKEN</code> no arquivo <code>.env</code> da raiz e reinicie a aplicação.</div>`;
  if (DATA.lookup_error) return `<div class="msg"><b>Não foi possível ler o lookup de campanhas.</b><br>${esc(DATA.lookup_error)}</div>`;
  if (DATA.collecting || sp.status === 'unknown') return '<div class="msg"><i class="spin">↻</i> Coletando dados do Splunk (lookup de campanhas e consultas ICN/Solar)…</div>';
  return '<div class="msg"><b>Nenhuma campanha com janela válida</b> foi encontrada no lookup <code>comparativoDatasEspeciais.csv</code> (status=1). Nenhuma busca sem restrição temporal é executada.</div>';
}
function visibleInsights(){
  const ids = new Set(base(ST.source).map(i => i.id));
  return ((DATA.insights || {})[String(ST.ref)] || []).filter(x => x.indicator_id ? ids.has(x.indicator_id) : ST.seg === SEG_ALL);
}
function renderInsights(){
  const el = $('#insights'), ins = visibleInsights();
  el.hidden = !ins.length;
  el.innerHTML = `<h2>Principais destaques</h2><ul>${ins.map(x => `<li class="s-${esc(x.severity)}">${esc(x.text)}</li>`).join('')}</ul>`;
}

/* ===== cards ===== */
function miniBars(d){
  const ys = yearsShown(); const vals = ys.map(y => d.values_by_year[String(y)]);
  const max = Math.max(1, ...vals.filter(v => v != null).map(Math.abs));
  const w = 96, h = 46, bw = 26, gap = 8;
  let s = `<svg width="${w}" height="${h+12}" viewBox="0 0 ${w} ${h+12}" role="img" aria-label="${ys.map((y, i) => y + ': ' + fmt(vals[i], d.unit)).join(', ')}">`;
  ys.forEach((y, i) => {
    const x = i * (bw + gap) + 2 + (3 - ys.length) * (bw + gap) / 2;
    if (vals[i] == null){
      s += `<text x="${x+bw/2}" y="${h-2}" text-anchor="middle" font-size="9.5" fill="var(--ink3)">—</text>`;
    } else {
      const bh = Math.max(3, Math.abs(vals[i]) / max * (h - 12));
      s += `<rect x="${x}" y="${h-bh}" width="${bw}" height="${bh}" rx="3" fill="${colorOf(y)}"/>`;
      s += `<text x="${x+bw/2}" y="${h-bh-3}" text-anchor="middle" font-size="9.5" fill="var(--ink3)">${fmtK(vals[i])}</text>`;
    }
    s += `<text x="${x+bw/2}" y="${h+10}" text-anchor="middle" font-size="9.5" fill="var(--ink3)">'${String(y).slice(2)}</text>`;
  });
  return s + '</svg>';
}
function kpiHTML(d, scope){
  const open = ST.sel === d.id, c = comp(d), k = cls(d), p = perf(d);
  const pill = p ? `${ARROW(c.eff)} ${pctTxt(c.pct)} · ${LABEL[p]}` : esc(stLabel(d));
  const pillTitle = c.data_status === 'daily_reference' ? ' title="Ano de referência só tem o total do dia: a variação é calculada quando o dia atual encerrar."' : '';
  const val = d.current == null ? `<div class="val na">—</div>` : `<div class="val">${fmt(d.current, d.unit)}</div>`;
  const daily = c.basis === 'dia';
  const refTxt = d.pending ? 'sem comparação' : (ST.ref ? `vs ${ST.ref}${daily ? ' (dia inteiro)' : ''}: ${fmt(c.ref, d.unit)}${c.abs != null ? ' (' + signed(c.abs, d.unit) + ')' : ''}` : 'sem referência') +
    (c.data_status === 'daily_reference' ? ' · compara no fechamento do dia' : '');
  const tags = (d.data_status === 'stale' ? '<span class="tag stale">Desatualizado</span>' : '') + (d.data_status === 'error' ? '<span class="tag err">Erro de coleta</span>' : '');
  return `<button type="button" class="card kpi s-${k}" data-id="${esc(d.id)}" data-scope="${scope}" aria-expanded="${open}" aria-controls="det-${scope}-${esc(d.id)}">
    <div class="top"><span class="nm">${esc(d.name)}${tags}</span><span class="seg-tag">${esc(d.segment)}${d.source==='solar' && d.segment!=='Solar'?' · Solar':''}</span></div>
    <div class="row">
      <div>${val}
        <div style="margin-top:7px"><span class="pill s-${k}"${pillTitle}>${pill}</span></div></div>
      ${miniBars(d)}
    </div>
    <div class="base">${refTxt} · corte ${esc(d.cutoff_label)} · atualizado ${tmf(d.last_updated)}</div>
  </button>`;
}
function renderGrid(scope, list){
  const el = $('#grid-' + scope); if (!el) return;
  if (!DATA.campaign){ el.innerHTML = scope === 'exec' ? '' : `<div class="card msg" style="grid-column:1/-1">${emptyMsg()}</div>`; return; }
  if (ST.sel && !list.find(x => x.id === ST.sel)) ST.sel = null;
  el.innerHTML = list.length ? list.map(d => kpiHTML(d, scope) + (ST.sel === d.id ? `<div class="card detail" id="det-${scope}-${esc(d.id)}"></div>` : '')).join('')
    : `<div class="card" style="padding:16px;grid-column:1/-1;color:var(--ink2)">Nenhum indicador neste filtro.</div>`;
  if (ST.sel){ const d = list.find(x => x.id === ST.sel); if (d) drawDetail(d, scope); }
}
function sumTable(scope, list){
  const el = $('#sum-' + scope); if (!el) return;
  if (!DATA.campaign || !list.length){ el.hidden = true; return; }
  el.hidden = false;
  const r = ST.ref;
  el.innerHTML = `<h2>Tabela consolidada${r ? ' · vs ' + r : ''}</h2><table><tr><th>Indicador</th><th>Segmento</th><th>Atual</th><th>Ref.</th><th>Δ abs</th><th>Δ %</th><th>Status</th><th>Corte</th><th>Atualização</th></tr>` +
    list.map(d => { const c = comp(d); return `<tr><td>${esc(d.name)}</td><td>${esc(d.segment)}</td><td>${fmt(d.current, d.unit)}</td><td>${fmt(c.ref, d.unit)}</td>
      <td class="${c.abs<0?'neg':c.abs>0?'pos':''}">${signed(c.abs, d.unit)}</td><td class="${c.pct<0?'neg':c.pct>0?'pos':''}">${pctTxt(c.pct)}</td>
      <td>${esc(stLabel(d))}</td><td>${esc(d.cutoff_label)}</td><td>${tmf(d.last_updated)}</td></tr>`; }).join('') + '</table>';
}

/* ===== detalhe: acumulado por hora + volume por hora ===== */
function drawDetail(d, scope){
  const el = $(`#det-${scope}-${CSS.escape(d.id)}`); if (!el) return;
  const ys = yearsShown().filter(y => d.series[String(y)]);
  const cur = DATA.selection.year, ref = ST.ref, c = comp(d);
  const S = {}; ys.forEach(y => S[y] = d.series[String(y)]);
  const buckets = (S[cur] || S[ys[ys.length-1]] || []).map(p => p.bucket);
  const showVol = d.aggregation === 'sum' && !d.pending;
  const at = (y, b, k) => { const p = (S[y] || []).find(q => q.bucket === b); return p ? p[k] : null; };
  const srcTxt = d.source === 'icn' ? 'Splunk · index=icn · sourcetype=' + d.match : 'Splunk · index=solar · query';
  const agg = {sum:'soma', last:'último valor', max:'máximo', min:'mínimo', avg:'média'}[d.aggregation] || 'não classificada';
  const notes = (d.notes || []).concat(c.data_status && c.data_status !== 'ok' ? [LABEL[c.data_status] + ' para ' + ref + '.'] : []);
  const intens = c.intensification_from != null ? ` Intensificação do desvio a partir das ${hh(c.intensification_from)}.` : '';
  el.innerHTML = `<h3>${esc(d.name)}: acumulado por hora</h3>
    <div class="sub">${esc(srcTxt)} · agregação: ${agg} · corte ${esc(d.cutoff_label)} · última atualização ${dtf(d.last_updated)}.${intens} Toque ou passe o dedo no gráfico.</div>
    ${notes.length ? `<div class="notes">${notes.map(esc).join(' ')}</div>` : ''}
    ${buckets.length ? `<div class="lg">${ys.slice().reverse().map(y => `<span><i class="sw" style="background:${colorOf(y)}"></i>${y}</span>`).join('')}</div>
    <div class="chartbox" data-k="cum"><svg></svg><div class="tip"></div></div>
    ${showVol ? `<h3 style="margin-top:12px">Volume por hora</h3><div class="chartbox" data-k="vol"><svg></svg><div class="tip"></div></div>` : ''}
    <details class="tblx"><summary>Ver como tabela</summary><div class="tbl"><table><tr><th>Hora</th>${ys.map(y => `<th>${y}</th>`).join('')}${showVol ? `<th>Vol. ${cur}</th>` : ''}${ref && !d.pending ? `<th>Δ abs vs ${ref}</th><th>Δ % vs ${ref}</th>` : ''}</tr>
    ${buckets.map(b => { const t = (c.timeline || []).find(x => x.bucket === b) || {};
      return `<tr><td>até ${hh(b)}</td>${ys.map(y => `<td>${fmt(at(y, b, 'cum'), d.unit)}</td>`).join('')}${showVol ? `<td>${fmt(at(cur, b, 'vol'), d.unit)}</td>` : ''}${ref && !d.pending ? `<td class="${t.abs<0?'neg':t.abs>0?'pos':''}">${signed(t.abs, d.unit)}</td><td class="${t.pct<0?'neg':t.pct>0?'pos':''}">${pctTxt(t.pct)}</td>` : ''}</tr>`; }).join('')}
    </table></div></details>` : '<div class="msg">Sem pontos horários para exibir.</div>'}`;
  if (!buckets.length) return;
  chart(el.querySelector('[data-k=cum]'), d, ys, buckets, b => Object.fromEntries(ys.map(y => [y, at(y, b, 'cum')])), 'line', c);
  if (showVol) chart(el.querySelector('[data-k=vol]'), d, ys, buckets, b => Object.fromEntries(ys.map(y => [y, at(y, b, 'vol')])), 'bars', null);
}
function niceMax(v){ if (!(v > 0)) return 4; const raw = v / 4, p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p; return Math.max(4, (f<=1?1:f<=2?2:f<=2.5?2.5:f<=5?5:10) * p * 4); }
function chart(box, d, ys, buckets, get, kind, c){
  const svg = box.querySelector('svg'), tip = box.querySelector('.tip');
  const W = Math.max(280, box.clientWidth || 600), H = kind === 'bars' ? 150 : 200, m = {l:42, r:14, t:10, b:24};
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  const vals = buckets.flatMap(b => Object.values(get(b))).filter(v => v != null);
  const minV = Math.min(0, ...vals), top = niceMax(Math.max(...vals, 0) * 1.08);
  const n = buckets.length;
  const slot = (W - m.l - m.r) / Math.max(1, kind === 'bars' ? n : n - 1);
  const X = i => kind === 'bars' ? m.l + slot * (i + .5) : m.l + (n === 1 ? (W - m.l - m.r) / 2 : i * slot);
  const Y = v => H - m.b - (v - minV) / (top - minV) * (H - m.t - m.b);
  let g = '';
  for (let i = 0; i <= 4; i++){ const v = minV + (top - minV) * i / 4, y = Y(v);
    g += `<line x1="${m.l}" x2="${W-m.r}" y1="${y}" y2="${y}" stroke="var(--grid)"/><text x="${m.l-6}" y="${y+3.5}" text-anchor="end" font-size="10" fill="var(--ink3)">${fmtK(v)}</text>`; }
  const step = n > 12 ? 3 : n > 6 ? 2 : 1;
  buckets.forEach((b, i) => { if (i % step === 0 || i === n - 1) g += `<text x="${X(i)}" y="${H-6}" text-anchor="middle" font-size="10" fill="var(--ink3)">${kind === 'bars' ? b : b+1}h</text>`; });
  const cur = DATA.selection.year;
  if (kind === 'line'){
    ys.forEach(y => {
      let seg = [], segs = [];
      buckets.forEach((b, i) => { const v = get(b)[y]; if (v == null){ if (seg.length) segs.push(seg); seg = []; } else seg.push(X(i) + ',' + Y(v)); });
      if (seg.length) segs.push(seg);
      segs.forEach(sg => g += `<polyline fill="none" stroke="${colorOf(y)}" stroke-width="${y===cur?2.5:2}" stroke-linejoin="round" stroke-linecap="round" points="${sg.join(' ')}"/>`);
      const lv = get(buckets[n-1])[y];
      if (lv != null) g += `<circle cx="${X(n-1)}" cy="${Y(lv)}" r="4" fill="${colorOf(y)}" stroke="var(--surface)" stroke-width="2"/>`;
    });
  } else {
    const bw = Math.max(2, Math.min(14, slot * .8 / ys.length));
    buckets.forEach((b, i) => ys.forEach((y, j) => { const v = get(b)[y]; if (v == null) return;
      const x = X(i) - bw * ys.length / 2 + j * bw; g += `<rect x="${x}" y="${Math.min(Y(v), Y(0))}" width="${bw - 1}" height="${Math.max(1, Math.abs(Y(0) - Y(v)))}" rx="1.5" fill="${colorOf(y)}"/>`; }));
  }
  g += `<line class="xh" y1="${m.t}" y2="${H-m.b}" stroke="var(--ink3)" stroke-dasharray="3 3" opacity="0"/><g class="dots"></g>`;
  svg.innerHTML = g;
  const xh = svg.querySelector('.xh'), dots = svg.querySelector('.dots');
  function show(ev){
    const r = svg.getBoundingClientRect(); const px = (ev.clientX - r.left) / r.width * W;
    let i = kind === 'bars' ? Math.floor((px - m.l) / slot) : Math.round((px - m.l) / (slot || 1));
    i = Math.max(0, Math.min(n - 1, i)); const b = buckets[i], v = get(b);
    xh.setAttribute('x1', X(i)); xh.setAttribute('x2', X(i)); xh.setAttribute('opacity', 1);
    dots.innerHTML = kind === 'line' ? ys.filter(y => v[y] != null).map(y => `<circle cx="${X(i)}" cy="${Y(v[y])}" r="4.5" fill="${colorOf(y)}" stroke="var(--surface)" stroke-width="2"/>`).join('') : '';
    const t = c && (c.timeline || []).find(x => x.bucket === b);
    tip.innerHTML = `<b>${kind === 'line' ? 'até ' + hh(b) : String(b).padStart(2,'0') + 'h–' + hh(b)}</b><br>` +
      ys.slice().reverse().map(y => `${y}: ${fmt(v[y], d.unit)}`).join('<br>') + (t && t.pct != null ? `<br>Δ vs ${ST.ref}: ${pctTxt(t.pct)}` : '');
    tip.style.opacity = 1;
    const tw = tip.offsetWidth, left = Math.min(Math.max(0, X(i) / W * r.width + 10), r.width - tw);
    tip.style.left = left + 'px'; tip.style.top = '6px';
  }
  function hide(){ xh.setAttribute('opacity', 0); dots.innerHTML = ''; tip.style.opacity = 0; }
  svg.addEventListener('pointermove', show); svg.addEventListener('pointerdown', show); svg.addEventListener('pointerleave', hide);
}

/* ===== render geral ===== */
function render(){
  if (!DATA) return;
  renderHeader();
  const dataTab = ST.tab !== 'dados';
  $('#v-filters').hidden = !dataTab || !DATA.campaign; $('#v-actions').hidden = !dataTab || !DATA.campaign;
  if (DATA.campaign) renderControls();
  if (ST.tab === 'exec'){ renderHero(); renderGrid('exec', visible(ST.source)); }
  if (ST.tab === 'icn'){ const l = visible('icn'); renderGrid('icn', l); sumTable('icn', l); }
  if (ST.tab === 'solar'){
    const l = visible('solar'); renderGrid('solar', l); sumTable('solar', l.filter(x => !x.pending));
    const n = $('#solar-note'), pend = (DATA.indicators || []).filter(x => x.source === 'solar' && x.pending).length;
    const st = (DATA.sources || {}).solar || {};
    const zero = st.status === 'ok' && st.rows === 0;
    n.hidden = !(pend || zero || st.status === 'error' || st.status === 'stale');
    n.textContent = (st.status === 'error' ? 'Falha na coleta Solar: ' + (st.error || '') + ' ' : st.status === 'stale' ? 'Última coleta Solar falhou; exibindo o último resultado válido. ' : '') +
      (zero ? 'A busca Solar foi executada sem erro, mas retornou 0 registros nas janelas da campanha. Causas prováveis: o usuário do token não tem acesso ao index=solar (o Splunk retorna vazio, sem erro) ou o sourcetype/campos são diferentes. O diagnóstico automático está na aba Modelo de Dados, seção 9. ' : '') +
      (pend ? `${pend} indicador(es) Solar pendente(s) de classificação semântica: exibidos sem comparação nem status. Classifique-os em config/indicators.json (ver aba Modelo de Dados).` : '');
  }
  if (ST.tab === 'dados') renderModel();
  $('#print-head').innerHTML = DATA.campaign ? `<p style="font-size:12px;color:var(--ink3)">Relatório gerado em ${dtf(DATA.generated_at)} · comparativo com ${ST.ref || '—'} · fonte: Splunk (ICN e Solar) · CoEE AIOps</p>` : '';
  $('#foot').textContent = 'Fonte: Splunk — ICN (index=icn) e Solar (index=solar), janelas do lookup comparativoDatasEspeciais.csv. ' +
    'Variação = (atual − referência) ÷ referência, no mesmo dia relativo da campanha e no mesmo horário de corte de cada indicador. ' +
    'Status: Acima ≥ 0%, Atenção entre 0% e −10%, Crítico ≤ −10% (configurável por indicador). CoEE AIOps.';
}

/* ===== Modelo de Dados ===== */
async function renderModel(){
  const el = $('#v-dados');
  if (!SNAP && !MODEL){ el.innerHTML = '<div class="msg">Carregando…</div>'; try { MODEL = await api('/api/model'); } catch(e){ el.innerHTML = '<div class="msg">Falha ao carregar o modelo de dados.</div>'; return; } }
  const inds = (DATA && DATA.indicators) || [];
  const camp = DATA && DATA.campaign;
  let h = '';
  h += `<h2>1. Fontes e fluxo</h2><p>Splunk (API REST, somente leitura) → conector no backend local → normalização → motor de indicadores → cache SQLite → API REST local → este painel. O navegador nunca acessa o Splunk nem recebe credenciais.</p>
  <ul><li><b>ICN</b>: <code>index=icn</code>, 8 sourcetypes de vendas e ativações, soma de <code>QUANTIDADE</code> por hora (variante horária da consulta original).</li>
  <li><b>Solar</b>: <code>index=solar sourcetype="queries*SOQL"</code>, campos <code>query</code> e <code>value</code>. <code>start</code> é a data de negócio (define o dia da campanha) e cada medição é posicionada na hora em que foi recebida (variante horária da consulta original), para comparar o acumulado do dia no mesmo horário entre os anos.</li>
  <li><b>Janelas</b>: lookup <code>comparativoDatasEspeciais.csv</code> (<code>status=1</code>, <code>periodo</code>, <code>inicio</code>, <code>fim</code>). Sem janela válida, nenhuma busca é executada.</li></ul>`;
  if (camp) h += `<div class="kv"><div>Campanha<strong>${esc(camp.label)} (${esc(camp.id)})</strong></div><div>Anos com janela<strong>${camp.all_years.join(', ')}</strong></div><div>Fuso<strong>${esc(DATA.timezone)}</strong></div><div>Corte efetivo<strong>${esc(DATA.selection.cutoff_label)}</strong></div><div>Último horário fechado (relógio)<strong>${esc(DATA.selection.clock_cutoff_label || '—')}</strong></div></div>` +
    (camp.issues && camp.issues.length ? `<div class="note">${camp.issues.map(esc).join('<br>')}</div>` : '');
  h += `<h2>2. Regras de cálculo</h2><ul>
   <li>Bucket horário local [h:00, h+1:00). “Corte 09h” = acumulado de 00h até 09h (buckets 0–8).</li>
   <li>Último horário completo: hora encerrada <b>e</b> já totalmente ingerida (passou o tempo típico de fechamento medido na seção 7, ou já chegaram dados da hora seguinte). Cada indicador usa como corte a sua última hora completa (corte individual), e os anos de referência são lidos no <b>mesmo corte</b> e no <b>mesmo dia relativo</b> da campanha.</li>
   <li>Janelas do lookup fixadas no fuso da aplicação (${esc(DATA.timezone)}), independentemente do fuso do usuário do token no Splunk.</li>
   <li>Variação % = (atual − referência) ÷ referência × 100. Variação absoluta = atual − referência.</li>
   <li>Referência = 0: variação % não aplicável. Sem dado: “sem dados” (nunca substituído por zero). Referência que não alcança o corte: “referência parcial” (sem classificação). Nada é interpolado ou estimado.</li>
   <li>Desatualizado: só quando a coleta da fonte falha e o painel exibe o último resultado válido. O alerta por idade dos dados está desativado (<code>stale_after_minutes = 0</code>; pode ser reativado por indicador).</li></ul>
  <h2>3. Classificação</h2><ul><li><b>Acima</b>: variação ≥ 0% · <b>Atenção</b>: entre 0% e −10% · <b>Crítico</b>: ≤ −10%. Limites por indicador em <code>config/indicators.json</code>.</li>
   <li>Para indicadores em que menor é melhor (<code>direction=lower_is_better</code>), a variação é invertida antes de classificar.</li>
   <li>A classificação compara com o histórico; não indica falha técnica.</li></ul>
  <h2>4. Catálogo de indicadores</h2><div class="card tbl"><table><tr><th>Indicador</th><th>Fonte</th><th>Chave</th><th>Segmento</th><th>Unidade</th><th>Agregação</th><th>Natureza</th><th>Direção</th><th>Validado</th></tr>
   ${inds.map(i => `<tr><td>${esc(i.name)}</td><td>${esc(i.source.toUpperCase())}</td><td><code>${esc((i.match||'').slice(0,40))}</code></td><td>${esc(i.segment)}</td><td>${esc(i.unit||'—')}</td><td>${esc(i.aggregation||'pendente')}</td><td>${esc(i.nature||'—')}</td><td>${i.direction==='lower_is_better'?'menor é melhor':i.direction?'maior é melhor':'—'}</td><td>${i.pending?'pendente':i.validated?'sim':'a validar'}</td></tr>`).join('')}</table></div>
  <h2>5. Qualidade dos dados</h2><div class="card tbl"><table><tr><th>Indicador</th><th>Status dos dados</th><th>Corte</th><th>Última atualização</th><th>Observações</th></tr>
   ${inds.map(i => `<tr><td>${esc(i.name)}</td><td>${esc(DATA_LABEL[i.data_status]||i.data_status)}</td><td>${esc(i.cutoff_label)}</td><td>${dtf(i.last_updated)}</td><td>${esc((i.notes||[]).join(' '))}</td></tr>`).join('')}</table></div>`;
  if (SNAP){ el.innerHTML = h + `<p>Snapshot exportado em ${dtf(DATA.generated_at)}. Seção técnica omitida.</p>`; return; }
  const M = MODEL, S = M.settings, cnt = M.metrics.counters, cs = M.collections_24h || {};
  h += `<h2>6. Integração Splunk</h2><div class="kv"><div>Host<strong>${esc(S.splunk_host||'—')}</strong></div><div>Configurado<strong>${S.splunk_configured?'sim':'não: '+esc(S.missing.join(', '))}</strong></div><div>Autenticação<strong>${esc(S.auth_scheme)}</strong></div><div>Contexto de app<strong>${esc(S.app_context)}</strong></div><div>TLS<strong>validado${S.custom_ca_bundle?' (CA corporativa)':''}</strong></div><div>Coleta automática<strong>${S.refresh_interval_s>0?'a cada '+Math.round(S.refresh_interval_s/60)+' min':'desativada'}</strong></div><div>Timeout / retries<strong>${S.query_timeout_s}s / ${S.max_retries}</strong></div><div>Buscas simultâneas<strong>${S.max_concurrent_searches}</strong></div></div>
  <p>Endpoints: <code>POST /services/search/jobs</code>, <code>GET /services/search/jobs/{sid}</code>, <code>GET /services/search/jobs/{sid}/results</code> (paginado). Uma busca consolidada por fonte e ciclo; os filtros reutilizam o cache.</p>
  <h2>7. Observabilidade da aplicação</h2><div class="kv">${['icn','solar'].map(s => { const c = cs[s] || {}; const st = (DATA.sources||{})[s] || {};
     return `<div>${s.toUpperCase()} · status<strong>${esc(st.status||'—')}</strong></div><div>${s.toUpperCase()} · sucesso 24h<strong>${c.success_rate!=null?Math.round(c.success_rate*100)+'% ('+c.success+'/'+c.attempts+')':'—'}</strong></div><div>${s.toUpperCase()} · tempo médio<strong>${c.avg_duration_ms!=null?(c.avg_duration_ms/1000).toFixed(1)+' s':'—'}</strong></div><div>${s.toUpperCase()} · registros / idade<strong>${st.rows!=null?nf0.format(st.rows):'—'} / ${st.data_age_s!=null?Math.round(st.data_age_s/60)+' min':'—'}</strong></div>`; }).join('')}
   <div>Ciclos de coleta<strong>${cnt.refresh_cycles||0}</strong></div><div>Uso do cache<strong>${cnt.cache_hit_ratio!=null?Math.round(cnt.cache_hit_ratio*100)+'%':'—'}</strong></div><div>Erros de normalização<strong>${cnt.normalization_errors||0}</strong></div><div>Indicadores processados<strong>${inds.length}</strong></div></div>
   ${(DATA.sources && Object.entries(DATA.sources).filter(([,v]) => v.error).map(([k,v]) => `<div class="note">${k.toUpperCase()}: ${esc(v.error)}</div>`).join('')) || ''}
   <div class="card tbl"><table><tr><th>Busca recente</th><th>Resultado</th><th>Duração</th><th>Registros</th><th>Horário</th></tr>${(M.metrics.recent_queries||[]).slice(0,12).map(q => `<tr><td>${esc(q.label)}</td><td>${q.ok?'ok':esc(q.error)}</td><td>${(q.duration_ms/1000).toFixed(1)} s</td><td>${q.rows!=null?nf0.format(q.rows):'—'}</td><td>${tmf(q.at)}</td></tr>`).join('') || '<tr><td colspan="5">Nenhuma busca nesta execução.</td></tr>'}</table></div>`;
  const ing = M.icn_ingestion || [];
  if (ing.length) h += `<p><b>Atraso de ingestão ICN</b> (últimas 3 horas com dados). <i>Atraso do evento</i> = _indextime − _time; <i>fecha após a hora</i> = quanto tempo depois do fim de cada hora chegou o último dado dela. Um horário só entra na comparação depois desse tempo de fechamento, ou quando já chegaram dados de um horário posterior.</p><div class="card tbl"><table><tr><th>Sourcetype</th><th>Último evento</th><th>Atraso médio do evento</th><th>Atraso máximo do evento</th><th>Fecha após a hora</th></tr>${ing.map(r => `<tr><td>${esc(r.key)}</td><td>${dtf(r.last_event)}</td><td>${r.lag_avg_min != null ? nf2.format(r.lag_avg_min) + ' min' : '—'}</td><td>${r.lag_max_min != null ? nf2.format(r.lag_max_min) + ' min' : '—'}</td><td>${r.close_lag_min != null ? nf2.format(r.close_lag_min) + ' min' : '—'}</td></tr>`).join('')}</table></div>`;
  const norm = M.normalization || {};
  const nk = Object.keys(norm).filter(k => Object.keys(norm[k][0] || {}).length);
  if (nk.length) h += `<div class="card tbl"><table><tr><th>Fonte</th><th>Erros de normalização (por tipo)</th><th>Amostras</th></tr>${nk.map(k => `<tr><td>${k.toUpperCase()}</td><td style="text-align:left">${Object.entries(norm[k][0]).map(([t, n]) => esc(t) + ': ' + n).join('<br>')}</td><td style="text-align:left"><code>${(norm[k][1] || []).map(esc).join('<br>')}</code></td></tr>`).join('')}</table></div>`;
  const rec = M.reconciliation;
  h += `<h2>8. Reconciliação ICN (consulta original × variante horária)</h2>` + (rec ? `<p>${esc(rec.note)} Última execução: ${dtf(rec.at)}.</p><div class="card tbl"><table><tr><th>Sourcetype</th><th>Ano</th><th>Original</th><th>Horária</th><th>Dif.</th></tr>${rec.items.map(r => `<tr><td>${esc(r.key)}</td><td>${esc(r.year)}</td><td>${fmt(r.original,'quantidade')}</td><td>${fmt(r.hourly,'quantidade')}</td><td class="${r.ok?'pos':'neg'}">${r.diff_pct!=null?pctTxt(r.diff_pct):'n/a'}</td></tr>`).join('')}</table></div>` : '<p>Ainda não executada.</p>');
  const prof = M.solar_profile;
  const sd = M.solar_diagnosis;
  h += `<h2>9. Perfil dos indicadores Solar (apoio à classificação)</h2>` +
    (sd ? `<div class="note"><b>Diagnóstico automático (busca Solar sem resultados, ${tmf(sd.at)}):</b> ${esc(sd.conclusion)}${(sd.details || []).length ? '<br>' + sd.details.map(esc).join('<br>') : ''}</div>` : '') +
    (prof && prof.length ? `<div class="card tbl"><table><tr><th>query</th><th>Pontos</th><th>Anos</th><th>Intervalo típico</th><th>Mín–Máx</th><th>Dias monotônicos</th><th>Sugestão (não aplicada)</th></tr>${prof.map(p => `<tr><td><code>${esc(p.key.slice(0,60))}</code></td><td>${p.points}</td><td>${p.years.join(', ')}</td><td>${p.typical_interval_s!=null?Math.round(p.typical_interval_s/60)+' min':'—'}</td><td>${fmt(p.min)}–${fmt(p.max)}</td><td>${esc(p.monotonic_days)}</td><td style="text-align:left">${esc(p.hint)}</td></tr>`).join('')}</table></div>` : '<p>Sem dados Solar coletados.</p>');
  h += `<h2>10. Consultas SPL (arquivos em <code>queries/</code>)</h2>` + Object.entries(M.queries).map(([k, q]) => `<p><b>${esc(k)}</b></p><pre>${esc(q)}</pre>`).join('');
  el.innerHTML = h;
}

/* ===== reporte / exportações ===== */
function toast(msg){ $('#toast').textContent = msg; clearTimeout(toast.t); toast.t = setTimeout(() => $('#toast').textContent = '', 5000); }
function copiarLegado(texto){
  // execCommand funciona em http (contexto não seguro), onde navigator.clipboard é bloqueado
  const t = document.createElement('textarea');
  t.value = texto; t.setAttribute('readonly', ''); t.style.position = 'fixed'; t.style.top = '-1000px'; t.style.opacity = '0'; t.style.display = 'block'; // app.css oculta textarea por padrão
  const prev = document.activeElement;
  document.body.appendChild(t); t.focus(); t.select(); t.setSelectionRange(0, texto.length);
  let ok = false; try { ok = document.execCommand('copy'); } catch(e){}
  t.remove(); if (prev && prev.focus) prev.focus(); return ok;
}
async function copiar(texto, okMsg){
  let ok = false;
  if (navigator.clipboard && window.isSecureContext){ try { await navigator.clipboard.writeText(texto); ok = true; } catch(e){} }
  if (!ok) ok = copiarLegado(texto);
  if (ok){ toast(okMsg); $('#ta').style.display = 'none'; return; }
  const ta = $('#ta'); ta.value = texto; ta.style.display = 'block'; ta.focus(); ta.select();
  toast('Não foi possível copiar automaticamente: selecione o texto abaixo e copie.');
}
async function reportText(style){
  if (SNAP) return SNAP.report_text;
  const r = await api('/api/reports/executive?' + qs(Object.assign(filterParams(), {style})));
  return r.text;
}
function download(url){ const a = document.createElement('a'); a.href = url; a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove(); }
/* PNG no formato do painel: monta a visão (cabeçalho, filtros, resumo e cards) com o CSS e os componentes
   da própria página, em 980 px e tema claro, e rasteriza via SVG foreignObject (sem bibliotecas externas). */
async function asDataURL(url){
  if (url.startsWith('data:')) return url;
  const b = await (await fetch(url)).blob();
  return new Promise((ok, ko) => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.onerror = ko; fr.readAsDataURL(b); });
}
function pageCSS(){
  let t = '';
  for (const sh of document.styleSheets){ try { for (const r of sh.cssRules) t += r.cssText + '\n'; } catch(e){} }
  return t;
}
const PNG_CSS = '.pngx .grid{grid-template-columns:repeat(3,minmax(0,1fr))!important}.pngx .hl{grid-template-columns:1fr 1fr!important}' +
  '.pngx nav{position:static}.pngx .kpi[aria-expanded=true]{outline:0}.pngx section{padding:12px 12px 0}';
async function exportPNGPanel(){
  const W = 980, src = tabSource(), list = visible(src), s = DATA.selection;
  const logo = await asDataURL($('.coe img').src);
  const prevSel = ST.sel; ST.sel = null;
  const cards = list.map(d => kpiHTML(d, 'png')).join('');
  ST.sel = prevSel;
  const segs = [[SEG_ALL, 'Todos'], ...(DATA.segments || []).filter(g => (DATA.indicators || []).some(i => i.segment === g)).map(g => [g, g])];
  const tabs = [['exec', 'Visão Executiva'], ['icn', 'Vendas e Ativações · ICN'], ['solar', 'Indicadores de Negócio · Solar'], ['dados', 'Modelo de Dados']];
  const segBtn = (on, l) => `<button type="button" aria-pressed="${on}">${esc(l)}</button>`;
  const html = `<div class="wrap pngx" style="width:${W}px;max-width:none;margin:0;padding:0 0 16px;background:var(--bg);color:var(--ink);font:15px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif">
    <header><div><h1>${esc($('#h-title').textContent)}</h1>
      <p>Vendas, ativações e indicadores de negócio · mesmo horário vs anos anteriores · atualizado ${esc(dtf(DATA.last_success || DATA.generated_at))}</p></div>
      <div class="coe"><img alt="CoEE AIOps" src="${logo}"/></div></header>
    <nav>${tabs.map(([k, l]) => `<button type="button" aria-selected="${ST.tab === k}">${esc(l)}</button>`).join('')}</nav>
    <section>
      <div class="ctrl">
        <div><span class="lbl">Comparar com</span> <span class="seg">${s.ref_years.slice(0, 3).map(y => segBtn(ST.ref === y, 'vs ' + y)).join('')}</span></div>
        <div class="chips">${segs.map(([k, l]) => `<button type="button" class="chip" aria-pressed="${ST.seg === k}">${esc(l)}</button>`).join('')}<button type="button" class="chip" aria-pressed="${ST.status === 'alerts'}">Só alertas</button></div>
        <div><span class="lbl">Ordem</span> <span class="seg">${[['default', 'Padrão'], ['worst', 'Pior variação'], ['best', 'Melhor variação']].map(([k, l]) => segBtn(ST.sort === k, l)).join('')}</span></div>
      </div>
      <div class="card hero">${heroHTML(src)}</div>
      <div class="grid">${cards || '<div class="card msg" style="grid-column:1/-1">Nenhum indicador neste filtro.</div>'}</div>
      <div class="foot">Fonte: Splunk — ICN e Solar · comparativo com ${esc(ST.ref || '—')} no mesmo horário de corte de cada indicador · CoEE AIOps</div>
    </section></div>`;
  // mede a altura real com o mesmo CSS (fora da tela)
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;left:-20000px;top:0;width:' + W + 'px';
  host.innerHTML = '<style>' + PNG_CSS + '</style>' + html;
  document.body.appendChild(host);
  const el = host.querySelector('.pngx');
  const H = Math.ceil(el.getBoundingClientRect().height);
  const xhtml = new XMLSerializer().serializeToString(el);
  host.remove();
  const css = (pageCSS() + PNG_CSS).replace(/]]>/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" data-theme="light"><style><![CDATA[${css}]]></style>` +
    `<foreignObject x="0" y="0" width="${W}" height="${H}">${xhtml}</foreignObject></svg>`;
  const img = new Image();
  await new Promise((ok, ko) => { img.onload = ok; img.onerror = () => ko(new Error('svg')); img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); });
  const cv = document.createElement('canvas'); cv.width = W * 2; cv.height = H * 2;
  const g = cv.getContext('2d'); g.scale(2, 2); g.fillStyle = '#F3F4F6'; g.fillRect(0, 0, W, H); g.drawImage(img, 0, 0, W, H);
  const blob = await new Promise(r => cv.toBlob(r, 'image/png'));   // lança SecurityError se o navegador bloquear
  if (!blob) throw new Error('toBlob');
  const u = URL.createObjectURL(blob), a = document.createElement('a');
  a.href = u; a.download = `${DATA.campaign.id}_${DATA.selection.year}_visao_executiva.png`.replace(/\s+/g, '_');
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 5000);
  toast('Imagem PNG gerada.');
}
/* alternativa (navegadores sem suporte a foreignObject em canvas): imagem em lista */
async function exportPNGLista(){
  const list = visible(tabSource()), m = summary(base(tabSource())), ins = visibleInsights().slice(0, 4);
  const W = 1080, pad = 40, rowH = 58, insH = ins.length ? 40 + ins.length * 34 : 0;
  const H = 150 + 190 + list.length * rowH + insH + 90;
  const cv = document.createElement('canvas'); cv.width = W * 2; cv.height = H * 2;
  const g = cv.getContext('2d'); g.scale(2, 2);
  const F = (w, s) => `${w} ${s}px -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`;
  const C = {claro:'#DA291C', bg:'#F3F4F6', ink:'#111827', ink2:'#4B5563', ink3:'#6B7280', line:'#E5E7EB', ok:'#157A52', okb:'#E3F4EC', warn:'#8A5300', warnb:'#FDF0D5', bad:'#B4161B', badb:'#FCE4E4', na:'#C3C7CE', nab:'#EEF0F3'};
  const rr = (x, y, w, h, r, fill) => { g.beginPath(); g.roundRect(x, y, w, h, r); g.fillStyle = fill; g.fill(); };
  g.fillStyle = C.bg; g.fillRect(0, 0, W, H);
  g.fillStyle = C.claro; g.fillRect(0, 0, W, 130);
  g.fillStyle = '#fff'; g.font = F(700, 30); g.fillText($('#h-title').textContent, pad, 56);
  g.font = F(400, 18); g.globalAlpha = .92;
  g.fillText(`Vendas, ativações e indicadores de negócio · atualizado ${dtf(DATA.last_success || DATA.generated_at)} · corte ${DATA.selection.cutoff_label}`, pad, 90);
  g.globalAlpha = 1;
  const img = $('.coe img');
  if (img && img.complete){ const ih = 56, iw = img.naturalWidth / img.naturalHeight * ih; rr(W - pad - iw - 18, 30, iw + 18, ih + 14, 12, '#fff'); g.drawImage(img, W - pad - iw - 9, 37, iw, ih); }
  let y = 150;
  rr(pad, y, W - 2*pad, 170, 16, '#fff');
  g.fillStyle = C.ink; g.font = F(800, 52); const big = ST.ref ? `${m.below} de ${m.n}` : '—'; g.fillText(big, pad + 22, y + 66);
  const bw = g.measureText(big).width; g.font = F(600, 20); g.fillStyle = C.ink2; g.fillText(ST.ref ? `indicadores abaixo de ${ST.ref}` : 'sem referência', pad + 32 + bw, y + 66);
  const tot = m.c.ok + m.c.warn + m.c.bad + m.na; let x = pad + 22; const sw = W - 2*pad - 44;
  [[m.c.ok, C.ok], [m.c.warn, C.warn], [m.c.bad, C.bad], [m.na, C.na]].forEach(([n, col]) => { if (!n) return; const w = sw * n / tot - 3; rr(x, y + 90, w, 14, 4, col); x += w + 3; });
  g.font = F(500, 17); g.fillStyle = C.ink2;
  g.fillText(`${m.c.ok} Acima   ·   ${m.c.warn} Atenção   ·   ${m.c.bad} Crítico   ·   ${m.na} Sem dados${m.stale ? '   ·   ' + m.stale + ' Desatualizados' : ''}`, pad + 22, y + 140);
  y += 190;
  list.forEach(d => {
    const c = comp(d), p = perf(d), k = cls(d);
    rr(pad, y, W - 2*pad, rowH - 8, 12, '#fff');
    g.fillStyle = p ? C[p] : C.na; g.fillRect(pad, y, 6, rowH - 8);
    g.fillStyle = C.ink; g.font = F(600, 19); g.fillText(d.name, pad + 22, y + 31);
    g.fillStyle = C.ink3; g.font = F(400, 15); g.fillText(d.segment + ' · corte ' + d.cutoff_label, pad + 380, y + 31);
    g.fillStyle = C.ink; g.font = F(800, 22); g.textAlign = 'right'; g.fillText(fmt(d.current, d.unit), W - pad - 210, y + 33);
    const label = p ? `${ARROW(c.eff)} ${pctTxt(c.pct)}` : stLabel(d);
    g.font = F(700, 16); const lw = g.measureText(label).width + 22;
    rr(W - pad - 16 - lw, y + 12, lw, 28, 14, p ? C[p + 'b'] : C.nab); g.fillStyle = p ? C[p] : C.ink2; g.fillText(label, W - pad - 27, y + 32);
    g.textAlign = 'left'; y += rowH;
  });
  if (ins.length){
    y += 8; g.fillStyle = C.ink; g.font = F(700, 19); g.fillText('Principais destaques', pad, y + 20); y += 34;
    g.font = F(400, 16); ins.forEach(t => { g.fillStyle = C[t.severity] || C.ink3; g.beginPath(); g.arc(pad + 5, y + 10, 5, 0, 7); g.fill();
      g.fillStyle = C.ink2; let s = t.text; while (g.measureText(s).width > W - 2*pad - 24 && s.length > 10) s = s.slice(0, -2); g.fillText(s === t.text ? s : s + '…', pad + 18, y + 16); y += 34; });
  }
  g.fillStyle = C.ink3; g.font = F(400, 14);
  g.fillText(`Comparativo: mesmo período de ${ST.ref || '—'} · Fonte: Splunk — ICN e Solar · CoEE AIOps`, pad, H - 34);
  cv.toBlob(b => { const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u;
    a.download = `${DATA.campaign.id}_${DATA.selection.year}_visao_executiva.png`; a.click(); setTimeout(() => URL.revokeObjectURL(u), 5000); toast('Imagem PNG gerada.'); }, 'image/png');
}

/* ===== eventos ===== */
function refetch(){ ST.sel = null; MODEL = null; load(); }
document.addEventListener('click', async e => {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.base){ ST.ref = +b.dataset.base; render(); }
  else if (b.dataset.seg){ ST.seg = b.dataset.seg; render(); }
  else if (b.dataset.alerts){ ST.status = ST.status === 'alerts' ? 'all' : 'alerts'; render(); }
  else if (b.dataset.sort){ ST.sort = b.dataset.sort; render(); }
  else if (b.dataset.source){ ST.source = b.dataset.source; render(); }
  else if (b.dataset.id){ ST.sel = ST.sel === b.dataset.id ? null : b.dataset.id; render(); }
  else if (b.dataset.tab){ setTab(b.dataset.tab); }
  else if (b.id === 'btn-refresh'){
    b.disabled = true;
    try { const r = await api('/api/refresh?' + new URLSearchParams(ST.campaign ? {campaign: ST.campaign} : {}), {method:'POST'});
      toast(r.status === 'running' ? 'Já existe uma coleta em andamento.' : 'Coleta iniciada no Splunk…'); }
    catch(err){ toast('Falha ao solicitar coleta: ' + err.message); }
    MODEL = null; setTimeout(load, 1200);
  }
  else if (b.id === 'btn-theme'){ cycleTheme(); }
  else if (b.id === 'btn-wa' || b.id === 'btn-teams'){
    try { const t = await reportText(b.id === 'btn-wa' ? 'whatsapp' : 'teams'); copiar(t, `Resumo copiado. Cole no ${b.id === 'btn-wa' ? 'WhatsApp' : 'Teams'}.`); }
    catch(err){ toast('Falha ao gerar resumo: ' + err.message); }
  }
  else if (b.id === 'btn-pdf'){ toast('Use “Salvar como PDF” na janela de impressão.'); setTimeout(() => window.print(), 300); }
  else if (b.id === 'btn-png'){ try { await exportPNGPanel(); } catch(err){ try { await exportPNGLista(); } catch(e2){ toast('Falha ao gerar PNG.'); } } }
  else if (b.id === 'btn-csv'){ if (SNAP) return toast('Exportação CSV indisponível no snapshot.'); download('/api/export/csv?' + qs(filterParams())); }
  else if (b.id === 'btn-html'){ if (SNAP) return toast('Este arquivo já é um snapshot.'); download('/api/export/html?' + qs(filterParams())); toast('Snapshot HTML gerado (sem credenciais).'); }
});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.id === 'f-camp'){ ST.campaign = t.value; ST.year = null; ST.day = null; ST.ref = null; ST.cutoff = null; refetch(); }
  else if (t.id === 'f-year'){ ST.year = +t.value; ST.day = null; ST.ref = null; refetch(); }
  else if (t.id === 'f-day'){ ST.day = +t.value; refetch(); }
  else if (t.id === 'f-cut'){ ST.cutoff = t.value ? +t.value : null; refetch(); }
  else if (t.id === 'f-status'){ ST.status = t.value; render(); }
});
function setTab(t){
  ST.tab = t; ST.sel = null;
  ['exec','icn','solar','dados'].forEach(k => { $('#v-' + k).hidden = k !== t; $('#t-' + k).setAttribute('aria-selected', k === t); });
  try { history.replaceState(null, '', '#' + t); } catch(e){}
  render();
}
const THEMES = ['auto', 'light', 'dark'];
function applyTheme(t){ if (t === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', t);
  $('#btn-theme').textContent = ({auto:'Tema: automático', light:'Tema: claro', dark:'Tema: escuro'}[t]); }
function cycleTheme(){ let t = 'auto'; try { t = localStorage.getItem('bf-theme') || 'auto'; } catch(e){}
  t = THEMES[(THEMES.indexOf(t) + 1) % 3]; try { localStorage.setItem('bf-theme', t); } catch(e){} applyTheme(t); render(); }
let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { if (ST.sel) render(); }, 150); });

(function init(){
  let t = 'auto'; try { t = localStorage.getItem('bf-theme') || 'auto'; } catch(e){} applyTheme(t);
  if (SNAP){ const sb = $('#snapbar'); sb.hidden = false;
    sb.textContent = `Snapshot estático exportado em ${new Date(SNAP.exported_at * 1000).toLocaleString('pt-BR')}: dados congelados, sem conexão com o Splunk.`;
    if (SNAP.filters){ ST.seg = SNAP.filters.segment; ST.status = SNAP.filters.status; ST.sort = SNAP.filters.sort; ST.source = SNAP.filters.source === 'all' ? 'all' : SNAP.filters.source; } }
  const h = (location.hash || '').slice(1);
  setTab(['exec','icn','solar','dados'].includes(h) ? h : 'exec');
  load();
})();
