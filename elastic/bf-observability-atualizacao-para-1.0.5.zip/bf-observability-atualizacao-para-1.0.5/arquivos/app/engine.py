"""Motor de indicadores: agregação, equivalência temporal, comparação e classificação.

Regras (todas determinísticas):
* Buckets horários: bucket h = intervalo local [h:00, h+1:00). Corte "09h" = buckets 0..8.
* Último bucket completo L do dia selecionado: o bucket termina antes de (agora - lag);
  dias já encerrados usam o fim do dia (ou da janela).
* Corte individual do indicador = último bucket <= L com dado no ano atual.
* Anos de referência são comparados no MESMO dia relativo da campanha e no MESMO corte.
* Variação % = (atual - ref) / ref * 100; variação absoluta = atual - ref.
* ref = 0 → % não aplicável; sem dado → sem dados; nada é interpolado ou trocado por zero.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from . import fmt
from .normalize import WindowIndex
from .queries import Campaign

AGGREGATIONS = ("sum", "last", "max", "min", "avg")
PERF = ("ok", "warn", "bad")
STATUS_LABEL = {
    "ok": "Acima", "warn": "Atenção", "bad": "Crítico",
    "no_data": "Sem dados", "no_reference": "Sem referência", "zero_reference": "Referência zero",
    "partial_reference": "Referência parcial", "stale": "Desatualizado", "error": "Erro de coleta",
    "pending": "Pendente de classificação", "future": "Não iniciado",
    "daily_reference": "Referência diária",
}


# ------------------------------------------------------------- agregação
def aggregate(values: list[tuple[float, float]], agg: str, day_has_data: bool = True) -> float | None:
    """values = [(ts, valor)] já filtrados até o corte. Retorna None se não há base."""
    if agg not in AGGREGATIONS:
        raise ValueError(f"agregação desconhecida: {agg}")
    if not values:
        return 0.0 if (agg == "sum" and day_has_data) else None
    vs = [v for _, v in sorted(values)]
    if agg == "sum":
        return float(sum(vs))
    if agg == "last":
        return float(vs[-1])
    if agg == "max":
        return float(max(vs))
    if agg == "min":
        return float(min(vs))
    return float(sum(vs) / len(vs))


def variation(cur: float | None, ref: float | None) -> tuple[float | None, float | None]:
    """(variação absoluta, variação %). % é None quando ref == 0 ou ausente."""
    if cur is None or ref is None:
        return None, None
    ab = cur - ref
    if ref == 0:
        return ab, None
    return ab, (cur - ref) / abs(ref) * 100.0


def classify(p: float | None, direction: str, thresholds: dict) -> tuple[str | None, float | None]:
    """Retorna (status, variação efetiva). Para lower_is_better a variação efetiva é invertida."""
    if p is None:
        return None, None
    eff = -p if direction == "lower_is_better" else p
    ok, warn = float(thresholds.get("ok", 0)), float(thresholds.get("warn", -10))
    if eff >= ok:
        return "ok", eff
    if eff > warn:
        return "warn", eff
    return "bad", eff


# ------------------------------------------------------------ seleção
@dataclass
class Selection:
    year: int
    ref_years: list[int]
    ref_year: int | None
    day: int
    day_dates: list
    last_bucket: int | None   # último bucket completo do dia (após corte manual)
    is_today: bool
    cutoff_override: int | None
    state: str                # running | closed | future


def default_year(c: Campaign, now: datetime) -> int | None:
    ws = c.valid_windows
    if not ws:
        return None
    for w in ws:
        if w.start <= now < w.end:
            return w.year
    started = [w.year for w in ws if w.start <= now]
    return max(started) if started else max(c.years)


def select(c: Campaign, tz: ZoneInfo, now: datetime, *, year: int | None = None, ref_year: int | None = None,
           day: int | None = None, cutoff: int | None = None, lag_minutes: int = 0) -> Selection:
    idx = WindowIndex(c, tz)
    years = c.years
    y = year if year in years else default_year(c, now)
    if y is None:
        raise ValueError("Campanha sem janelas válidas")
    refs = sorted([r for r in years if r < y], reverse=True)
    r = ref_year if ref_year in refs else (y - 1 if (y - 1) in refs else (refs[0] if refs else None))
    dates = idx.day_dates(y)
    today = now.astimezone(tz).date()
    if day is None or not (0 <= day < len(dates)):
        if today in dates:
            day = dates.index(today)
        elif dates and today > dates[-1]:
            day = len(dates) - 1
        else:
            day = 0
    ddate = dates[day] if dates else today
    midnight = datetime(ddate.year, ddate.month, ddate.day, tzinfo=tz)
    win_end = max(w.end for w in c.valid_windows if w.year == y)
    day_end = min(midnight + timedelta(days=1), win_end)
    eff_now = now - timedelta(minutes=lag_minutes)
    limit = min(eff_now, day_end)
    hours_done = int((limit - midnight).total_seconds() // 3600)
    last = min(hours_done, 24) - 1
    state = "closed" if eff_now >= day_end else ("future" if last < 0 and eff_now < midnight else "running")
    if last < 0:
        last = None
    if cutoff is not None and last is not None:
        cutoff = max(1, min(24, int(cutoff)))
        last = min(last, cutoff - 1)
    return Selection(y, refs, r, day, dates, last, ddate == today and state == "running",
                     cutoff, state)


# ------------------------------------------------------------- cálculo
def _group(points: list[dict]) -> dict[tuple[int, int], list[dict]]:
    g: dict[tuple[int, int], list[dict]] = {}
    for p in points:
        g.setdefault((p["year"], p["day"]), []).append(p)
    return g


def _upto(pts: list[dict], bucket: int) -> list[tuple[float, float]]:
    return [(p["ts"], p["value"]) for p in pts if p["hour"] <= bucket]


def _intensification(timeline: list[dict], min_drop_pp: float = 2.0) -> int | None:
    """Início da última sequência de queda contínua da variação efetiva (>= min_drop_pp)."""
    eff = [(t["bucket"], t["eff"]) for t in timeline if t["eff"] is not None]
    if len(eff) < 3:
        return None
    i = len(eff) - 1
    while i > 0 and eff[i][1] < eff[i - 1][1]:
        i -= 1
    if i == len(eff) - 1 or eff[i][1] - eff[-1][1] < min_drop_pp:
        return None
    return eff[i][0]


def confirm_cut(cur_pts: list[dict], cut: int, sel: Selection, now: datetime, tz: ZoneInfo,
                ind: dict, defaults: dict) -> tuple[int | None, str | None]:
    """Evita comparar um bucket ainda em ingestão.

    O último bucket com dado só entra no corte se (a) já existem dados de um bucket posterior
    (a ingestão passou dele) ou (b) desde o fim do bucket passou o tempo de FECHAMENTO típico
    medido no próprio dia: mediana, nos buckets anteriores, de (último _indextime do bucket - fim
    do bucket). Isso vale tanto para eventos em tempo real (fechamento ~minutos) quanto para
    cargas horárias carimbadas no início da hora (fechamento = atraso da carga após a hora).
    Sem medição, usa `ingestion_lag_minutes` do indicador (o atraso global já foi aplicado ao relógio).
    """
    if not sel.is_today or sel.cutoff_override is not None:
        return cut, None
    if ind.get("completeness", defaults.get("completeness", "measured_lag")) == "clock":
        return cut, None
    if any(p["hour"] > cut for p in cur_pts):
        return cut, None
    closes = sorted(max(0.0, p["close_lag"]) for p in cur_pts
                    if p["hour"] < cut and p.get("close_lag") is not None)
    lag_s = closes[len(closes) // 2] if closes else float(ind.get("ingestion_lag_minutes", 0)) * 60
    d = sel.day_dates[sel.day]
    end = datetime(d.year, d.month, d.day, tzinfo=tz) + timedelta(hours=cut + 1)
    if (now - end).total_seconds() >= lag_s:
        return cut, None
    prev = [p["hour"] for p in cur_pts if p["hour"] < cut]
    note = (f"Horário até {fmt.hour_label(cut)} ainda em ingestão (cada hora fecha ~{round(lag_s / 60)} min "
            f"após o término): não comparado.")
    return (max(prev) if prev else None), note


def compute_indicator(ind: dict, points: list[dict], sel: Selection, now: datetime, tz: ZoneInfo,
                      years: list[int], defaults: dict) -> dict:
    agg = ind.get("aggregation") or "sum"
    pending = ind.get("pending", False)
    thresholds = ind.get("thresholds") or defaults.get("thresholds", {"ok": 0, "warn": -10})
    stale_after = int(ind.get("stale_after_minutes", defaults.get("stale_after_minutes", 0)))
    by = _group(points)
    cur_pts = by.get((sel.year, sel.day), [])
    last_upd = max((p["measured"] for p in points if p["year"] == sel.year), default=None)

    out = {k: ind.get(k) for k in ("id", "source", "name", "segment", "unit", "aggregation", "nature",
                                    "direction", "description", "validated", "match")}
    out.update({
        "pending": pending, "thresholds": thresholds, "notes": [],
        "last_updated": datetime.fromtimestamp(last_upd, tz).isoformat() if last_upd else None,
        "cutoff_bucket": None, "cutoff_label": "—", "current": None, "values_by_year": {},
        "comparisons": {}, "series": {}, "data_status": "no_data",
    })
    if sel.last_bucket is None:
        out["data_status"] = "future" if sel.state == "future" else "no_data"
        return out
    eligible = [p for p in cur_pts if p["hour"] <= sel.last_bucket]
    cut = max((p["hour"] for p in eligible), default=None)
    if cut is not None:
        cut, note = confirm_cut(cur_pts, cut, sel, now, tz, ind, defaults)
        if note:
            out["notes"].append(note)
    if cut is None:
        out["data_status"] = "no_data"
        out["notes"].append("Sem dados confirmados no período atual até o corte.")
        cut = sel.last_bucket  # mostra histórico até o corte geral
    else:
        if cut < sel.last_bucket:
            out["notes"].append(f"Corte individual {fmt.hour_label(cut)} (dados completos até este horário).")
        out["data_status"] = "ok"
    out["cutoff_bucket"] = cut
    out["cutoff_label"] = fmt.hour_label(cut)
    use_agg = "last" if pending else agg

    first_bucket = min((p["hour"] for y in years for p in by.get((y, sel.day), [])), default=0)
    first_bucket = min(first_bucket, cut)
    for y in years:
        pts = by.get((y, sel.day), [])
        if not pts:
            out["values_by_year"][str(y)] = None
            continue
        v = aggregate(_upto(pts, cut), use_agg)
        if v is None and use_agg == "last" and y != sel.year:
            # ano anterior sem medição até o corte (só o total do dia, ex.: histórico Solar): exibe o total do dia
            v = aggregate([(p["ts"], p["value"]) for p in pts], "last")
            out.setdefault("daily_only_years", []).append(y)
        out["values_by_year"][str(y)] = v
        ser = []
        for b in range(first_bucket, cut + 1):
            hour_pts = [(p["ts"], p["value"]) for p in pts if p["hour"] == b]
            ser.append({
                "bucket": b,
                "cum": aggregate(_upto(pts, b), use_agg),
                "vol": aggregate(hour_pts, "sum", False) if (use_agg == "sum" and hour_pts) else None,
            })
        out["series"][str(y)] = ser
    if out.get("daily_only_years"):
        anos = ", ".join(map(str, out["daily_only_years"]))
        out["notes"].append(f"{anos}: só há o total do dia (sem medições ao longo do dia); a comparação é feita "
                            "com o dia completo, quando o dia atual estiver encerrado.")
    if out["data_status"] != "ok":
        return out
    out["current"] = out["values_by_year"].get(str(sel.year))

    # defasagem: só no dia corrente e sem corte manual
    # alerta por idade desativado por padrão (stale_after_minutes = 0); falha de coleta continua sinalizada
    if stale_after > 0 and sel.is_today and sel.cutoff_override is None:
        sp_mid = datetime(sel.day_dates[sel.day].year, sel.day_dates[sel.day].month, sel.day_dates[sel.day].day, tzinfo=tz)
        age_min = (now - (sp_mid + timedelta(hours=cut + 1))).total_seconds() / 60
        if age_min > stale_after:
            out["data_status"] = "stale"
            out["notes"].append(f"Último dado completo há {int(age_min)} min (limite {stale_after} min).")

    if pending:
        out["data_status"] = "pending" if out["data_status"] == "ok" else out["data_status"]
        out["notes"].append("Semântica não classificada: sem comparação nem status.")
        return out

    cur_series = {s["bucket"]: s["cum"] for s in out["series"].get(str(sel.year), [])}
    for r in sel.ref_years:
        rpts = by.get((r, sel.day), [])
        comp = {"ref": None, "abs": None, "pct": None, "eff": None, "status": None, "data_status": None,
                "timeline": [], "intensification_from": None}
        daily_only = bool(rpts) and agg == "last" and aggregate(_upto(rpts, cut), agg) is None
        if not rpts:
            comp["data_status"] = "no_reference"
        elif daily_only:
            # referência só com o total do dia: compara apenas quando o dia atual também estiver completo
            ref_day = aggregate([(p["ts"], p["value"]) for p in rpts], "last")
            comp["ref"] = ref_day
            comp["basis"] = "dia"
            if sel.last_bucket == 23:
                ab, pc = variation(out["current"], ref_day)
                st, eff = classify(pc, ind.get("direction", "higher_is_better"), thresholds)
                comp.update(abs=ab, pct=pc, eff=eff, status=st,
                            data_status="zero_reference" if ref_day == 0 else "ok")
            else:
                comp["data_status"] = "daily_reference"
        elif max(p["hour"] for p in rpts) < cut:
            comp["data_status"] = "partial_reference"
            comp["ref"] = aggregate(_upto(rpts, cut), agg)
        else:
            ref = aggregate(_upto(rpts, cut), agg)
            ab, pc = variation(out["current"], ref)
            st, eff = classify(pc, ind.get("direction", "higher_is_better"), thresholds)
            comp.update(ref=ref, abs=ab, pct=pc, eff=eff, status=st,
                        data_status="no_reference" if ref is None else ("zero_reference" if ref == 0 else "ok"))
            ref_series = {s["bucket"]: s["cum"] for s in out["series"].get(str(r), [])}
            for b in sorted(cur_series):
                ab_h, pc_h = variation(cur_series[b], ref_series.get(b))
                st_h, eff_h = classify(pc_h, ind.get("direction", "higher_is_better"), thresholds)
                comp["timeline"].append({"bucket": b, "cur": cur_series[b], "ref": ref_series.get(b),
                                         "abs": ab_h, "pct": pc_h, "eff": eff_h, "status": st_h})
            if st in ("warn", "bad"):
                comp["intensification_from"] = _intensification(comp["timeline"])
        out["comparisons"][str(r)] = comp
    return out


def summarize(inds: list[dict], ref_year: int | None) -> dict:
    key = str(ref_year)
    comp = [(i, i["comparisons"].get(key)) for i in inds if not i.get("pending")]
    comparable = [(i, c) for i, c in comp if c and c.get("status") in PERF]
    counts = {k: sum(1 for _, c in comparable if c["status"] == k) for k in PERF}
    below = sum(1 for _, c in comparable if c["eff"] is not None and c["eff"] < 0)
    worst = min(comparable, key=lambda x: x[1]["eff"], default=None)
    best = max(comparable, key=lambda x: x[1]["eff"], default=None)
    return {
        "ref_year": ref_year,
        "total": len(inds),
        "comparable": len(comparable),
        "below": below,
        "counts": counts,
        "unavailable": sum(1 for i, c in comp if not (c and c.get("status") in PERF)),
        "pending": sum(1 for i in inds if i.get("pending")),
        "stale": sum(1 for i in inds if i["data_status"] == "stale"),
        "worst": {"id": worst[0]["id"], "name": worst[0]["name"], "pct": worst[1]["pct"], "eff": worst[1]["eff"]} if worst else None,
        "best": {"id": best[0]["id"], "name": best[0]["name"], "pct": best[1]["pct"], "eff": best[1]["eff"]} if best and best[1]["eff"] >= 0 else None,
    }


def resolve_catalog(catalog: dict, keys_by_source: dict[str, list[str]]) -> list[dict]:
    """Indicadores do catálogo + queries Solar descobertas e ainda não catalogadas (pendentes)."""
    import hashlib

    inds = [dict(i) for i in catalog.get("indicators", [])]
    if not catalog.get("solar_discover_pending", True):
        return inds  # só o catálogo: queries Solar não catalogadas ficam fora do painel
    known = {(i["source"], i["match"]) for i in inds}
    pdef = catalog.get("solar_pending_defaults", {})
    for key in keys_by_source.get("solar", []):
        if ("solar", key) in known:
            continue
        h = hashlib.sha1(key.encode("utf-8")).hexdigest()[:10]
        short = key if len(key) <= 60 else key[:57] + "…"
        inds.append({
            "id": f"solar_{h}", "source": "solar", "match": key, "name": short,
            "segment": pdef.get("segment", "Solar"), "unit": "indefinida", "aggregation": None,
            "nature": "indefinida", "direction": None, "pending": True, "validated": False,
            "description": "Indicador Solar descoberto automaticamente; pendente de classificação semântica.",
        })
    return inds
