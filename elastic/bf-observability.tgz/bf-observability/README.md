# Black Friday · Business Observability (Claro · CoEE AIOps)

Aplicação web **local** para acompanhamento executivo de vendas, ativações e indicadores de negócio durante campanhas comerciais (Black Friday 2026 como campanha inicial), consumindo **dados reais do Splunk** via API REST, somente leitura.

A identidade visual reproduz o modelo de referência `docs/prototipo-referencia.html`: cabeçalho vermelho Claro, logo CoEE AIOps, cards, hero, gráficos comparativos, abas, tema claro/escuro e layout responsivo.

```
Splunk ──REST──▶ Conector (app/splunk_client.py) ─▶ Normalização (app/normalize.py)
      ─▶ Motor de indicadores (app/engine.py, app/insights.py) ─▶ Cache SQLite (app/cache.py)
      ─▶ API REST local (app/main.py) ─▶ Painel (frontend/)
```

O navegador **nunca** fala com o Splunk e nunca recebe o token.

## 1. Requisitos

- Servidor Linux (ou estação Windows/macOS para desenvolvimento) com **Python 3.11+**.
- Acesso de rede ao Splunk (porta da API REST, normalmente 8089) e um token com permissão de busca nos índices `icn` e `solar` e de leitura do lookup `comparativoDatasEspeciais.csv`.
- Nenhuma infraestrutura adicional: sem Docker, sem banco externo, sem CDN.

## 2. Instalação no servidor Linux (rede interna)

O painel roda como serviço no servidor, e o time acessa pela URL (`http://<servidor>:8765`). Não há login, então o acesso fica restrito à rede interna.

**Pré-requisitos:** Python 3.11+ e saída do servidor para o Splunk (`<host>.splunkcloud.com:8089`, direto ou via proxy corporativo com `HTTPS_PROXY`).

```bash
sudo useradd --system --home /opt/bf-observability bfobs
sudo git clone https://github.com/adriano-atanes/claro-black-friday-report /opt/bf-observability
cd /opt/bf-observability
sudo python3.11 -m venv .venv
sudo .venv/bin/python -m pip install -r requirements-server.txt   # sem internet: ver o topo do arquivo
sudo cp .env.example .env && sudo nano .env                         # token, BF_HOST=0.0.0.0, BF_PUBLIC_URL
sudo mkdir -p data logs && sudo chown -R bfobs: data logs && sudo chown bfobs: .env && sudo chmod 600 .env
sudo cp deploy/bf-observability.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now bf-observability
```

Operação:

```bash
sudo systemctl status bf-observability       # estado
sudo systemctl restart bf-observability      # após git pull ou mudança no .env
sudo journalctl -u bf-observability -f       # logs (também em logs/app.log)
sudo -u bfobs .venv/bin/python -m scripts.validate_splunk   # diagnóstico da integração → docs/validacao_splunk_<data>.md
```

Atualização da aplicação: `sudo git pull && sudo systemctl restart bf-observability`.

> Rode **um único processo** (não use vários workers do uvicorn): a coleta agendada e o cache SQLite são do processo, e vários workers duplicariam as buscas no Splunk.

Execução manual (desenvolvimento): `./start.sh` (abre o navegador só em máquina local com interface gráfica).

### Configuração (`.env` na raiz)

Variáveis obrigatórias (o arquivo existente **não é sobrescrito**):

```env
COCKPIT_SOURCE_SPLUNK_BASE_URL=https://seu-splunk:8089
COCKPIT_SOURCE_SPLUNK_TOKEN=...
```

Opcionais em `.env.example`: contexto de app (`BF_SPLUNK_APP`, necessário se o lookup só é visível em um app específico), CA corporativa (`BF_SPLUNK_CA_BUNDLE`; o TLS continua validado), intervalo de coleta (padrão 300 s), timeout, retries, porta etc. Se a aplicação estiver em uma subpasta de outro repositório, o `.env` da pasta-pai também é lido (ou aponte `BF_ENV_FILE`).

## 3. Primeiro uso no ambiente real (obrigatório antes de considerar validado)

1. `python -m scripts.validate_splunk`: confirma conectividade e autenticação, lê o lookup, executa as quatro consultas e grava um relatório **sem dados brutos** em `docs/`. Verifique:
   - o valor de `periodo` da Black Friday no lookup (o padrão detecta `black*`; fixe com `BF_DEFAULT_CAMPAIGN`);
   - o formato de `inicio`/`fim` (epoch, `%m/%d/%Y:%H:%M:%S` ou ISO; formatos relativos bloqueiam a campanha);
   - a reconciliação ICN (consulta original × variante horária);
   - o perfil de `QUANTIDADE` (incremental × acumulado);
   - os valores distintos de `query` do Solar e o perfil de cada um.
2. Classifique os indicadores Solar em `config/indicators.json` (ver §5).
3. Marque `"validated": true` nos indicadores cuja semântica o negócio confirmar.

## 4. Funcionalidades

| Aba | Conteúdo |
|---|---|
| **Visão Executiva** | Hero (“X de Y indicadores abaixo de 2025”), barra segmentada, maior queda e maior crescimento, principais destaques (insights determinísticos), cards de todos os indicadores |
| **Vendas e Ativações · ICN** | 8 indicadores ICN + tabela consolidada |
| **Indicadores de Negócio · Solar** | Indicadores Solar classificados + pendentes de classificação |
| **Modelo de Dados** | Fontes, regras, classificação, catálogo, qualidade dos dados, integração, observabilidade da aplicação, reconciliação, perfil Solar e as SPL em uso |

- **Filtros:** ano de referência (2025 padrão; 2024), segmento, “só alertas”, ordenação (padrão, pior e melhor variação), campanha, ano atual, dia da campanha, horário de corte (automático ou manual), fonte e status. Ano de referência, segmento, status e ordenação são aplicados no navegador sobre dados já carregados; campanha, ano, dia e corte são recalculados no backend a partir do cache, **sem nova busca no Splunk**.
- **Card → detalhe na própria página:** curva acumulada por hora (todos os anos), volume por hora (indicadores de soma), tooltip, tabela por horário com variação absoluta e percentual, fonte e atualização.
- **Reportes:** copiar para WhatsApp e para Teams (texto no modelo da especificação, respeitando os filtros e os cortes individuais), PDF (impressão otimizada), PNG (imagem gerada localmente), CSV e **snapshot HTML autônomo** (abre offline, sem credenciais, sem host interno nem chamadas de rede).
- **Atualização:** automática (`BF_REFRESH_INTERVAL_SECONDS`) e manual (botão “Atualizar”), com indicador de coleta, horários da última tentativa e da última coleta bem-sucedida e status por fonte. Uma coleta por vez; falhas no ICN não afetam o Solar e vice-versa; o último resultado válido continua visível, marcado como desatualizado.

## 5. Catálogo de indicadores (`config/indicators.json`)

Cada entrada: `id`, `source` (`icn`|`solar`), `match` (sourcetype no ICN; texto exato de `query` no Solar), `name`, `segment`, `unit` (`quantidade`, `percentual`, `moeda`…), `aggregation` (`sum`|`last`|`max`|`min`|`avg`), `nature`, `direction` (`higher_is_better`|`lower_is_better`), `thresholds` opcionais (`{"ok":0,"warn":-10}`), `stale_after_minutes`, `time_field` (Solar: `start` ou `_time`) e `validated`.

Valores de `query` do Solar sem entrada no catálogo aparecem automaticamente como **pendentes de classificação**: o valor é exibido, mas sem comparação nem status. Exemplo de classificação:

```json
{ "id": "solar_pedidos_ativados", "source": "solar", "match": "<texto exato da query>",
  "name": "Pedidos ativados", "segment": "Solar", "unit": "quantidade",
  "aggregation": "last", "nature": "cumulative", "direction": "higher_is_better", "validated": true }
```

Novos indicadores ICN exigem adicionar o sourcetype nas SPL (`queries/`) e no catálogo; a interface não muda.

## 6. API interna (somente `127.0.0.1`)

`GET /api/health` · `GET /api/campaigns` · `GET /api/indicators` · `GET /api/dashboard` · `GET /api/indicators/{id}/history` · `GET /api/sources/status` · `GET /api/reports/executive` · `POST /api/refresh` · `GET /api/export/csv` · `GET /api/export/html` · `GET /api/model` (seção técnica). Nenhum endpoint aceita SPL. Todos os parâmetros são validados e as mensagens de erro são sanitizadas.

## 7. Testes

```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

São 45 testes: unitários (agregação, comparação, classificação, equivalência temporal, normalização, exceções, insights) e de integração com um **Splunk falso** (`tests/fake_splunk.py`), que cobrem o contrato REST com polling e paginação, a falha parcial de fontes, o cache após reinício, a concorrência, a ausência de credenciais nas respostas e nos exports, e a validação contra injeção.

Para inspecionar a interface sem Splunk: `python -m tests.run_demo` (http://127.0.0.1:8799). **Os números desse modo são sintéticos**; esse modo existe só em `tests/` e nunca é usado pela aplicação operacional.

## 8. Segurança

O token fica apenas no processo backend: nunca vai para o navegador, logs, respostas, exports nem arquivos versionados (`.env` está no `.gitignore`). O TLS é validado. O servidor escuta em `127.0.0.1` por padrão (no servidor da empresa, `BF_HOST=0.0.0.0`, rede interna), com Host validado, CSP restritiva e sem CDN. Do Splunk, a aplicação usa apenas busca e leitura: a única ação de controle é cancelar o **próprio** job em caso de timeout (`BF_CANCEL_ON_TIMEOUT=false` desativa).

Ver também `docs/DECISOES.md` e `docs/CHECKLIST.md` (critérios de aceite e pendências).
