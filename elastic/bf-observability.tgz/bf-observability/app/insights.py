"""Motor de insights executivos por regras explícitas (sem modelos de linguagem).

Cada regra só usa valores calculados pelo motor de indicadores. Nenhuma causa
técnica é atribuída aos desvios.
"""
from __future__ import annotations

from . import fmt

RANK = {"ok": 0, "warn": 1, "bad": 2}


def _comparable(inds: list[dict], ref: str) -> list[tuple[dict, dict]]:
    out = []
    for i in inds:
        c = i["comparisons"].get(ref)
        if not i.get("pending") and c and c.get("status") in RANK:
            out.append((i, c))
    return out


def generate(inds: list[dict], ref_year: int | None, *, consecutive: int = 3) -> list[dict]:
    if ref_year is None:
        return []
    ref = str(ref_year)
    comp = _comparable(inds, ref)
    out: list[dict] = []

    def add(kind, severity, text, ind=None):
        out.append({"type": kind, "severity": severity, "text": text,
                    "indicator_id": ind["id"] if ind else None,
                    "segment": ind["segment"] if ind else None,
                    "source": ind["source"] if ind else None})

    # 1. maior queda percentual (variação efetiva)
    neg = [x for x in comp if x[1]["eff"] < 0]
    if neg:
        i, c = min(neg, key=lambda x: x[1]["eff"])
        verb = "redução" if c["pct"] < 0 else "aumento"
        mag = f"{abs(c['pct']):.1f}".replace(".", ",") + "%"
        t = (f"{i['name']} apresenta {verb} de {mag} "
             f"em relação ao mesmo horário de {ref} (até {i['cutoff_label']})")
        if c.get("intensification_from") is not None:
            t += f", com intensificação do desvio a partir das {fmt.hour_label(c['intensification_from'])}"
        add("maior_queda_pct", c["status"], t + ".", i)

    # 2. maior queda absoluta entre métricas de mesma unidade (quantidade)
    qty = [x for x in comp if x[0].get("unit") == "quantidade" and x[0].get("direction") == "higher_is_better"
           and x[1]["abs"] is not None and x[1]["abs"] < 0]
    if len(qty) >= 1:
        i, c = min(qty, key=lambda x: x[1]["abs"])
        add("maior_queda_abs", c["status"],
            f"Maior queda absoluta: {i['name']}, {fmt.signed(c['abs'])} vs {ref} "
            f"({fmt.num(i['current'])} contra {fmt.num(c['ref'])}).", i)

    # 3. maior crescimento
    pos = [x for x in comp if x[1]["eff"] >= 0 and x[1]["pct"] is not None]
    if pos:
        i, c = max(pos, key=lambda x: x[1]["eff"])
        add("maior_crescimento", "ok",
            f"Maior crescimento: {i['name']} {fmt.pct(c['pct'])} vs {ref} (até {i['cutoff_label']}).", i)

    # 4. segmento com maior concentração de desvios
    dev: dict[str, list[str]] = {}
    tot: dict[str, int] = {}
    for i, c in comp:
        tot[i["segment"]] = tot.get(i["segment"], 0) + 1
        if c["status"] in ("warn", "bad"):
            dev.setdefault(i["segment"], []).append(i["name"])
    if dev:
        n_all = sum(len(v) for v in dev.values())
        top = max(len(v) for v in dev.values())
        segs = sorted(s for s, v in dev.items() if len(v) == top)
        if len(dev) > 1 or n_all > 1:
            seg_txt = " e ".join(segs)
            add("concentracao_segmento", "warn",
                f"{seg_txt} concentra{'m' if len(segs) > 1 else ''} {top * len(segs)} de {n_all} "
                f"indicadores em atenção ou crítico.")

    # 5/6. transições na última hora e 7. deterioração consecutiva
    for i, c in comp:
        tl = [t for t in c["timeline"] if t["status"] in RANK]
        if len(tl) >= 2:
            prev, last = tl[-2], tl[-1]
            if prev["status"] == "warn" and last["status"] == "bad":
                add("atencao_para_critico", "bad",
                    f"{i['name']} passou de atenção para crítico entre {fmt.hour_label(prev['bucket'])} e "
                    f"{fmt.hour_label(last['bucket'])} ({fmt.pct(prev['pct'])} → {fmt.pct(last['pct'])}).", i)
            elif RANK[last["status"]] < RANK[prev["status"]]:
                add("recuperacao", "ok",
                    f"{i['name']} apresentou recuperação: {fmt.pct(prev['pct'])} até {fmt.hour_label(prev['bucket'])} → "
                    f"{fmt.pct(last['pct'])} até {fmt.hour_label(last['bucket'])}.", i)
        effs = [t["eff"] for t in c["timeline"] if t["eff"] is not None]
        if c["status"] in ("warn", "bad") and len(effs) > consecutive:
            tail = effs[-(consecutive + 1):]
            if all(b < a for a, b in zip(tail, tail[1:])):
                add("deterioracao_consecutiva", c["status"],
                    f"{i['name']} piora há {consecutive} horas consecutivas "
                    f"({fmt.pct(tail[0] if i.get('direction') != 'lower_is_better' else -tail[0])} → {fmt.pct(c['pct'])}).", i)

    # 9. sem atualização recente
    stale = [i for i in inds if i["data_status"] == "stale"]
    if stale:
        names = ", ".join(i["name"] for i in stale)
        add("desatualizado", "warn", f"Sem atualização recente: {names}.")

    return out


def divergences(inds: list[dict], pairs: list[dict]) -> list[dict]:
    """Divergência entre fontes, apenas para pares de negócio validados no catálogo."""
    by = {i["id"]: i for i in inds}
    out = []
    for p in pairs or []:
        a, b = by.get(p.get("a")), by.get(p.get("b"))
        tol = float(p.get("tolerance_pct", 5))
        if not a or not b or a["current"] in (None, 0) or b["current"] is None:
            continue
        diff = (b["current"] - a["current"]) / abs(a["current"]) * 100
        if abs(diff) > tol:
            out.append({"type": "divergencia_fontes", "severity": "warn", "indicator_id": a["id"],
                        "segment": a["segment"], "source": None,
                        "text": f"Divergência entre {a['name']} ({fmt.num(a['current'])}) e {b['name']} "
                                f"({fmt.num(b['current'])}): {fmt.pct(diff)} (tolerância {tol:g}%)."})
    return out
