"""Formatação pt-BR determinística (usada em insights e reportes)."""
from __future__ import annotations

MINUS = "−"


def num(v: float | None, unit: str = "quantidade") -> str:
    if v is None:
        return "—"
    if unit == "percentual":
        return f"{v:.1f}".replace(".", ",") + "%"
    if unit == "moeda":
        s = f"{abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        return (MINUS if v < 0 else "") + "R$ " + s
    if unit in ("quantidade",) or float(v).is_integer():
        s = f"{abs(round(v)):,}".replace(",", ".")
    else:
        s = f"{abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return (MINUS if v < 0 else "") + s


def signed(v: float | None, unit: str = "quantidade") -> str:
    if v is None:
        return "—"
    return ("+" if v > 0 else "") + num(v, unit)


def pct(p: float | None) -> str:
    if p is None:
        return "n/a"
    sign = "+" if p > 0 else MINUS if p < 0 else ""
    return sign + f"{abs(p):.1f}".replace(".", ",") + "%"


def hour_label(bucket: int | None) -> str:
    """Bucket h (intervalo [h, h+1)) → rótulo de corte 'até (h+1)h'."""
    if bucket is None:
        return "—"
    return f"{bucket + 1:02d}h"
