"""Ponto de entrada local: valida configuração, sobe o servidor em 127.0.0.1 e abre o navegador.

    python -m app.run [--no-browser]
"""
from __future__ import annotations

import os
import socket
import sys
import threading
import webbrowser
from pathlib import Path

import uvicorn

from .config import ROOT, load_settings

PID_FILE = ROOT / "data" / "app.pid"


def main() -> int:
    s = load_settings()
    print("Black Friday Business Observability")
    if s.missing:
        print("[AVISO] Variáveis ausentes no .env:", ", ".join(s.missing))
        print("        O painel abrirá, mas nenhuma coleta será executada até a configuração ser corrigida.")
    else:
        from urllib.parse import urlparse
        print(f"[ok] Splunk configurado: {urlparse(s.splunk_base_url).hostname} (token carregado, não exibido)")
    if s.host not in ("127.0.0.1", "localhost"):
        print(f"[AVISO] BF_HOST={s.host}: o servidor ficará acessível na rede.")
    with socket.socket() as sock:
        if sock.connect_ex(("127.0.0.1", s.port)) == 0:
            print(f"[ERRO] Porta {s.port} já está em uso. Encerre a instância em execução (systemctl stop bf-observability) ou defina BF_PORT no .env.")
            return 1
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))
    local = s.host in ("127.0.0.1", "localhost")
    url = f"http://127.0.0.1:{s.port}/" if local else (s.public_url or f"http://{socket.getfqdn()}:{s.port}/")
    print(f"[ok] Acesse: {url}")
    desktop = os.name == "nt" or bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")) or sys.platform == "darwin"
    if local and desktop and "--no-browser" not in sys.argv:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    try:
        uvicorn.run("app.main:create_app", factory=True, host=s.host, port=s.port, log_level="warning")
    finally:
        try:
            PID_FILE.unlink()
        except OSError:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
