"""Normalização dos resultados do Splunk para um contrato interno único.

Cada ponto normalizado:
    {"key": <sourcetype|query>, "ts": epoch do bucket/início, "measured": epoch da medição,
     "year": ano da janela da campanha, "day": posição relativa do dia na campanha (0 = 1º dia),
     "hour": hora local (0-23), "value": float, "events": int|None}

A atribuição de ano/dia usa as janelas do lookup comparativoDatasEspeciais.csv
(e não a data de calendário). Pontos fora de qualquer janela são descartados e
contabilizados como erro de normalização.
"""
from __future__ import annotations

import math
import re
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

from .queries import Campaign

_OFFSET_BASIC = re.compile(r"([+-]\d{2})(\d{2})$")


def parse_ts(raw: object, tz: ZoneInfo) -> datetime | None:
    """Aceita epoch (número/str) ou ISO-8601 com offset (+HH:MM ou +HHMM)."""
    if raw is None or raw == "":
        return None
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(float(raw), tz)
    s = str(raw).strip()
    if re.fullmatch(r"-?\d+(\.\d+)?", s):
        return datetime.fromtimestamp(float(s), tz)
    s = _OFFSET_BASIC.sub(r"\1:\2", s)
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=tz)
    return dt.astimezone(tz)


def parse_number(raw: object) -> float | None:
    if raw is None or raw == "":
        return None
    if isinstance(raw, list):  # campos multivalorados
        return None
    try:
        v = float(str(raw).strip().replace(",", ".")) if not isinstance(raw, (int, float)) else float(raw)
    except ValueError:
        return None
    return v if math.isfinite(v) else None


class WindowIndex:
    """Mapeia timestamps para (ano, dia relativo) a partir das janelas válidas."""

    def __init__(self, campaign: Campaign, tz: ZoneInfo):
        self.tz = tz
        self.windows = campaign.valid_windows
        self.first_date: dict[int, date] = {}
        for w in self.windows:
            d = w.start.astimezone(tz).date()
            y = w.year
            if y not in self.first_date or d < self.first_date[y]:
                self.first_date[y] = d

    def locate(self, dt: datetime) -> tuple[int, int] | None:
        for w in self.windows:
            # tolerância: o bin de 1h pode começar antes do início da janela (ex.: início 00:30)
            start = w.start.replace(minute=0, second=0, microsecond=0)
            if start <= dt < w.end:
                y = w.year
                return y, (dt.astimezone(self.tz).date() - self.first_date[y]).days
        return None

    def day_dates(self, year: int) -> list[date]:
        """Datas de calendário de cada dia relativo da campanha naquele ano."""
        ws = [w for w in self.windows if w.year == year]
        if not ws:
            return []
        first = self.first_date[year]
        last = max((w.end - timedelta(seconds=1)).astimezone(self.tz).date() for w in ws)
        return [first + timedelta(days=i) for i in range((last - first).days + 1)]


def _empty(source: str, rows: int) -> dict:
    return {"source": source, "rows": rows, "points": [], "errors": {}, "error_samples": [], "keys": []}


def _err(out: dict, kind: str, sample: str) -> None:
    out["errors"][kind] = out["errors"].get(kind, 0) + 1
    if len(out["error_samples"]) < 5:
        out["error_samples"].append(f"{kind}: {sample[:120]}")


def normalize_icn(rows: list[dict], campaign: Campaign, tz: ZoneInfo) -> dict:
    """Resultados da variante horária do ICN (sourcetype, _time/epoch, QUANTIDADE, EVENTOS)."""
    out = _empty("icn", len(rows))
    idx = WindowIndex(campaign, tz)
    keys = set()
    for r in rows:
        key = str(r.get("sourcetype", "")).strip()
        dt = parse_ts(r.get("epoch"), tz) or parse_ts(r.get("_time"), tz)
        val = parse_number(r.get("QUANTIDADE"))
        if not key:
            _err(out, "sem_sourcetype", str(r)[:80])
            continue
        if dt is None:
            _err(out, "timestamp_invalido", key)
            continue
        if val is None:
            _err(out, "quantidade_invalida", key)
            continue
        loc = idx.locate(dt)
        if loc is None:
            _err(out, "fora_da_janela", f"{key} {dt.isoformat()}")
            continue
        ev = parse_number(r.get("EVENTOS"))
        last_ev = parse_ts(r.get("LAST_EVENT"), tz)
        out["points"].append({
            "key": key, "ts": dt.timestamp(),
            # momento do último evento do bucket (fallback: fim do bucket)
            "measured": last_ev.timestamp() if last_ev else dt.timestamp() + 3600,
            "year": loc[0], "day": loc[1], "hour": dt.hour, "value": val,
            "events": int(ev) if ev is not None else None,
            "lag_avg": parse_number(r.get("LAG_AVG")), "lag_max": parse_number(r.get("LAG_MAX")),
        })
        keys.add(key)
    out["keys"] = sorted(keys)
    return out


def normalize_solar(rows: list[dict], campaign: Campaign, tz: ZoneInfo, time_fields: dict[str, str] | None = None) -> dict:
    """Resultados da consulta Solar original (start, query, value, _time, ...).

    O timestamp de referência é o campo `start` original (preservado pela consulta),
    pois o campo `time` é sobrescrito por `eventstats min(time) by block`.
    `time_fields` permite, por indicador, usar `_time` (momento da medição).
    """
    out = _empty("solar", len(rows))
    idx = WindowIndex(campaign, tz)
    time_fields = time_fields or {}
    keys = set()
    for r in rows:
        key = r.get("query")
        if isinstance(key, list):
            key = " ".join(map(str, key))
        key = str(key or "").strip()
        if not key:
            _err(out, "sem_query", str(r)[:80])
            continue
        measured = parse_ts(r.get("_time"), tz)
        field = time_fields.get(key, "start")
        dt = measured if field == "_time" else parse_ts(r.get("start"), tz)
        val = parse_number(r.get("value"))
        if dt is None:
            _err(out, "timestamp_invalido", key[:60])
            continue
        if val is None:
            _err(out, "valor_nao_numerico", key[:60])
            continue
        loc = idx.locate(dt)
        if loc is None:
            _err(out, "fora_da_janela", f"{key[:60]} {dt.isoformat()}")
            continue
        out["points"].append({
            "key": key, "ts": dt.timestamp(), "measured": (measured or dt).timestamp(),
            "year": loc[0], "day": loc[1], "hour": dt.hour, "minute": dt.minute, "value": val, "events": None,
        })
        keys.add(key)
    out["keys"] = sorted(keys)
    return out


def ingestion_summary(norm: dict, tz: ZoneInfo) -> list[dict]:
    """Atraso de ingestão (_indextime - _time) por chave, nas últimas 3 horas com dados do ano mais recente."""
    by: dict[str, list[dict]] = {}
    for p in norm["points"]:
        by.setdefault(p["key"], []).append(p)
    out = []
    for key, pts in sorted(by.items()):
        y = max(p["year"] for p in pts)
        recent = sorted((p for p in pts if p["year"] == y), key=lambda p: p["ts"])[-3:]
        avgs = [p["lag_avg"] for p in recent if p.get("lag_avg") is not None]
        maxs = [p["lag_max"] for p in recent if p.get("lag_max") is not None]
        out.append({
            "key": key, "year": y,
            "last_event": datetime.fromtimestamp(recent[-1]["measured"], tz).isoformat() if recent else None,
            "lag_avg_min": round(sum(avgs) / len(avgs) / 60, 1) if avgs else None,
            "lag_max_min": round(max(maxs) / 60, 1) if maxs else None,
        })
    return out


def icn_daily_totals(rows: list[dict]) -> dict[str, dict[str, float]]:
    """Totais por sourcetype e bloco/ano a partir da consulta ICN ORIGINAL (reconciliação)."""
    tot: dict[str, dict[str, float]] = {}
    for r in rows:
        key = str(r.get("sourcetype", ""))
        year = str(r.get("time", ""))
        v = parse_number(r.get("QUANTIDADE"))
        if key and year and v is not None:
            tot.setdefault(key, {})
            tot[key][year] = tot[key].get(year, 0.0) + v
    return tot


def profile_solar(norm: dict) -> list[dict]:
    """Perfil determinístico de cada `query` do Solar, para apoiar a classificação semântica."""
    by: dict[str, list[dict]] = {}
    for p in norm["points"]:
        by.setdefault(p["key"], []).append(p)
    prof = []
    for key, pts in sorted(by.items()):
        pts.sort(key=lambda p: p["ts"])
        ts = sorted({p["ts"] for p in pts})
        gaps = [b - a for a, b in zip(ts, ts[1:]) if b - a < 86400]
        typical = sorted(gaps)[len(gaps) // 2] if gaps else None
        mono_days = total_days = 0
        days: dict[tuple, list[float]] = {}
        for p in pts:
            days.setdefault((p["year"], p["day"]), []).append(p["value"])
        for vals in days.values():
            if len(vals) >= 3:
                total_days += 1
                if all(b >= a for a, b in zip(vals, vals[1:])):
                    mono_days += 1
        vals = [p["value"] for p in pts]
        integer = all(float(v).is_integer() for v in vals)
        if typical is None:
            hint = "Granularidade indeterminada (poucos pontos)."
        elif total_days and mono_days == total_days:
            hint = "Valores não decrescentes ao longo do dia: provável métrica ACUMULADA (agregação 'last')."
        elif integer:
            hint = "Valores inteiros oscilando: provável contagem INCREMENTAL por intervalo (agregação 'sum')."
        else:
            hint = "Valores não inteiros oscilando: provável taxa/média (agregação 'last' ou 'avg')."
        prof.append({
            "key": key, "points": len(pts), "years": sorted({p["year"] for p in pts}),
            "typical_interval_s": typical, "min": min(vals), "max": max(vals),
            "integer_values": integer, "monotonic_days": f"{mono_days}/{total_days}", "hint": hint,
        })
    return prof
