"""Reporte executivo em texto (WhatsApp / Teams) e CSV, respeitando os filtros."""
from __future__ import annotations

import csv
import io
from datetime import datetime

from . import fmt
from .engine import STATUS_LABEL, summarize

EMOJI = {"ok": "🟢", "warn": "🟡", "bad": "🔴"}
SEG_ORDER = ["Móvel", "Digital", "Residencial"]


def apply_filters(inds: list[dict], ref: int | None, *, source: str = "all", segment: str = "all",
                  status: str = "all", sort: str = "default") -> list[dict]:
    key = str(ref)
    out = []
    for i in inds:
        c = i["comparisons"].get(key) or {}
        st = c.get("status") if not i.get("pending") else None
        if source != "all" and i["source"] != source:
            continue
        if segment != "all" and i["segment"] != segment:
            continue
        if status == "alerts" and st not in ("warn", "bad"):
            continue
        if status in ("ok", "warn", "bad") and st != status:
            continue
        if status == "unavailable" and st in ("ok", "warn", "bad"):
            continue
        if status == "stale" and i["data_status"] != "stale":
            continue
        out.append(i)

    def eff(i):
        c = i["comparisons"].get(key) or {}
        return c.get("eff")

    if sort in ("worst", "best"):
        has = [i for i in out if eff(i) is not None]
        rest = [i for i in out if eff(i) is None]
        has.sort(key=eff, reverse=(sort == "best"))
        out = has + rest
    return out


def _line(i: dict, ref: str) -> str:
    c = i["comparisons"].get(ref) or {}
    st = c.get("status")
    val = fmt.num(i["current"], i.get("unit") or "quantidade")
    if i.get("pending"):
        return f"⚪ {i['name']}: {val} | pendente de classificação"
    if st in EMOJI:
        return f"{EMOJI[st]} {i['name']}: {val} | {fmt.pct(c['pct'])}"
    label = STATUS_LABEL.get(c.get("data_status") or i["data_status"], "Sem dados")
    if c.get("data_status") == "zero_reference":
        return f"⚪ {i['name']}: {val} | referência zero (variação n/a)"
    return f"⚪ {i['name']}: {val} | {label.lower()}"


def executive_text(payload: dict, inds: list[dict], insights: list[dict], *, fmt_style: str = "whatsapp",
                   public_url: str = "") -> str:
    sel = payload["selection"]
    ref = sel["ref_year"]
    key = str(ref)
    camp = payload["campaign"]
    b = "*" if fmt_style == "whatsapp" else "**"
    gen = datetime.fromisoformat(payload["generated_at"]).strftime("%d/%m/%Y %H:%M")
    summ = summarize(inds, ref)
    cuts = sorted({i["cutoff_label"] for i in inds if i["data_status"] in ("ok", "stale")})

    L = [f"{b}{camp['label'].upper()} {sel['year']} | VISÃO EXECUTIVA{b}", ""]
    L.append(f"Atualização: {gen}")
    day_txt = f" · dia {sel['day'] + 1} da campanha" if len(sel["days"]) > 1 else ""
    L.append(f"Comparativo: mesmo período de {ref}{day_txt}." if ref else "Comparativo: sem ano de referência disponível.")
    if len(cuts) == 1:
        L.append(f"Corte: até {cuts[0]}.")
    elif cuts:
        L.append("Cortes individuais: " + "; ".join(
            f"{i['name']} até {i['cutoff_label']}" for i in inds if i["data_status"] in ("ok", "stale")
            and i["cutoff_label"] != max(cuts, key=lambda c: c)) + f"; demais até {max(cuts)}.")
    L += ["", f"{b}Resumo executivo{b}", ""]
    L.append(f"- {summ['below']} de {summ['comparable']} indicadores abaixo da referência.")
    L.append(f"- {summ['counts']['bad']} indicadores críticos.")
    L.append(f"- {summ['counts']['warn']} indicadores em atenção.")
    L.append(f"- {summ['counts']['ok']} indicadores acima da referência.")
    L.append(f"- {summ['unavailable']} indicadores sem dados suficientes.")
    if summ["stale"]:
        L.append(f"- {summ['stale']} indicadores com dados desatualizados.")

    groups: dict[str, list[dict]] = {}
    for i in inds:
        g = "Solar" if i["source"] == "solar" else i["segment"]
        groups.setdefault(g, []).append(i)
    order = [s for s in SEG_ORDER if s in groups] + sorted(g for g in groups if g not in SEG_ORDER and g != "Solar")
    if "Solar" in groups:
        order.append("Solar")
    for g in order:
        lines = [_line(i, key) for i in groups[g] if not (g == "Solar" and i.get("pending"))]
        if g == "Solar":
            pend = sum(1 for i in groups[g] if i.get("pending"))
            if pend:
                lines.append(f"({pend} indicadores Solar pendentes de classificação não incluídos)")
        if not lines:
            continue
        L += ["", f"{b}{g}{b}", ""] + lines
    if insights:
        L += ["", f"{b}Principais destaques{b}", ""] + [f"- {x['text']}" for x in insights[:6]]
    srcs = payload.get("sources", {})
    bad_src = [k.upper() for k, v in srcs.items() if v.get("status") != "ok"]
    if bad_src:
        L += ["", f"⚠️ Fonte(s) {', '.join(bad_src)} com falha ou dados do último ciclo válido."]
    if public_url:
        L += ["", f"🔗 Painel: {public_url}"]
    L += ["", "Fonte: Splunk — ICN e Solar.", "CoEE AIOps."]
    return "\n".join(L)


def to_csv(payload: dict, inds: list[dict]) -> str:
    sel = payload["selection"]
    years = [str(y) for y in payload["campaign"]["years"]]
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["campanha", "ano_atual", "dia_campanha", "indicador_id", "indicador", "fonte", "segmento", "unidade",
                "agregacao", "corte", "ultima_atualizacao", "status_dados"]
               + [f"valor_{y}" for y in years]
               + [f"{k}_vs_{r}" for r in sel["ref_years"] for k in ("var_abs", "var_pct", "status")])
    for i in inds:
        row = [payload["campaign"]["id"], sel["year"], sel["day"] + 1, i["id"], i["name"], i["source"], i["segment"],
               i.get("unit"), i.get("aggregation"), i["cutoff_label"], i["last_updated"] or "", i["data_status"]]
        row += ["" if i["values_by_year"].get(y) is None else i["values_by_year"][y] for y in years]
        for r in sel["ref_years"]:
            c = i["comparisons"].get(str(r)) or {}
            row += ["" if c.get("abs") is None else round(c["abs"], 4),
                    "" if c.get("pct") is None else round(c["pct"], 2),
                    STATUS_LABEL.get(c.get("status") or c.get("data_status") or "", "")]
        w.writerow(row)
    return "﻿" + buf.getvalue()
