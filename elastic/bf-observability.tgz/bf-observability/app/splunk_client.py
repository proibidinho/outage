"""Cliente somente-leitura da API REST do Splunk.

Fluxo: POST /services/search/jobs → GET /services/search/jobs/{sid} (polling) →
GET /services/search/jobs/{sid}/results (paginado). A única operação de controle
usada é o cancelamento do próprio job criado pela aplicação em caso de timeout
(configurável em BF_CANCEL_ON_TIMEOUT); nenhum dado, objeto ou permissão do
Splunk é alterado.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass

import httpx

from .config import Settings
from .observability import METRICS, event, sanitize

log = logging.getLogger("bf.splunk")


class SplunkError(Exception):
    kind = "erro_coleta"

    def __init__(self, message: str, *, status: int | None = None):
        super().__init__(sanitize(message))
        self.status = status


class SplunkConfigError(SplunkError):
    kind = "configuracao"


class SplunkAuthError(SplunkError):
    kind = "autenticacao"


class SplunkForbiddenError(SplunkError):
    kind = "autorizacao"


class SplunkConnectionError(SplunkError):
    kind = "conectividade"


class SplunkTimeoutError(SplunkError):
    kind = "timeout"


class SplunkSearchError(SplunkError):
    kind = "busca"


@dataclass
class SearchResult:
    rows: list[dict]
    sid: str
    duration_ms: int
    result_count: int
    messages: list[str]


class SplunkClient:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None):
        self.s = settings
        self._transport = transport
        self._sem = asyncio.Semaphore(settings.max_concurrent_searches)

    # ------------------------------------------------------------------ http
    def _client(self) -> httpx.AsyncClient:
        if not self.s.configured:
            raise SplunkConfigError("Variáveis obrigatórias ausentes: " + ", ".join(self.s.missing))
        verify: bool | str = self.s.splunk_ca_bundle or True  # TLS sempre validado
        return httpx.AsyncClient(
            base_url=self.s.splunk_base_url,
            headers={"Authorization": f"{self.s.splunk_auth_scheme} {self.s.splunk_token}"},
            timeout=httpx.Timeout(self.s.http_timeout_s),
            verify=verify,
            transport=self._transport,
            follow_redirects=False,
        )

    def _jobs_path(self) -> str:
        if self.s.splunk_app:
            return f"/servicesNS/{self.s.splunk_owner}/{self.s.splunk_app}/search/jobs"
        return "/services/search/jobs"

    @staticmethod
    def _raise_for(resp: httpx.Response) -> None:
        if resp.status_code < 400:
            return
        detail = ""
        try:
            msgs = resp.json().get("messages") or []
            detail = "; ".join(m.get("text", "") for m in msgs)
        except Exception:
            pass
        if resp.status_code == 401:
            raise SplunkAuthError("Falha de autenticação no Splunk (401). Verifique o token.", status=401)
        if resp.status_code == 403:
            raise SplunkForbiddenError("Sem permissão para executar a busca (403). " + detail, status=403)
        if resp.status_code >= 500:
            raise SplunkConnectionError(f"Splunk indisponível ({resp.status_code}). {detail}", status=resp.status_code)
        raise SplunkSearchError(f"Requisição recusada ({resp.status_code}). {detail}", status=resp.status_code)

    async def _request(self, client: httpx.AsyncClient, method: str, url: str, **kw) -> httpx.Response:
        """Requisição com retry limitado e backoff exponencial (apenas erros transitórios)."""
        attempt = 0
        while True:
            try:
                resp = await client.request(method, url, **kw)
                self._raise_for(resp)
                return resp
            except (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError, httpx.TimeoutException) as exc:
                err: SplunkError = (
                    SplunkTimeoutError("Timeout na comunicação com o Splunk")
                    if isinstance(exc, httpx.TimeoutException)
                    else SplunkConnectionError("Falha de conectividade com o Splunk: " + type(exc).__name__)
                )
            except httpx.HTTPError as exc:  # TLS, proxy etc.
                err = SplunkConnectionError("Erro HTTP: " + type(exc).__name__)
            except SplunkConnectionError as exc:  # 5xx
                err = exc
            attempt += 1
            METRICS.inc("splunk_http_retry")
            if attempt > self.s.max_retries:
                raise err
            delay = min(30.0, (2 ** (attempt - 1)) + random.random() * 0.5)
            event(log, "retry splunk", logging.WARNING, attempt=attempt, delay_s=round(delay, 2), error=str(err))
            await asyncio.sleep(delay)

    # ---------------------------------------------------------------- search
    @staticmethod
    def _prepare(spl: str) -> str:
        spl = spl.strip()
        if spl.startswith("|") or spl.lower().startswith("search "):
            return spl
        return "search " + spl

    async def ping(self) -> dict:
        """Verifica conectividade/autenticação (GET somente-leitura)."""
        t0 = time.monotonic()
        async with self._client() as c:
            r = await self._request(c, "GET", "/services/server/info", params={"output_mode": "json"})
            content = (r.json().get("entry") or [{}])[0].get("content", {})
        return {"ok": True, "latency_ms": int((time.monotonic() - t0) * 1000), "version": content.get("version")}

    async def search(self, spl: str, *, label: str, timeout_s: int | None = None) -> SearchResult:
        timeout_s = timeout_s or self.s.query_timeout_s
        async with self._sem:
            t0 = time.monotonic()
            sid = ""
            try:
                async with self._client() as c:
                    r = await self._request(
                        c, "POST", self._jobs_path(),
                        data={"search": self._prepare(spl), "output_mode": "json", "exec_mode": "normal"},
                    )
                    sid = r.json().get("sid", "")
                    if not sid:
                        raise SplunkSearchError("Splunk não retornou sid para a busca")
                    content = await self._wait(c, sid, timeout_s, t0)
                    rows = await self._results(c, sid)
                duration = int((time.monotonic() - t0) * 1000)
                msgs = [sanitize(m.get("text", "")) for m in content.get("messages", []) if isinstance(m, dict)]
                METRICS.inc("splunk_search_ok")
                METRICS.record_query(label=label, ok=True, duration_ms=duration, rows=len(rows))
                event(log, "busca concluída", label=label, duration_ms=duration, rows=len(rows))
                return SearchResult(rows, sid, duration, int(content.get("resultCount", len(rows)) or 0), msgs)
            except SplunkError as exc:
                duration = int((time.monotonic() - t0) * 1000)
                METRICS.inc("splunk_search_error")
                METRICS.record_query(label=label, ok=False, duration_ms=duration, error=exc.kind)
                event(log, "busca falhou", logging.ERROR, label=label, kind=exc.kind, error=str(exc), duration_ms=duration)
                raise

    async def _wait(self, c: httpx.AsyncClient, sid: str, timeout_s: int, t0: float) -> dict:
        url = f"{self._jobs_path()}/{sid}"
        while True:
            r = await self._request(c, "GET", url, params={"output_mode": "json"})
            content = (r.json().get("entry") or [{}])[0].get("content", {})
            state = content.get("dispatchState", "")
            if content.get("isFailed") or state == "FAILED":
                msgs = "; ".join(m.get("text", "") for m in content.get("messages", []) if isinstance(m, dict))
                raise SplunkSearchError("Busca falhou no Splunk: " + (msgs or state))
            if content.get("isDone") or state == "DONE":
                return content
            if time.monotonic() - t0 > timeout_s:
                if self.s.cancel_on_timeout:
                    try:
                        await c.post(f"{url}/control", data={"action": "cancel", "output_mode": "json"})
                    except httpx.HTTPError:
                        pass
                raise SplunkTimeoutError(f"Busca excedeu {timeout_s}s")
            await asyncio.sleep(self.s.poll_interval_s)

    async def _results(self, c: httpx.AsyncClient, sid: str) -> list[dict]:
        rows: list[dict] = []
        offset = 0
        url = f"{self._jobs_path()}/{sid}/results"
        while True:
            r = await self._request(
                c, "GET", url, params={"output_mode": "json", "count": self.s.page_size, "offset": offset}
            )
            page = r.json().get("results", []) if r.content else []
            rows.extend(page)
            if len(page) < self.s.page_size:
                return rows
            offset += len(page)
