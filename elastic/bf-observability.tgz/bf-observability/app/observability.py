"""Logs estruturados (JSON) e métricas internas da aplicação.

Nunca registra tokens, cabeçalhos de autenticação ou o texto completo das buscas
com resultados. Mensagens de erro passam por `sanitize()` antes de serem logadas
ou devolvidas pela API.
"""
from __future__ import annotations

import json
import logging
import re
import threading
import time
from collections import deque
from logging.handlers import RotatingFileHandler
from pathlib import Path

_SECRET_PATTERNS = [
    re.compile(r"(?i)(authorization|bearer|splunk)\s*[:=]?\s*[A-Za-z0-9._\-+/=]{16,}"),
    re.compile(r"(?i)(token|password|senha|secret)[\"']?\s*[:=]\s*[\"']?[^\s\"',}]+"),
    re.compile(r"eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]*"),  # JWT
]
_URL = re.compile(r"https?://[^\s\"']+")


def sanitize(msg: object, max_len: int = 300) -> str:
    s = str(msg)
    for p in _SECRET_PATTERNS:
        s = p.sub("[redacted]", s)
    s = _URL.sub("[url]", s)
    return s[:max_len]


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        data = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "msg": sanitize(record.getMessage(), 1000),
        }
        extra = getattr(record, "fields", None)
        if isinstance(extra, dict):
            data.update({k: (sanitize(v) if isinstance(v, str) else v) for k, v in extra.items()})
        return json.dumps(data, ensure_ascii=False, default=str)


def setup_logging(log_path: str) -> logging.Logger:
    log = logging.getLogger("bf")
    for h in list(log.handlers):
        log.removeHandler(h)
        h.close()
    log.setLevel(logging.INFO)
    fmt = JsonFormatter()
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    log.addHandler(sh)
    try:
        Path(log_path).parent.mkdir(parents=True, exist_ok=True)
        fh = RotatingFileHandler(log_path, maxBytes=5_000_000, backupCount=3, encoding="utf-8")
        fh.setFormatter(fmt)
        log.addHandler(fh)
    except OSError:
        log.warning("não foi possível abrir arquivo de log")
    log.propagate = False
    return log


def event(log: logging.Logger, msg: str, level: int = logging.INFO, **fields) -> None:
    log.log(level, msg, extra={"fields": fields})


class Metrics:
    """Contadores em memória, expostos na aba Modelo de Dados."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.counters: dict[str, int] = {}
        self.queries: deque = deque(maxlen=50)

    def inc(self, name: str, n: int = 1) -> None:
        with self._lock:
            self.counters[name] = self.counters.get(name, 0) + n

    def record_query(self, **info) -> None:
        with self._lock:
            self.queries.appendleft({"at": time.time(), **info})

    def snapshot(self) -> dict:
        with self._lock:
            c = dict(self.counters)
            q = list(self.queries)
        hits, misses = c.get("cache_hit", 0), c.get("cache_miss", 0)
        c["cache_hit_ratio"] = round(hits / (hits + misses), 3) if hits + misses else None
        return {"counters": c, "recent_queries": q}


METRICS = Metrics()
