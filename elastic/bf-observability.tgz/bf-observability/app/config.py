"""Carregamento e validação de configuração.

Lê o arquivo `.env` existente na raiz do projeto (sem nunca sobrescrevê-lo) e
variáveis de ambiente do processo. O token do Splunk permanece apenas neste
processo: não é logado, serializado nem enviado ao navegador.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

REQUIRED = ("COCKPIT_SOURCE_SPLUNK_BASE_URL", "COCKPIT_SOURCE_SPLUNK_TOKEN")


def _parse_env_file(path: Path) -> dict[str, str]:
    """Parser mínimo de .env (KEY=VALUE, comentários com #, aspas opcionais)."""
    out: dict[str, str] = {}
    if not path.is_file():
        return out
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        key, _, val = line.partition("=")
        key, val = key.strip(), val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        elif " #" in val:
            val = val.split(" #", 1)[0].rstrip()
        out[key] = val
    return out


def _env_files() -> list[Path]:
    # .env da raiz do projeto; BF_ENV_FILE permite apontar para o .env da raiz
    # de um repositório maior quando esta aplicação estiver em uma subpasta.
    files = []
    custom = os.environ.get("BF_ENV_FILE")
    if custom:
        files.append(Path(custom))
    files += [ROOT / ".env", ROOT.parent / ".env"]
    return files


def load_env() -> dict[str, str]:
    merged: dict[str, str] = {}
    for f in reversed(_env_files()):  # o primeiro da lista tem precedência
        merged.update(_parse_env_file(f))
    merged.update({k: v for k, v in os.environ.items() if k.startswith(("COCKPIT_", "BF_"))})
    return merged


def _int(env: dict, key: str, default: int) -> int:
    try:
        return int(env.get(key, default))
    except (TypeError, ValueError):
        return default


def _bool(env: dict, key: str, default: bool) -> bool:
    v = env.get(key)
    if v is None or v == "":
        return default
    return v.strip().lower() in ("1", "true", "yes", "sim", "on")


@dataclass(frozen=True)
class Settings:
    splunk_base_url: str = ""
    splunk_token: str = field(default="", repr=False)
    splunk_auth_scheme: str = "Bearer"
    splunk_app: str = ""
    splunk_owner: str = "-"
    splunk_ca_bundle: str = ""
    timezone: str = "America/Sao_Paulo"
    host: str = "127.0.0.1"
    port: int = 8765
    refresh_interval_s: int = 300
    query_timeout_s: int = 300
    http_timeout_s: int = 30
    max_retries: int = 3
    max_concurrent_searches: int = 2
    page_size: int = 10000
    poll_interval_s: float = 2.0
    cancel_on_timeout: bool = True
    icn_reconcile_every: int = 6
    default_campaign: str = ""
    public_url: str = ""
    db_path: str = str(ROOT / "data" / "cache.sqlite3")
    log_path: str = str(ROOT / "logs" / "app.log")
    catalog_path: str = str(ROOT / "config" / "indicators.json")
    queries_dir: str = str(ROOT / "queries")
    frontend_dir: str = str(ROOT / "frontend")

    @property
    def missing(self) -> list[str]:
        miss = []
        if not self.splunk_base_url:
            miss.append(REQUIRED[0])
        if not self.splunk_token:
            miss.append(REQUIRED[1])
        return miss

    @property
    def configured(self) -> bool:
        return not self.missing

    def public(self) -> dict:
        """Visão segura das configurações (sem token, sem URL completa)."""
        from urllib.parse import urlparse

        host = urlparse(self.splunk_base_url).hostname or ""
        return {
            "splunk_host": host,
            "splunk_configured": self.configured,
            "missing": self.missing,
            "auth_scheme": self.splunk_auth_scheme,
            "app_context": self.splunk_app or "(padrão do usuário)",
            "timezone": self.timezone,
            "refresh_interval_s": self.refresh_interval_s,
            "query_timeout_s": self.query_timeout_s,
            "max_retries": self.max_retries,
            "max_concurrent_searches": self.max_concurrent_searches,
            "page_size": self.page_size,
            "icn_reconcile_every": self.icn_reconcile_every,
            "tls_verify": True,
            "custom_ca_bundle": bool(self.splunk_ca_bundle),
        }


def load_settings(env: dict[str, str] | None = None) -> Settings:
    env = load_env() if env is None else env
    return Settings(
        splunk_base_url=env.get("COCKPIT_SOURCE_SPLUNK_BASE_URL", "").strip().rstrip("/"),
        splunk_token=env.get("COCKPIT_SOURCE_SPLUNK_TOKEN", "").strip(),
        splunk_auth_scheme=env.get("BF_SPLUNK_AUTH_SCHEME", "Bearer").strip() or "Bearer",
        splunk_app=env.get("BF_SPLUNK_APP", "").strip(),
        splunk_owner=env.get("BF_SPLUNK_OWNER", "-").strip() or "-",
        splunk_ca_bundle=env.get("BF_SPLUNK_CA_BUNDLE", "").strip(),
        timezone=env.get("BF_TIMEZONE", "America/Sao_Paulo"),
        host=env.get("BF_HOST", "127.0.0.1"),
        port=_int(env, "BF_PORT", 8765),
        refresh_interval_s=_int(env, "BF_REFRESH_INTERVAL_SECONDS", 300),
        query_timeout_s=_int(env, "BF_QUERY_TIMEOUT_SECONDS", 300),
        http_timeout_s=_int(env, "BF_HTTP_TIMEOUT_SECONDS", 30),
        max_retries=_int(env, "BF_MAX_RETRIES", 3),
        max_concurrent_searches=max(1, _int(env, "BF_MAX_CONCURRENT_SEARCHES", 2)),
        page_size=max(100, _int(env, "BF_PAGE_SIZE", 10000)),
        poll_interval_s=float(env.get("BF_POLL_INTERVAL_SECONDS", 2.0) or 2.0),
        cancel_on_timeout=_bool(env, "BF_CANCEL_ON_TIMEOUT", True),
        icn_reconcile_every=max(0, _int(env, "BF_ICN_RECONCILE_EVERY", 6)),
        default_campaign=env.get("BF_DEFAULT_CAMPAIGN", "").strip(),
        public_url=env.get("BF_PUBLIC_URL", "").strip(),
        db_path=env.get("BF_DB_PATH", str(ROOT / "data" / "cache.sqlite3")),
        log_path=env.get("BF_LOG_PATH", str(ROOT / "logs" / "app.log")),
    )


def load_catalog(path: str) -> dict:
    with open(path, encoding="utf-8") as fh:
        cat = json.load(fh)
    ids = [i["id"] for i in cat.get("indicators", [])]
    if len(ids) != len(set(ids)):
        raise ValueError("Catálogo de indicadores possui ids duplicados")
    return cat
