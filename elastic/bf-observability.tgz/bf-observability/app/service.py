"""Montagem do payload do dashboard a partir do cache (nenhuma busca no Splunk aqui).

Filtros de ano de referência, segmento, fonte, status e ordenação são aplicados
sobre os dados já coletados; o frontend recebe todos os anos de referência de
uma vez para alternar sem novas requisições.
"""
from __future__ import annotations

import time
from datetime import datetime
from zoneinfo import ZoneInfo

from . import insights as I
from .collector import Collector
from .engine import compute_indicator, resolve_catalog, select, summarize
from .normalize import WindowIndex
from .observability import METRICS

WEEKDAYS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]


def campaign_days(camp, tz, years) -> list[dict]:
    idx = WindowIndex(camp, tz)
    dates = {y: idx.day_dates(y) for y in years}
    n = max((len(d) for d in dates.values()), default=0)
    out = []
    for i in range(n):
        dd = {str(y): dates[y][i].isoformat() for y in years if i < len(dates[y])}
        out.append({"index": i, "dates": dd})
    return out


def build_dashboard(col: Collector, *, campaign: str | None = None, year: int | None = None,
                    ref_year: int | None = None, day: int | None = None, cutoff: int | None = None,
                    now: datetime | None = None) -> dict:
    tz = col.tz
    now = now or col.clock()
    camp = col.campaign(campaign)
    base = {
        "generated_at": now.isoformat(),
        "timezone": col.s.timezone,
        "campaigns": [{"id": c.id, "label": c.label, "years": c.years} for c in col.campaigns if c.usable],
        "splunk": {k: col.splunk[k] for k in ("status", "checked_at", "error")},
        "lookup_error": col.lookup_error,
        "collecting": col.lock.locked(),
    }
    if camp is None:
        return {**base, "status": "no_campaign", "campaign": None, "indicators": [], "sources": col.sources_status(None)}

    key = (camp.id, year, ref_year, day, cutoff, col.data_version, now.strftime("%Y%m%d%H%M"), col.lock.locked())
    _memo = col.memo
    if key in _memo:
        METRICS.inc("dashboard_memo_hit")
        return _memo[key]
    METRICS.inc("dashboard_memo_miss")

    sel = select(camp, tz, now, year=year, ref_year=ref_year, day=day, cutoff=cutoff,
                 lag_minutes=int(col.catalog.get("defaults", {}).get("ingestion_lag_minutes", 0)))
    data = col.source_data(camp.id)
    sources = col.sources_status(camp.id)
    keys = {s: (d["keys"] if d else []) for s, d in data.items()}
    years = [y for y in camp.years if y <= sel.year]
    by_key: dict[tuple[str, str], list[dict]] = {}
    for s, d in data.items():
        for p in (d["points"] if d else []):
            by_key.setdefault((s, p["key"]), []).append(p)

    inds = []
    defaults = col.catalog.get("defaults", {})
    for ind in resolve_catalog(col.catalog, keys):
        src = ind["source"]
        r = compute_indicator(ind, by_key.get((src, ind["match"]), []), sel, now, tz, years, defaults)
        st = sources[src]["status"]
        if data[src] is None:
            r["data_status"] = "error" if st == "error" else "no_data"
            r["notes"].append("Fonte sem coleta válida." if st == "error" else "Aguardando primeira coleta.")
        elif st == "stale" and r["data_status"] in ("ok", "pending"):
            r["data_status"] = "stale"
            r["notes"].append("Falha na última coleta da fonte: exibindo o último resultado válido.")
        inds.append(r)

    summaries = {str(r): summarize(inds, r) for r in sel.ref_years}
    ins = {str(r): I.generate(inds, r) + I.divergences(inds, col.catalog.get("divergence_pairs", []))
           for r in sel.ref_years}
    payload = {
        **base,
        "status": "ok",
        "campaign": {"id": camp.id, "label": camp.label, "years": years, "all_years": camp.years,
                     "issues": camp.issues},
        "selection": {
            "year": sel.year, "ref_year": sel.ref_year, "ref_years": sel.ref_years, "day": sel.day,
            "days": campaign_days(camp, tz, years), "state": sel.state, "is_today": sel.is_today,
            "cutoff_override": sel.cutoff_override, "last_bucket": sel.last_bucket,
            "clock_cutoff_label": f"{sel.last_bucket + 1:02d}h" if sel.last_bucket is not None else "—",
            "cutoff_label": predominant_cutoff(inds, sel),
        },
        "segments": col.catalog.get("segments", []),
        "sources": sources,
        "indicators": inds,
        "summary": summaries,
        "insights": ins,
        "last_success": max((v["last_success"] or v["cached_at"] or 0) for v in sources.values()) or None,
    }
    if len(_memo) > 64:
        _memo.clear()
    _memo[key] = payload
    return payload


def predominant_cutoff(inds: list[dict], sel) -> str:
    """Corte efetivamente usado pela maioria dos indicadores com dados (empate: o mais recente)."""
    from collections import Counter
    c = Counter(i["cutoff_label"] for i in inds if i["data_status"] in ("ok", "stale", "pending"))
    if not c:
        return f"{sel.last_bucket + 1:02d}h" if sel.last_bucket is not None else "—"
    top = max(c.values())
    return max(k for k, v in c.items() if v == top)


def strip_internal(payload: dict) -> dict:
    """Remove detalhes técnicos antes de exportar snapshots para terceiros."""
    p = dict(payload)
    p["sources"] = {k: {kk: v.get(kk) for kk in ("status", "last_success", "cached_at", "data_age_s")}
                    for k, v in payload.get("sources", {}).items()}
    p["splunk"] = {"status": payload.get("splunk", {}).get("status")}
    p.pop("lookup_error", None)
    p["snapshot"] = True
    p["exported_at"] = time.time()
    return p
