#!/usr/bin/env bash
# Execução manual (desenvolvimento ou teste). Em produção use o serviço systemd (deploy/).
set -e
cd "$(dirname "$0")"
[ -x .venv/bin/python ] || { python -m venv .venv && .venv/bin/python -m pip install -q -r requirements-server.txt; }
exec .venv/bin/python -m app.run "$@"
