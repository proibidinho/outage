"""Testes de integração ponta a ponta com o Splunk falso (contrato REST + API local)."""
from dataclasses import replace
from datetime import datetime

import pytest
from fastapi.testclient import TestClient

from app.config import Settings, load_settings, _parse_env_file
from app.main import create_app
from tests.fake_splunk import TZ, FakeSplunk

NOW = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
TOKEN = "test-token-123456789"


def make(tmp_path, fake: FakeSplunk, **kw):
    s = Settings(splunk_base_url="https://splunk.example.invalid:8089", splunk_token=TOKEN,
                 db_path=str(tmp_path / "c.sqlite3"), log_path=str(tmp_path / "app.log"),
                 poll_interval_s=0.01, page_size=100, max_retries=0, icn_reconcile_every=1)
    s = replace(s, **kw)
    app = create_app(s, transport=fake.transport(), start_scheduler=False)
    app.state.col.clock = lambda: NOW
    return app


@pytest.fixture
def env(tmp_path):
    fake = FakeSplunk(NOW)
    app = make(tmp_path, fake)
    with TestClient(app) as c:
        r = c.portal.call(app.state.col.refresh)
        assert r["status"] == "ok", r
        yield c, app, fake, tmp_path


def test_full_cycle(env):
    c, app, fake, _ = env
    # uma busca consolidada por fonte (+ lookup + reconciliação com a consulta original)
    assert sorted(fake.searches) == ["icn_hourly", "icn_original", "lookup", "solar"]
    assert fake.result_requests > 4  # paginação (page_size=100)
    d = c.get("/api/dashboard").json()
    assert d["campaign"]["id"] == "black_friday" and d["selection"]["year"] == 2026
    assert d["selection"]["ref_year"] == 2025 and d["selection"]["cutoff_label"] == "09h"
    icn = [i for i in d["indicators"] if i["source"] == "icn"]
    assert len(icn) == 8 and all(i["current"] is not None for i in icn)
    ecom = next(i for i in icn if i["id"] == "vendasECommerce")
    assert ecom["cutoff_label"] == "08h"  # corte individual detectado dinamicamente
    assert all(i["cutoff_label"] == "09h" for i in icn if i["id"] != "vendasECommerce")
    solar = [i for i in d["indicators"] if i["source"] == "solar"]
    assert len(solar) == 2 and all(i["pending"] for i in solar)
    s = d["summary"]["2025"]
    assert s["comparable"] == 8 and s["below"] == 7 and s["counts"]["ok"] == 1
    assert d["insights"]["2025"]
    assert "2024" in d["summary"]
    assert d["selection"]["clock_cutoff_label"] == "09h"
    m = c.get("/api/model").json()
    assert len(m["icn_ingestion"]) == 8 and m["icn_ingestion"][0]["lag_max_min"] == 5.0
    pre = next(i for i in icn if i["id"] == "ativacaoPrePago")
    assert pre["last_updated"].startswith("2026-11-27T08:59")  # último evento real, não o fim do bucket


def test_values_match_splunk_rows(env):
    """O valor exibido = soma das linhas QUANTIDADE retornadas pelo Splunk até o corte."""
    c, app, fake, _ = env
    rows = fake.icn_hourly()
    exp = sum(float(r["QUANTIDADE"]) for r in rows if r["sourcetype"] == "ativacaoPrePago"
              and r["_time"].startswith("2026-11-27") and int(r["_time"][11:13]) <= 8)
    ref = sum(float(r["QUANTIDADE"]) for r in rows if r["sourcetype"] == "ativacaoPrePago"
              and r["_time"].startswith("2025-11-28") and int(r["_time"][11:13]) <= 8)
    i = c.get("/api/indicators/ativacaoPrePago/history").json()["indicator"]
    assert i["current"] == exp and i["comparisons"]["2025"]["ref"] == ref
    assert i["comparisons"]["2025"]["pct"] == pytest.approx((exp - ref) / ref * 100)
    rec = app.state.col.reconciliation
    assert rec and all(x["ok"] for x in rec["items"])


def test_filters_and_report(env):
    c, *_ = env
    r = c.get("/api/reports/executive", params={"segment": "Móvel"}).json()
    t = r["text"]
    assert r["count"] == 5 and "BLACK FRIDAY 2026 | VISÃO EXECUTIVA" in t and "*Móvel*" in t
    assert "Residencial" not in t.split("Resumo executivo")[1].split("Principais destaques")[0]
    assert "Cortes individuais: Vendas E-commerce até 08h" not in t  # e-commerce fora do filtro
    full = c.get("/api/reports/executive").json()["text"]
    assert "Vendas E-commerce até 08h" in full and "Fonte: Splunk — ICN e Solar." in full
    assert "localhost" not in full and "127.0.0.1" not in full
    teams = c.get("/api/reports/executive", params={"style": "teams"}).json()["text"]
    assert teams.startswith("**BLACK FRIDAY")
    r24 = c.get("/api/reports/executive", params={"ref_year": 2024}).json()["text"]
    assert "mesmo período de 2024" in r24
    csv = c.get("/api/export/csv").text
    assert csv.count("\n") == 11 and "vendasECommerce" in csv  # cabeçalho + 10 indicadores
    assert c.get("/api/reports/executive", params={"status": "x"}).status_code == 400
    assert c.get("/api/dashboard", params={"campaign": 'black_friday" | delete'}).status_code == 400
    assert c.get("/api/dashboard", params={"cutoff": 30}).status_code == 422


def test_cutoff_override_and_year(env):
    c, *_ = env
    d = c.get("/api/dashboard", params={"cutoff": 6}).json()
    assert d["selection"]["cutoff_label"] == "06h"
    assert all(i["cutoff_label"] in ("06h", "—") for i in d["indicators"])
    d = c.get("/api/dashboard", params={"year": 2025}).json()
    assert d["selection"]["ref_years"] == [2024] and d["selection"]["cutoff_label"] == "24h"


def test_snapshot_html_has_no_secrets(env):
    c, *_ = env
    h = c.get("/api/export/html").text
    assert "window.__SNAPSHOT__" in h and "/api/" in h  # código do app embutido
    assert TOKEN not in h and "splunk.example.invalid" not in h
    assert 'src="/static' not in h and "<link rel=\"stylesheet\"" not in h


def test_no_secret_in_any_response(env):
    c, *_ = env
    for p in ["/api/health", "/api/campaigns", "/api/indicators", "/api/dashboard", "/api/sources/status",
              "/api/model", "/api/reports/executive"]:
        body = c.get(p).text
        assert TOKEN not in body and "Bearer" not in body.replace('"auth_scheme":"Bearer"', ""), p


def test_partial_failure_keeps_other_source(tmp_path):
    fake = FakeSplunk(NOW, fail={"solar"})
    app = make(tmp_path, fake)
    with TestClient(app) as c:
        r = c.portal.call(app.state.col.refresh)
        assert r["status"] == "partial"
        d = c.get("/api/dashboard").json()
        assert d["sources"]["icn"]["status"] == "ok" and d["sources"]["solar"]["status"] == "error"
        assert len([i for i in d["indicators"] if i["source"] == "icn" and i["current"] is not None]) == 8


def test_failure_after_success_serves_cache_as_stale(tmp_path):
    fake = FakeSplunk(NOW)
    app = make(tmp_path, fake)
    with TestClient(app) as c:
        c.portal.call(app.state.col.refresh)
        fake.fail = {"icn_hourly"}
        c.portal.call(app.state.col.refresh)
        d = c.get("/api/dashboard").json()
        assert d["sources"]["icn"]["status"] == "stale"
        icn = [i for i in d["indicators"] if i["source"] == "icn"]
        assert all(i["data_status"] == "stale" and i["current"] is not None for i in icn)


def test_auth_error_is_reported_without_token(tmp_path):
    fake = FakeSplunk(NOW, token="outro")
    app = make(tmp_path, fake)
    with TestClient(app) as c:
        r = c.portal.call(app.state.col.refresh)
        assert r["status"] == "error" and "401" in r["error"]
        d = c.get("/api/dashboard").json()
        assert d["status"] == "no_campaign" and d["splunk"]["status"] == "autenticacao"
        assert TOKEN not in (tmp_path / "app.log").read_text()


def test_missing_config(tmp_path):
    fake = FakeSplunk(NOW)
    app = make(tmp_path, fake, splunk_token="")
    with TestClient(app) as c:
        r = c.portal.call(app.state.col.refresh)
        assert r["status"] == "error" and "COCKPIT_SOURCE_SPLUNK_TOKEN" in r["error"]
        assert fake.searches == []
        assert c.get("/api/health").json()["missing"] == ["COCKPIT_SOURCE_SPLUNK_TOKEN"]


def test_concurrent_refresh_is_skipped(env):
    c, app, fake, _ = env
    col = app.state.col

    async def two():
        import asyncio
        a, b = await asyncio.gather(col.refresh(), col.refresh())
        return a, b

    a, b = c.portal.call(two)
    assert {a["status"], b["status"]} >= {"running"}


def test_cache_survives_restart(tmp_path):
    fake = FakeSplunk(NOW)
    app = make(tmp_path, fake)
    with TestClient(app) as c:
        c.portal.call(app.state.col.refresh)
    fake2 = FakeSplunk(NOW, token="invalid")  # Splunk indisponível após reinício
    app2 = make(tmp_path, fake2)
    with TestClient(app2) as c:
        d = c.get("/api/dashboard").json()
        assert d["status"] == "ok" and d["sources"]["icn"]["status"] == "cached"


def test_trusted_host_and_headers(env):
    c, *_ = env
    r = c.get("/api/health")
    assert r.headers["x-content-type-options"] == "nosniff" and "script-src 'self'" in r.headers["content-security-policy"]
    assert c.get("/api/health", headers={"host": "evil.example"}).status_code == 400
    assert c.get("/").status_code == 200 and c.get("/static/app.js").status_code == 200


def test_env_parser_does_not_write(tmp_path):
    f = tmp_path / ".env"
    f.write_text('# c\nCOCKPIT_SOURCE_SPLUNK_BASE_URL="https://s:8089/"\nexport COCKPIT_SOURCE_SPLUNK_TOKEN=abc # x\n')
    before = f.read_text()
    e = _parse_env_file(f)
    s = load_settings(e)
    assert s.splunk_base_url == "https://s:8089" and s.splunk_token == "abc" and f.read_text() == before
    assert "abc" not in repr(s) and "abc" not in str(s.public())


def test_validation_script(tmp_path, monkeypatch):
    import asyncio
    from scripts import validate_splunk as V
    from app.splunk_client import SplunkClient
    fake = FakeSplunk(NOW)
    s = Settings(splunk_base_url="https://splunk.example.invalid:8089", splunk_token=TOKEN, poll_interval_s=0.01)
    monkeypatch.setattr(V, "load_settings", lambda: s)
    monkeypatch.setattr(V, "SplunkClient", lambda st: SplunkClient(st, transport=fake.transport()))
    txt = asyncio.run(V.run(None))
    assert "Conectividade/autenticação: OK" in txt and "Campanha validada: `black_friday`" in txt
    assert "Sourcetypes do catálogo sem dados: nenhum" in txt and "quedas sequenciais" in txt
    assert "Valores distintos de `query`: 2" in txt and TOKEN not in txt
    assert "`queriesOrderSOQL`: 120 eventos" in txt and "Atraso de ingestão ICN" in txt


def test_report_includes_public_url_when_configured(tmp_path):
    fake = FakeSplunk(NOW)
    app = make(tmp_path, fake, public_url="http://bf-painel.claro.corp:8765")
    with TestClient(app) as c:
        c.portal.call(app.state.col.refresh)
        t = c.get("/api/reports/executive").json()["text"]
        assert "🔗 Painel: http://bf-painel.claro.corp:8765" in t


def test_network_host_accepts_server_name(tmp_path):
    fake = FakeSplunk(NOW)
    app = make(tmp_path, fake, host="0.0.0.0")
    with TestClient(app) as c:
        assert c.get("/api/health", headers={"host": "bf-painel.claro.corp:8765"}).status_code == 200
