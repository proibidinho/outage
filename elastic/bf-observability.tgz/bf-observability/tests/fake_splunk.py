"""Splunk FALSO para testes automatizados e verificação visual (somente em tests/).

Implementa o contrato REST usado pela aplicação (criação de job, polling,
resultados paginados) e devolve linhas no MESMO FORMATO que as consultas SPL
reais produzem. Os valores são sintéticos e determinísticos: servem apenas para
testar o código, nunca são usados pela aplicação operacional.
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timedelta
from urllib.parse import parse_qs
from zoneinfo import ZoneInfo

import httpx

TZ = ZoneInfo("America/Sao_Paulo")
SOURCETYPES = {
    "ativacaoPrePago": 900, "ativacaoFlex": 110, "ativacaoControleFacil": 95, "vendasAtivacaoSimplificada": 320,
    "vendasPortabilidade": 70, "vendasECommerce": 380, "vendasResidencialAtivacao": 12, "vendasResidencialMigracao": 120,
}
# fatores sintéticos por ano (apenas para exercitar classificações diferentes)
FACTOR = {2024: {"*": 0.95, "vendasPortabilidade": 1.3}, 2025: {"*": 1.0},
          2026: {"ativacaoPrePago": 0.66, "ativacaoFlex": 0.72, "ativacaoControleFacil": 0.69,
                 "vendasAtivacaoSimplificada": 0.955, "vendasPortabilidade": 0.73, "vendasECommerce": 0.26,
                 "vendasResidencialAtivacao": 0.79, "vendasResidencialMigracao": 1.07}}
DAYS = {2024: (11, 29), 2025: (11, 28), 2026: (11, 27)}
SOLAR = ["SELECT COUNT() FROM Order WHERE Status = 'Ativado'", "SELECT COUNT() FROM Case WHERE Origin = 'Loja'"]


def shape(h: int) -> float:
    return 0.35 + 0.9 * math.exp(-((h - 11) ** 2) / 40) + (0.4 if h == 0 else 0)


class FakeSplunk:
    def __init__(self, now: datetime, *, fail: set[str] | None = None, token: str = "test-token-123456789",
                 page_limit: int | None = None):
        self.now = now
        self.fail = fail or set()
        self.token = token
        self.jobs: dict[str, dict] = {}
        self.searches: list[str] = []
        self.polls: dict[str, int] = {}
        self.result_requests = 0
        self.lag_s = 300  # atraso de ingestão simulado (_indextime - _time)

    # ------------------------------------------------------------- dados
    def lookup(self):
        return [{"periodo": "black_friday", "status": "1", "inicio": f"{m:02d}/{d:02d}/{y}:00:00:00",
                 "fim": f"{m:02d}/{d + 1:02d}/{y}:00:00:00"} for y, (m, d) in DAYS.items()] + [
            {"periodo": "natal", "status": "0", "inicio": "12/24/2025:00:00:00", "fim": "12/25/2025:00:00:00"}]

    def _hours(self, y: int, st: str):
        m, d = DAYS[y]
        start = datetime(y, m, d, tzinfo=TZ)
        f = FACTOR[y].get(st, FACTOR[y].get("*", 1.0))
        for h in range(24):
            t = start + timedelta(hours=h)
            if y == 2026:
                lag = 2 if st == "vendasECommerce" else 1
                if t + timedelta(hours=lag) > self.now:
                    continue
            yield t, round(SOURCETYPES[st] / 10 * shape(h) * f * (1 + 0.03 * math.sin(h + len(st))))

    def icn_hourly(self):
        rows = []
        for st in SOURCETYPES:
            for y in DAYS:
                for t, v in self._hours(y, st):
                    rows.append({"sourcetype": st, "_time": t.isoformat(timespec="milliseconds"),
                                 "QUANTIDADE": str(v), "EVENTOS": str(max(1, v // 3)), "epoch": f"{t.timestamp():.0f}",
                                 "LAST_EVENT": f"{t.timestamp() + 3540:.3f}", "LAG_AVG": str(self.lag_s / 2),
                                 "LAG_MAX": str(self.lag_s)})
        return rows

    def icn_original(self):
        rows = []
        for st in SOURCETYPES:
            for y in DAYS:
                tot = sum(v for _, v in self._hours(y, st))
                if tot:
                    m, d = DAYS[y]
                    rows.append({"sourcetype": st, "_time": datetime(y, m, d, tzinfo=TZ).isoformat(), "QUANTIDADE": str(tot),
                                 "time": str(y), "wday": "x", "block": "0"})
        return rows

    def icn_profile(self):
        return [{"sourcetype": st, "eventos": "100", "dt_movimento_distintos": "3", "qtd_min": "1", "qtd_max": "3",
                 "qtd_media": "1.2", "quedas_sequenciais": "40"} for st in SOURCETYPES]

    def solar_index_access(self):
        return [{"sourcetype": "queriesOrderSOQL", "eventos": "120", "ultimo": "2026-11-27 09:00:00"}]

    def solar_fields(self):
        return [{"eventos": "120", "com_start": "120", "com_query": "120", "com_value": "120", "queries_distintas": "2",
                 "primeiro": "2026-11-20 00:00:00", "ultimo": "2026-11-27 09:00:00", "sourcetypes": "queriesOrderSOQL"}]

    def icn_ingestion_lag(self):
        return [{"sourcetype": st, "ultimo_evento": "2026-11-27 08:59:00", "atraso_medio_min": "2.5",
                 "atraso_p95_min": "4.8", "atraso_max_min": "5"} for st in SOURCETYPES]

    def solar(self):
        rows = []
        for qi, q in enumerate(SOLAR):
            for y in DAYS:
                m, d = DAYS[y]
                acc = 0
                for h in range(24):
                    t = datetime(y, m, d, h, tzinfo=TZ)
                    if t + timedelta(hours=1) > self.now:
                        break
                    acc += round((40 + qi * 25) * shape(h) * (0.9 if y == 2026 else 1))
                    rows.append({"start": t.strftime("%Y-%m-%dT%H:%M:%S.000%z"), "query": q, "value": str(acc),
                                 "_time": (t + timedelta(minutes=55)).isoformat(), "time": "0", "year": str(y)})
        return rows

    # ------------------------------------------------------------- http
    def _kind(self, search: str) -> str:
        if "atraso_min" in search:
            return "icn_ingestion_lag"
        if "count(start)" in search:
            return "solar_fields"
        if "index=solar earliest=-7d" in search:
            return "solar_index_access"
        if "index=icn" in search and "EVENTOS" in search and "bin span=1h _time" in search:
            return "icn_hourly"
        if "index=icn" in search and "quedas_sequenciais" in search:
            return "icn_profile"
        if "index=icn" in search and "bin span=1d _time" in search:
            return "icn_original"
        if "index=solar" in search:
            return "solar"
        if search.strip().startswith("| inputlookup comparativoDatasEspeciais.csv"):
            return "lookup"
        return "unknown"

    def handler(self, req: httpx.Request) -> httpx.Response:
        if req.headers.get("authorization") != f"Bearer {self.token}":
            return httpx.Response(401, json={"messages": [{"type": "WARN", "text": "call not properly authenticated"}]})
        path = req.url.path
        if path.endswith("/server/info"):
            return httpx.Response(200, json={"entry": [{"content": {"version": "9.x-fake"}}]})
        if req.method == "POST" and path.endswith("/search/jobs"):
            form = parse_qs(req.content.decode())
            search = form["search"][0]
            assert "$class$" not in search, "parâmetro não substituído"
            assert form.get("output_mode") == ["json"]
            kind = self._kind(search)
            self.searches.append(kind)
            sid = f"sid{len(self.jobs) + 1}"
            self.jobs[sid] = {"kind": kind}
            return httpx.Response(201, json={"sid": sid})
        parts = path.rstrip("/").split("/")
        if req.method == "GET" and "jobs" in parts:
            sid = parts[parts.index("jobs") + 1]
            job = self.jobs.get(sid)
            if not job:
                return httpx.Response(404, json={"messages": [{"text": "Unknown sid"}]})
            if parts[-1] == "results":
                self.result_requests += 1
                rows = getattr(self, job["kind"])()
                off, cnt = int(req.url.params.get("offset", 0)), int(req.url.params.get("count", 100))
                return httpx.Response(200, json={"results": rows[off:off + cnt]})
            n = self.polls[sid] = self.polls.get(sid, 0) + 1
            if job["kind"] in self.fail:
                return httpx.Response(200, json={"entry": [{"content": {"dispatchState": "FAILED", "isFailed": True,
                                      "messages": [{"type": "FATAL", "text": "Error in 'search': simulated failure"}]}}]})
            done = n >= 2
            rc = len(getattr(self, job["kind"])()) if done else 0
            return httpx.Response(200, json={"entry": [{"content": {"dispatchState": "DONE" if done else "RUNNING",
                                  "isDone": done, "resultCount": rc, "messages": []}}]})
        return httpx.Response(404)

    def transport(self) -> httpx.MockTransport:
        return httpx.MockTransport(self.handler)


def to_json(obj) -> str:
    return json.dumps(obj, ensure_ascii=False)
