"""Executa a aplicação contra o Splunk FALSO (somente para desenvolvimento/inspeção visual).

    python -m tests.run_demo   →  http://127.0.0.1:8799

Os números exibidos neste modo são sintéticos e NÃO representam dados de negócio.
"""
import os
import tempfile
from datetime import datetime

import uvicorn

from app.config import Settings
from app.main import create_app
from tests.fake_splunk import TZ, FakeSplunk

now = datetime.fromisoformat(os.environ.get("DEMO_NOW", "2026-11-27T09:30:00-03:00")).astimezone(TZ)
tmp = tempfile.mkdtemp()
fake = FakeSplunk(now)
s = Settings(splunk_base_url="https://splunk.demo.invalid:8089", splunk_token=fake.token,
             db_path=os.path.join(tmp, "c.sqlite3"), host=os.environ.get("DEMO_HOST", "127.0.0.1"), log_path=os.path.join(tmp, "app.log"), poll_interval_s=0.05)
app = create_app(s, transport=fake.transport())
app.state.col.clock = lambda: now
if __name__ == "__main__":
    uvicorn.run(app, host=os.environ.get("DEMO_HOST", "127.0.0.1"), port=int(os.environ.get("DEMO_PORT", 8799)), log_level="warning")
