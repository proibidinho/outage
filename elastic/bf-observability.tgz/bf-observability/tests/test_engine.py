"""Testes unitários: agregação, comparação, classificação e normalização temporal.

Os valores abaixo são fixtures de teste (não são dados de negócio).
"""
from datetime import datetime
from zoneinfo import ZoneInfo

import pytest

from app import engine as E
from app import insights as I
from app import normalize as N
from app import queries as Q

TZ = ZoneInfo("America/Sao_Paulo")


def camp(windows):
    rows = [{"periodo": "black_friday", "status": "1", "inicio": a, "fim": b} for a, b in windows]
    return Q.parse_campaigns(rows, TZ, {"black_friday": "Black Friday"})[0]


BF = camp([("11/29/2024:00:00:00", "11/30/2024:00:00:00"),
           ("11/28/2025:00:00:00", "11/29/2025:00:00:00"),
           ("11/27/2026:00:00:00", "11/28/2026:00:00:00")])


def ts(y, m, d, h, mi=0):
    return datetime(y, m, d, h, mi, tzinfo=TZ).timestamp()


def icn_rows(key, y, m, d, hourly):
    return [{"sourcetype": key, "epoch": str(ts(y, m, d, h)), "QUANTIDADE": str(v), "EVENTOS": "1"}
            for h, v in hourly.items()]


# ------------------------------------------------------------------ lookup
def test_parse_lookup_formats():
    assert Q.parse_lookup_time("11/27/2026:00:00:00", TZ) == datetime(2026, 11, 27, tzinfo=TZ)
    assert Q.parse_lookup_time("1764212400", TZ).year == 2025
    assert Q.parse_lookup_time("-7d@d", TZ) is None
    assert BF.years == [2024, 2025, 2026]
    assert BF.usable


def test_campaign_validation_blocks_injection():
    spl = 'x periodo="$class$"'
    assert Q.render(spl, "black_friday", {"black_friday"}) == 'x periodo="black_friday"'
    for bad in ['black_friday" OR 1=1 "', "a|delete", "", "x" * 80, "black friday]"]:
        with pytest.raises(Q.InvalidCampaign):
            Q.render(spl, bad, {"black_friday", bad})
    with pytest.raises(Q.InvalidCampaign):
        Q.render(spl, "natal", {"black_friday"})


def test_campaign_without_valid_window_is_not_usable():
    c = camp([("-7d@d", "now")])
    assert not c.usable and c.issues


def test_default_campaign_prefers_black_friday():
    rows = [{"periodo": "natal", "status": "1", "inicio": "12/24/2026:00:00:00", "fim": "12/25/2026:00:00:00"},
            {"periodo": "bf", "status": "0", "inicio": "11/27/2026:00:00:00", "fim": "11/28/2026:00:00:00"},
            {"periodo": "blackfriday", "status": "1", "inicio": "11/27/2026:00:00:00", "fim": "11/28/2026:00:00:00"}]
    cs = Q.parse_campaigns(rows, TZ, {})
    assert [c.id for c in cs] == ["blackfriday", "natal"]  # status 0 ignorado
    assert Q.pick_default_campaign(cs, "", datetime(2026, 11, 27, 9, tzinfo=TZ)) == "blackfriday"
    assert Q.pick_default_campaign(cs, "natal", datetime(2026, 11, 27, 9, tzinfo=TZ)) == "natal"


# --------------------------------------------------------- normalização
def test_normalize_icn_assigns_year_day_hour_from_windows():
    rows = icn_rows("ativacaoPrePago", 2025, 11, 28, {0: 10, 9: 5}) + [
        {"sourcetype": "ativacaoPrePago", "_time": "2025-11-28T10:00:00.000-03:00", "QUANTIDADE": "3"},
        {"sourcetype": "ativacaoPrePago", "_time": "2025-12-05T10:00:00.000-03:00", "QUANTIDADE": "3"},  # fora
        {"sourcetype": "ativacaoPrePago", "epoch": "x", "QUANTIDADE": "3"},
        {"sourcetype": "ativacaoPrePago", "epoch": str(ts(2025, 11, 28, 3)), "QUANTIDADE": ""},
    ]
    n = N.normalize_icn(rows, BF, TZ)
    assert [(p["year"], p["day"], p["hour"], p["value"]) for p in n["points"]] == [
        (2025, 0, 0, 10.0), (2025, 0, 9, 5.0), (2025, 0, 10, 3.0)]
    assert n["errors"] == {"fora_da_janela": 1, "timestamp_invalido": 1, "quantidade_invalida": 1}


def test_parse_ts_offsets_and_utc():
    a = N.parse_ts("2025-11-28T09:00:00.000-0300", TZ)
    b = N.parse_ts("2025-11-28T12:00:00Z", TZ)
    assert a == b and a.hour == 9


def test_multi_day_campaign_relative_day():
    c = camp([("11/27/2025:00:00:00", "11/30/2025:00:00:00"), ("11/26/2026:00:00:00", "11/29/2026:00:00:00")])
    idx = N.WindowIndex(c, TZ)
    assert idx.locate(datetime(2025, 11, 29, 5, tzinfo=TZ)) == (2025, 2)
    assert idx.locate(datetime(2026, 11, 28, 5, tzinfo=TZ)) == (2026, 2)
    assert len(idx.day_dates(2026)) == 3


# ------------------------------------------------------------- agregação
def test_aggregations():
    v = [(1, 5.0), (3, 2.0), (2, 9.0)]
    assert E.aggregate(v, "sum") == 16
    assert E.aggregate(v, "last") == 2.0
    assert E.aggregate(v, "max") == 9 and E.aggregate(v, "min") == 2
    assert E.aggregate(v, "avg") == pytest.approx(16 / 3)
    assert E.aggregate([], "sum") == 0.0          # dia com dados, nenhum evento até o corte
    assert E.aggregate([], "sum", False) is None  # dia sem dados
    assert E.aggregate([], "last") is None


def test_variation_and_zero_reference():
    assert E.variation(8125, 12292) == (pytest.approx(-4167), pytest.approx(-33.8996, rel=1e-4))
    assert E.variation(10, 0) == (10, None)
    assert E.variation(None, 5) == (None, None)


@pytest.mark.parametrize("p,direction,expected", [
    (0.0, "higher_is_better", "ok"), (5, "higher_is_better", "ok"), (-0.1, "higher_is_better", "warn"),
    (-9.99, "higher_is_better", "warn"), (-10, "higher_is_better", "bad"), (-40, "higher_is_better", "bad"),
    (-15, "lower_is_better", "ok"), (5, "lower_is_better", "warn"), (12, "lower_is_better", "bad"),
])
def test_classify(p, direction, expected):
    assert E.classify(p, direction, {"ok": 0, "warn": -10})[0] == expected


def test_classify_custom_thresholds():
    assert E.classify(-3, "higher_is_better", {"ok": -2, "warn": -5})[0] == "warn"
    assert E.classify(-1, "higher_is_better", {"ok": -2, "warn": -5})[0] == "ok"


# -------------------------------------------------- seleção / equivalência
def test_select_cutoff_running_day():
    now = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
    s = E.select(BF, TZ, now)
    assert (s.year, s.ref_year, s.ref_years, s.day) == (2026, 2025, [2025, 2024], 0)
    assert s.last_bucket == 8 and s.is_today and s.state == "running"   # corte 09h
    s = E.select(BF, TZ, now, cutoff=5)
    assert s.last_bucket == 4
    s = E.select(BF, TZ, now, lag_minutes=45)
    assert s.last_bucket == 7


def test_select_closed_and_future_days():
    s = E.select(BF, TZ, datetime(2026, 11, 29, 9, tzinfo=TZ))
    assert s.last_bucket == 23 and s.state == "closed"
    s = E.select(BF, TZ, datetime(2026, 11, 20, 9, tzinfo=TZ))
    assert s.year == 2025  # campanha 2026 ainda não iniciada → último ano iniciado
    s = E.select(BF, TZ, datetime(2026, 11, 20, 9, tzinfo=TZ), year=2026)
    assert s.last_bucket is None and s.state == "future"


IND = {"id": "pre", "source": "icn", "match": "ativacaoPrePago", "name": "Ativação Pré-Pago", "segment": "Móvel",
       "unit": "quantidade", "aggregation": "sum", "direction": "higher_is_better"}
DEF = {"thresholds": {"ok": 0, "warn": -10}, "stale_after_minutes": 120}


def points(hourly_by_year):
    dates = {2024: (11, 29), 2025: (11, 28), 2026: (11, 27)}
    rows = []
    for y, hourly in hourly_by_year.items():
        rows += icn_rows("ativacaoPrePago", y, *dates[y], hourly)
    return N.normalize_icn(rows, BF, TZ)["points"]


def test_equivalent_window_does_not_compare_partial_vs_full_day():
    now = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
    pts = points({2026: {h: 100 for h in range(10)},           # hora 9 parcial → ignorada
                  2025: {h: 100 for h in range(24)},
                  2024: {h: 50 for h in range(24)}})
    r = E.compute_indicator(IND, pts, E.select(BF, TZ, now), now, TZ, [2024, 2025, 2026], DEF)
    assert r["cutoff_label"] == "09h" and r["current"] == 900
    c = r["comparisons"]["2025"]
    assert c["ref"] == 900 and c["pct"] == 0 and c["status"] == "ok"
    assert r["comparisons"]["2024"]["ref"] == 450 and r["comparisons"]["2024"]["pct"] == 100
    assert len(r["series"]["2026"]) == 9 and r["series"]["2025"][-1]["cum"] == 900


def test_individual_cutoff_and_stale():
    now = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
    pts = points({2026: {h: 10 for h in range(8)}, 2025: {h: 20 for h in range(24)}})
    r = E.compute_indicator(IND, pts, E.select(BF, TZ, now), now, TZ, [2025, 2026], DEF)
    assert r["cutoff_label"] == "08h" and r["data_status"] == "ok"
    assert r["comparisons"]["2025"]["ref"] == 160  # referência no mesmo corte individual
    assert r["comparisons"]["2025"]["pct"] == -50 and r["comparisons"]["2025"]["status"] == "bad"
    now2 = datetime(2026, 11, 27, 12, 30, tzinfo=TZ)
    r2 = E.compute_indicator(IND, pts, E.select(BF, TZ, now2), now2, TZ, [2025, 2026], DEF)
    assert r2["data_status"] == "stale"


def test_missing_reference_and_zero_reference():
    now = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
    pts = points({2026: {0: 5, 8: 5}, 2025: {h: 0 for h in range(24)}})
    r = E.compute_indicator(IND, pts, E.select(BF, TZ, now), now, TZ, [2024, 2025, 2026], DEF)
    assert r["comparisons"]["2025"]["data_status"] == "zero_reference"
    assert r["comparisons"]["2025"]["pct"] is None and r["comparisons"]["2025"]["status"] is None
    assert r["comparisons"]["2024"]["data_status"] == "no_reference"
    assert r["values_by_year"]["2024"] is None  # ausente não vira zero
    s = E.summarize([r], 2025)
    assert s["comparable"] == 0 and s["unavailable"] == 1


def test_partial_reference_not_classified():
    now = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
    pts = points({2026: {h: 5 for h in range(9)}, 2025: {h: 5 for h in range(4)}})
    r = E.compute_indicator(IND, pts, E.select(BF, TZ, now), now, TZ, [2025, 2026], DEF)
    assert r["comparisons"]["2025"]["data_status"] == "partial_reference"
    assert r["comparisons"]["2025"]["status"] is None


def test_no_current_data():
    now = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
    pts = points({2025: {h: 5 for h in range(24)}})
    r = E.compute_indicator(IND, pts, E.select(BF, TZ, now), now, TZ, [2025, 2026], DEF)
    assert r["data_status"] == "no_data" and r["current"] is None and r["comparisons"] == {}


def test_last_aggregation_for_cumulative_solar_metric():
    ind = dict(IND, source="solar", aggregation="last", nature="cumulative")
    now = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
    pts = points({2026: {0: 10, 4: 40, 8: 80}, 2025: {0: 10, 4: 50, 8: 100, 20: 300}})
    r = E.compute_indicator(ind, pts, E.select(BF, TZ, now), now, TZ, [2025, 2026], DEF)
    assert r["current"] == 80 and r["comparisons"]["2025"]["ref"] == 100
    assert r["comparisons"]["2025"]["pct"] == -20


def test_pending_indicator_has_no_classification():
    cat = {"indicators": [IND], "solar_pending_defaults": {"segment": "Solar"}}
    inds = E.resolve_catalog(cat, {"solar": ["SELECT COUNT() FROM Order"]})
    pend = [i for i in inds if i.get("pending")]
    assert len(pend) == 1 and pend[0]["id"].startswith("solar_")
    now = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
    rows = [{"query": "SELECT COUNT() FROM Order", "start": "2026-11-27T08:00:00.000-0300", "value": "7",
             "_time": "2026-11-27T05:10:00.000-03:00"}]
    p = N.normalize_solar(rows, BF, TZ)["points"]
    r = E.compute_indicator(pend[0], p, E.select(BF, TZ, now), now, TZ, [2026], DEF)
    assert r["data_status"] == "pending" and r["comparisons"] == {} and r["current"] == 7


# ---------------------------------------------------------------- insights
def test_insights_rules():
    now = datetime(2026, 11, 27, 9, 30, tzinfo=TZ)
    sel = E.select(BF, TZ, now)
    # deterioração contínua: 2026 cai ao longo das horas frente a 2025 constante
    p1 = points({2026: {0: 100, 1: 100, 2: 90, 3: 80, 4: 70, 5: 60, 6: 50, 7: 40, 8: 30},
                 2025: {h: 100 for h in range(24)}})
    a = E.compute_indicator(IND, p1, sel, now, TZ, [2025, 2026], DEF)
    b_ind = dict(IND, id="flex", name="Ativação Flex", match="ativacaoFlex", segment="Digital")
    p2 = [dict(p, key="ativacaoFlex") for p in points({2026: {h: 120 for h in range(9)}, 2025: {h: 100 for h in range(24)}})]
    b = E.compute_indicator(b_ind, p2, sel, now, TZ, [2025, 2026], DEF)
    ins = I.generate([a, b], 2025)
    kinds = {x["type"] for x in ins}
    assert {"maior_queda_pct", "maior_queda_abs", "maior_crescimento", "deterioracao_consecutiva"} <= kinds
    worst = next(x for x in ins if x["type"] == "maior_queda_pct")
    assert "Ativação Pré-Pago apresenta redução de" in worst["text"] and "intensificação" in worst["text"]
    assert a["comparisons"]["2025"]["intensification_from"] == 1
    best = next(x for x in ins if x["type"] == "maior_crescimento")
    assert "+20,0%" in best["text"]


def test_warn_to_critical_transition():
    now = datetime(2026, 11, 27, 4, 30, tzinfo=TZ)
    sel = E.select(BF, TZ, now)
    p = points({2026: {0: 95, 1: 95, 2: 95, 3: 30}, 2025: {h: 100 for h in range(24)}})
    r = E.compute_indicator(IND, p, sel, now, TZ, [2025, 2026], DEF)
    ins = I.generate([r], 2025)
    assert any(x["type"] == "atencao_para_critico" for x in ins)


def test_lookup_prefers_splunk_epoch_and_warns_on_timezone():
    # Usuário do token em UTC: o Splunk interpreta "11/27/2026:00:00:00" como 00:00Z = 21:00 BRT do dia anterior
    utc_start = datetime(2026, 11, 27, tzinfo=ZoneInfo("UTC")).timestamp()
    rows = [{"periodo": "black_friday", "status": "1", "inicio": "11/27/2026:00:00:00", "fim": "11/28/2026:00:00:00",
             "inicio_epoch": f"{utc_start:.6f}", "fim_epoch": f"{utc_start + 86400:.6f}", "splunk_tz": "+0000"}]
    c = Q.parse_campaigns(rows, TZ, {})[0]
    w = c.valid_windows[0]
    assert w.start == datetime(2026, 11, 26, 21, tzinfo=TZ) and w.raw_start == "11/27/2026:00:00:00"
    assert any("+0000" in i for i in c.issues)
    # ponto das 22h BRT do dia 26 agora pertence à janela (antes era descartado como fora_da_janela)
    pts = N.normalize_icn(icn_rows("ativacaoPrePago", 2026, 11, 26, {22: 5}), c, TZ)
    assert pts["errors"] == {} and pts["points"][0]["day"] == 0


def test_lookup_same_timezone_has_no_warning():
    s = datetime(2026, 11, 27, tzinfo=TZ).timestamp()
    rows = [{"periodo": "bf", "status": "1", "inicio": "x", "fim": "y", "inicio_epoch": str(s),
             "fim_epoch": str(s + 86400), "splunk_tz": "-0300"}]
    c = Q.parse_campaigns(rows, TZ, {})[0]
    assert c.usable and not c.issues


def _pts_with_lag(hourly, lag_s, y=2026, m=11, d=27):
    rows = [dict(r, LAG_MAX=str(lag_s)) for r in icn_rows("ativacaoPrePago", y, m, d, hourly)]
    return N.normalize_icn(rows, BF, TZ)["points"]


def test_last_bucket_still_in_ingestion_is_not_compared():
    # 13:03, dados até o bucket 11 (11:00-12:00), atraso medido de 90 min: bucket 11 ainda em ingestão
    now = datetime(2026, 11, 27, 13, 3, tzinfo=TZ)
    pts = _pts_with_lag({h: 10 for h in range(12)}, 5400) + points({2025: {h: 10 for h in range(24)}})
    r = E.compute_indicator(IND, pts, E.select(BF, TZ, now), now, TZ, [2025, 2026], DEF)
    assert r["cutoff_label"] == "11h" and r["current"] == 110 and r["comparisons"]["2025"]["ref"] == 110
    assert any("ainda em ingestão" in n for n in r["notes"])


def test_last_bucket_confirmed_by_elapsed_lag_or_later_data():
    now = datetime(2026, 11, 27, 13, 3, tzinfo=TZ)
    ref = points({2025: {h: 10 for h in range(24)}})
    # atraso medido de 5 min: às 13:03 o bucket 11 (fim 12:00) já está confirmado
    r = E.compute_indicator(IND, _pts_with_lag({h: 10 for h in range(12)}, 300) + ref, E.select(BF, TZ, now), now, TZ, [2025, 2026], DEF)
    assert r["cutoff_label"] == "12h"
    # atraso alto, mas já há dados do bucket 13 (hora corrente): bucket 12 confirmado
    r = E.compute_indicator(IND, _pts_with_lag({h: 10 for h in range(14)}, 5400) + ref, E.select(BF, TZ, now), now, TZ, [2025, 2026], DEF)
    assert r["cutoff_label"] == "13h" and r["current"] == 130


def test_clock_completeness_mode_ignores_lag():
    now = datetime(2026, 11, 27, 13, 3, tzinfo=TZ)
    ind = dict(IND, completeness="clock")
    pts = _pts_with_lag({h: 10 for h in range(12)}, 5400) + points({2025: {h: 10 for h in range(24)}})
    r = E.compute_indicator(ind, pts, E.select(BF, TZ, now), now, TZ, [2025, 2026], DEF)
    assert r["cutoff_label"] == "12h"
