# Validação Splunk — 27/11/2026 12:57

- Conectividade/autenticação: OK (versão 10.6.2.4, 977 ms)

## Lookup comparativoDatasEspeciais.csv
- Linhas: 16 · campos: ano, fim, inicio, periodo, status
- `Ano Novo` → anos [2024, 2025] · utilizável: True
  - inicio=`01/01/2024:00:00:00` fim=`01/08/2024:00:00:00` → 2024-01-01 00:00:00-03:00 … 2024-01-08 00:00:00-03:00
  - inicio=`12/30/2024:00:00:00` fim=`01/06/2025:00:00:00` → 2024-12-30 00:00:00-03:00 … 2025-01-06 00:00:00-03:00
  - inicio=`12/29/2025:00:00:00` fim=`01/05/2026:00:00:00` → 2025-12-29 00:00:00-03:00 … 2026-01-05 00:00:00-03:00
  - ⚠ Mais de uma janela no mesmo ano: dias tratados por posição relativa na janela
- `Black Friday` → anos [2023, 2024, 2025, 2026] · utilizável: True
  - inicio=`11/20/2023:00:00:00` fim=`11/27/2023:00:00:00` → 2023-11-20 00:00:00-03:00 … 2023-11-27 00:00:00-03:00
  - inicio=`11/25/2024:00:00:00` fim=`12/02/2024:00:00:00` → 2024-11-25 00:00:00-03:00 … 2024-12-02 00:00:00-03:00
  - inicio=`11/24/2025:00:00:00` fim=`12/01/2025:00:00:00` → 2025-11-24 00:00:00-03:00 … 2025-12-01 00:00:00-03:00
  - inicio=`11/23/2026:00:00:00` fim=`11/30/2026:00:00:00` → 2026-11-23 00:00:00-03:00 … 2026-11-30 00:00:00-03:00
- `Dia Das Mães` → anos [2023, 2024, 2025] · utilizável: False
  - inicio=`05/08/2023:00:00:00` fim=`05/15/2023:00:00:00` → 2023-05-08 00:00:00-03:00 … 2023-05-15 00:00:00-03:00
  - inicio=`05/06/2024:00:00:00` fim=`05/13/2024:00:00:00` → 2024-05-06 00:00:00-03:00 … 2024-05-13 00:00:00-03:00
  - inicio=`05/05/2025:00:00:00` fim=`05/12/2025:00:00:00` → 2025-05-05 00:00:00-03:00 … 2025-05-12 00:00:00-03:00
  - ⚠ Valor de periodo com caracteres não permitidos; campanha bloqueada
- `Dia Dos Pais` → anos [2023, 2024, 2025] · utilizável: True
  - inicio=`08/07/2023:00:00:00` fim=`08/14/2023:00:00:00` → 2023-08-07 00:00:00-03:00 … 2023-08-14 00:00:00-03:00
  - inicio=`08/05/2024:00:00:00` fim=`08/12/2024:00:00:00` → 2024-08-05 00:00:00-03:00 … 2024-08-12 00:00:00-03:00
  - inicio=`08/04/2025:00:00:00` fim=`08/11/2025:00:00:00` → 2025-08-04 00:00:00-03:00 … 2025-08-11 00:00:00-03:00
- `Natal` → anos [2023, 2024, 2025] · utilizável: True
  - inicio=`12/25/2023:00:00:00` fim=`01/01/2024:00:00:00` → 2023-12-25 00:00:00-03:00 … 2024-01-01 00:00:00-03:00
  - inicio=`12/23/2024:00:00:00` fim=`12/30/2024:00:00:00` → 2024-12-23 00:00:00-03:00 … 2024-12-30 00:00:00-03:00
  - inicio=`12/22/2025:00:00:00` fim=`12/29/2025:00:00:00` → 2025-12-22 00:00:00-03:00 … 2025-12-29 00:00:00-03:00

## Campanha validada: `Black Friday`

## ICN — consulta original
- 152 linhas em 16398 ms · campos: sourcetype, _time, QUANTIDADE, block, diff, minDayHour, time, wday, _time_prev
- Amostra de `_time`: `2024-11-25T00:00:00.000+00:00` · `time` (ano do bloco): ['2024', '2025', '2026']

## ICN — variante horária
- 3250 linhas em 16413 ms · campos: sourcetype, _time, QUANTIDADE, EVENTOS, epoch
- Sourcetypes: ['ativacaoControleFacil', 'ativacaoFlex', 'ativacaoPrePago', 'vendasAtivacaoSimplificada', 'vendasECommerce', 'vendasPortabilidade', 'vendasResidencialAtivacao', 'vendasResidencialMigracao']
- Pontos normalizados: 3183 · erros: {'fora_da_janela': 67}
- Sourcetypes do catálogo sem dados: nenhum
- Reconciliação (original × horária, por sourcetype/ano):
  - ativacaoControleFacil 2024: 27422 × 27405
  - ativacaoControleFacil 2025: 32085 × 32078
  - ativacaoControleFacil 2026: 8580 × 8578
  - ativacaoFlex 2024: 29006 × 28739
  - ativacaoFlex 2025: 39670 × 39241
  - ativacaoFlex 2026: 24932 × 24515
  - ativacaoPrePago 2024: 394949 × 392878
  - ativacaoPrePago 2025: 516606 × 514672
  - ativacaoPrePago 2026: 270819 × 268776
  - vendasAtivacaoSimplificada 2024: 330114 × 329758
  - vendasAtivacaoSimplificada 2025: 346427 × 346090
  - vendasAtivacaoSimplificada 2026: 225903 × 225645
  - vendasECommerce 2024: 114636 × 112986
  - vendasECommerce 2025: 123164 × 121286
  - vendasECommerce 2026: 68110 × 67017
  - vendasPortabilidade 2024: 58706 × 58473
  - vendasPortabilidade 2025: 54664 × 54482
  - vendasPortabilidade 2026: 35998 × 35864
  - vendasResidencialAtivacao 2024: 9157 × 9127
  - vendasResidencialAtivacao 2025: 9826 × 9811
  - vendasResidencialAtivacao 2026: 5353 × 5338
  - vendasResidencialMigracao 2024: 71403 × 71182
  - vendasResidencialMigracao 2025: 70153 × 69846
  - vendasResidencialMigracao 2026: 48746 × 48511

## ICN — perfil de QUANTIDADE (incremental × acumulado)
| sourcetype | eventos | DT_MOVIMENTO distintos | mín | máx | média | quedas sequenciais |
|---|---|---|---|---|---|---|
| ativacaoControleFacil | 11113 | 22 | 1 | 129 | 6.126788445964186 | 4506 |
| ativacaoFlex | 18894 | 22 | 1 | 100 | 4.954377050915634 | 7539 |
| ativacaoPrePago | 60127 | 22 | 1 | 918 | 19.664609909025895 | 24919 |
| vendasAtivacaoSimplificada | 54432 | 22 | 1 | 723 | 16.579291593180482 | 21078 |
| vendasECommerce | 12052 | 22 | 1 | 1462 | 25.38250912711583 | 4697 |
| vendasPortabilidade | 13366 | 22 | 1 | 312 | 11.175220709262307 | 4967 |
| vendasResidencialAtivacao | 22105 | 22 | 1 | 5 | 1.1009273919927618 | 1669 |
| vendasResidencialMigracao | 85253 | 22 | 1 | 17 | 2.2322029723294197 | 24656 |

Interpretação: muitas quedas sequenciais e valores pequenos ⇒ QUANTIDADE incremental por evento (soma é válida). Poucas quedas e valores crescentes ⇒ acumulado (soma gera dupla contagem).

## Solar
- 0 linhas em 3571 ms · campos: 
- Amostra de `start`: `-`
- Valores distintos de `query`: 0 · erros de normalização: nenhum

| query (60 car.) | pontos | anos | intervalo típico | mín | máx | dias monotônicos | sugestão |
|---|---|---|---|---|---|---|---|