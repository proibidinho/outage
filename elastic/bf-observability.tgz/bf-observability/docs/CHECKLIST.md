# Checklist de implementação e aceite

Legenda: ✅ implementado e testado · 🟡 implementado, depende de validação no ambiente real ou do negócio · ⬜ pendente

| Critério | Status | Evidência |
|---|---|---|
| Aplicação executando localmente (127.0.0.1) | ✅ | `app/run.py`, `deploy/bf-observability.service`; smoke test sem `.env` |
| Identidade visual fiel ao protótipo | ✅ | CSS e tokens do protótipo preservados; logo original extraído do HTML |
| Integração real com o Splunk (REST, Bearer, TLS, paginação, polling) | 🟡 | Testada contra Splunk falso; **sem acesso ao Splunk real neste ambiente** |
| Execução das duas consultas fornecidas | 🟡 | ICN original (reconciliação) e Solar originais; variante horária ICN documentada |
| Identificação das campanhas pelo lookup | 🟡 | Parser de `inicio`/`fim` (epoch, `%m/%d/%Y:%H:%M:%S`, ISO); confirmar o formato real |
| Oito indicadores ICN | ✅ / 🟡 | Catálogo central; nomes de negócio a confirmar (`validated: false`) |
| Indicadores Solar disponíveis | 🟡 | Descoberta automática + perfil; **classificação semântica pendente** |
| Comparação entre períodos equivalentes (dia relativo e corte) | ✅ | `tests/test_engine.py` |
| Comparação com 2024 e 2025 | ✅ | Payload com todos os anos de referência |
| Gráficos horários com dados retornados pelo Splunk | ✅ | Séries derivadas só das linhas retornadas |
| Cálculo de variações | ✅ | Unitários e integração (valor exibido = soma das linhas do Splunk) |
| Referência igual a zero, dados ausentes, referência parcial | ✅ | Testes dedicados |
| Falha parcial das fontes / cache após falha | ✅ | `test_partial_failure_*`, `test_failure_after_success_*` |
| Atualização manual e automática, concorrência | ✅ | `test_concurrent_refresh_is_skipped` |
| Cache funcional (inclusive após reinício) | ✅ | `test_cache_survives_restart` |
| Reporte executivo (WhatsApp e Teams) | ✅ | Verificado no navegador (clipboard) |
| Exportações PDF, PNG, CSV e HTML | ✅ | Verificadas com Playwright; snapshot offline sem requisições de rede |
| Ausência de credenciais no frontend, respostas, logs e exports | ✅ | `test_no_secret_in_any_response`, `test_snapshot_html_has_no_secrets` |
| Desktop e mobile, tema claro e escuro | ✅ | Screenshots 1000 px e iPhone 13 (dark), sem rolagem horizontal |
| Documentação de instalação e execução | ✅ | `README.md` |
| Execução local / em servidor | ✅ / 🟡 | Os `.bat` foram usados na validação inicial; substituídos por serviço systemd (`deploy/`) para o servidor Linux interno, **ainda não instalado no servidor** |
| Execução com o Splunk real | ✅ | Painel executado em claro.splunkcloud.com com ICN carregado (27/11/2026) |

## Pendências que dependem do ambiente ou do negócio

0. **Solar retornou 0 registros** no ambiente real: rodar `python -m scripts.validate_splunk` (seção "Diagnóstico Solar") para distinguir falta de permissão no `index=solar` de sourcetype ou campos diferentes.
0. **Fuso do usuário do token**: conferir o aviso na seção 1 do Modelo de Dados após a correção das janelas.
1. **Executar `python -m scripts.validate_splunk` no ambiente corporativo** e anexar o relatório gerado. Confirmar:
   - endpoint e contexto de app do lookup `comparativoDatasEspeciais.csv` (`BF_SPLUNK_APP`, se necessário);
   - valor de `periodo` da Black Friday e datas 29/11/2024, 28/11/2025 e 27/11/2026;
   - formato de `inicio`/`fim` e compatibilidade de fuso (`America/Sao_Paulo`);
   - reconciliação original × horária sem divergência;
   - natureza de `QUANTIDADE` (incremental esperado; se for acumulada, mudar `aggregation` para `last`/`max` no catálogo).
2. **Classificar os indicadores Solar** (nome, unidade, agregação, natureza e direção) com o negócio.
3. **Confirmar nomes de negócio e segmentos ICN** e marcar `validated: true`.
4. Definir os limiares por indicador, se diferentes de 0% / −10%.
5. Calibrar `stale_after_minutes` e `ingestion_lag_minutes` conforme a latência real de ingestão.
6. Pares de divergência entre fontes (`divergence_pairs`): só após correspondência de negócio validada.
7. Validar os valores do painel contra uma busca manual no Splunk (amostra de 2 ou 3 indicadores).
