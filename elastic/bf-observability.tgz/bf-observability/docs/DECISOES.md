# Decisões técnicas

## Arquitetura
- **Repositório inicial vazio**: não havia cliente Splunk, API nem frontend para reaproveitar. Adotado o padrão da especificação: FastAPI, SQLite e frontend sem build, reaproveitando o HTML, o CSS e o JS do protótipo. Isso evita Node/React e CDNs.
- **Dependências mínimas**: `fastapi`, `uvicorn`, `httpx`, `tzdata` (necessário no Windows para `America/Sao_Paulo`). PDF por impressão do navegador e PNG por Canvas, ambos sem bibliotecas extras.

## Consultas
- **ICN horário**: a consulta original agrega por `_time` diário (`stats … by sourcetype _time` depois de `bin span=1d _time`), então perde a hora. Criei a variante `queries/icn_business_metrics_hourly.spl` com o **mesmo filtro e o mesmo subsearch do lookup**, `bin span=1h _time`, `sum(QUANTIDADE)` e `count` por hora, além de `epoch` numérico, para não depender do fuso do usuário Splunk. A consulta original fica intacta e é executada a cada `BF_ICN_RECONCILE_EVERY` ciclos para **reconciliar** os totais por sourcetype e ano (aba Modelo de Dados).
- **Ano e dia da campanha** são atribuídos no backend pelas janelas do lookup (`inicio`/`fim`), não pela data de calendário nem pelo agrupamento em blocos da SPL. O dia relativo é contado a partir da data local de início da primeira janela do ano, o que suporta campanhas de vários dias e lookups com uma linha por dia.
- **Fuso das janelas**: o Splunk interpreta `inicio`/`fim` do lookup no fuso do **usuário do token**. A consulta do lookup devolve `inicio_epoch`/`fim_epoch` calculados pelo próprio Splunk (`strptime`) e `splunk_tz`, para que as janelas do painel sejam exatamente as buscadas. Se `splunk_tz` diferir de `BF_TIMEZONE`, a aba Modelo de Dados mostra um aviso. Evidência que motivou a mudança: no ambiente real, a reconciliação mostrou a variante horária sempre 0,1%–1,7% abaixo da original, com 67 pontos "fora da janela".
- **Solar**: a consulta original é usada sem alteração. O campo `time` é sobrescrito por `eventstats min(time) by block`, por isso o timestamp do ponto vem de `start`, que a consulta preserva. Se `start` não representar o momento do indicador, `time_field: "_time"` no catálogo usa o momento da medição.
- **`$class$`**: o valor só é aceito se casar com `^[A-Za-z0-9][A-Za-z0-9_\-. ]{0,63}$` **e** existir no lookup com `status=1` e janela interpretável. Sem janela válida, nenhuma busca de dados é executada.

## Regras
- **Corte**: bucket horário local; “corte 09h” = buckets 00–08. O último bucket completo é derivado do relógio e de `ingestion_lag_minutes`. O corte de cada indicador é o último bucket com dado (o E-commerce às 08h é detectado sozinho, nada fixo no código). As referências são lidas no mesmo corte e no mesmo dia relativo.
- **Horário em ingestão**: a variante horária do ICN devolve, por hora, `LAST_EVENT` (último `_time`) e `LAG_AVG`/`LAG_MAX` (`_indextime − _time`). No dia corrente, o último horário com dado só entra na comparação se (a) já chegaram dados de um horário posterior ou (b) desde o fim do horário passou o atraso típico medido (mediana dos `LAG_MAX` do dia). Assim, um horário parcialmente ingerido não é comparado com um histórico completo. `completeness: "clock"` no catálogo desativa a regra por indicador. O cabeçalho mostra o corte efetivo (o predominante entre os indicadores), e o Modelo de Dados também mostra o último horário fechado pelo relógio.
- **Ausência ≠ zero**: um ano sem pontos no dia fica como “sem dados”. Para indicadores de soma, uma hora sem eventos dentro de um dia com dados vale zero no acumulado (o `stats` do Splunk não emite buckets vazios); essa é a semântica correta de contagem.
- **Referência parcial**: se o histórico não alcança o corte, a comparação não é classificada.
- **Desatualizado**: idade do último bucket completo acima de `stale_after_minutes` (padrão 120), avaliada só no dia corrente e sem corte manual. Pode sinalizar indicadores de baixo volume de madrugada; o limite é ajustável por indicador.
- **Insights**: regras explícitas em `app/insights.py`; nenhuma causa técnica é atribuída. A transição atenção→crítico e a recuperação comparam o status entre os dois últimos buckets do dia; a “deterioração consecutiva” exige 3 horas seguidas de piora; a “intensificação” é o início da última sequência contínua de queda (pelo menos 2 p.p.).

## Operação
- Uma coleta por vez (`asyncio.Lock`), no máximo N buscas simultâneas (semáforo), retry exponencial só para erros transitórios (rede, timeout, 5xx), timeout por busca e paginação de resultados.
- Cache SQLite por campanha e fonte; o payload do dashboard é memorizado por versão dos dados, então filtros não executam SPL.
- Snapshot HTML: `strip_internal()` remove host, erros detalhados e mensagens técnicas, e a seção técnica do Modelo de Dados não é exportada.
