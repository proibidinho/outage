# install_es68

Elasticsearch **6.8.23** (licença free/Basic) em um único nó: `cbl2am72256` (10.29.88.219), RHEL, 32 vCPU, 64 GB, dois discos de 1 TB livres.
Um playbook só (`site.yml`), sem survey nem tags.

## O que ele faz, nesta ordem

1. **Confere** o servidor e procura os discos. Se não achar exatamente 2 discos virgens de ~1 TiB, **para sem tocar em nada**.
2. **Disco:** LVM com os dois discos em um volume só (~2 TB, sem redundância), XFS, montado em `/var/lib/elasticsearch` (`nofail` + o serviço só inicia com o disco montado).
3. **Sistema:** chrony com o NTP da empresa, `vm.max_map_count`, swap desligado, limites do serviço.
4. **Java e pacote:** OpenJDK 11 (a 6.8 não traz JDK) e o RPM 6.8.23 baixado de `artifacts.elastic.co` com SHA-512 conferido.
5. **Segurança (grátis no Basic):** CA interna gerada no servidor, HTTPS na 9200, autenticação ligada.
6. **Configuração:** `discovery.type: single-node`, heap de 30g, `bootstrap.memory_lock`.
7. **Start** e gravação da senha do usuário `elastic`.
8. **Validação:** versão, saúde (green/yellow, 1 nó), licença `basic` e heap com ponteiros comprimidos.

Pode rodar de novo: o que já está pronto não muda. Os discos só são formatados quando o volume `vg_esdata` ainda não existe.

## Antes de rodar

- A chave do exec node precisa estar autorizada no root de `cbl2am72256`.
- O servidor precisa alcançar `artifacts.elastic.co` (ou defina `elastic_repo_proxy` nas variáveis extras do Job Template).
- Crie o `vault.yml` a partir do `vault.yml.example` (2 valores), criptografe com `ansible-vault` e anexe a credencial Vault ao Job Template.
- Cole o `inventory.yml` em um inventário do AAP. Job Template: playbook `site.yml`, credencial Machine (root).

## Depois

```
curl --cacert ca.crt -u elastic https://10.29.88.219:9200/_cluster/health
```

Copie `/root/elastic-ca/ca.crt` do servidor para os clientes que forem acessar (ou use `-k` só em teste). Se o `firewalld` estiver ativo, libere a 9200.

## Atenção

- A 6.8 está **fora de suporte** (a 6.8.23 é a última) e não recebe correções de segurança.
- Em um nó só, índices com réplica ficam `yellow`. Crie os índices com `number_of_replicas: 0`.
- Os dois discos viram um volume único: se um falhar, perde-se tudo. Faça snapshots (repositório `fs` ou S3).
- Para trocar a senha do `elastic` depois, use a API de senha; rodar o playbook com outro valor no vault não a altera.
