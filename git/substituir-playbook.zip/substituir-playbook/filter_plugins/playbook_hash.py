"""Filtro Jinja `hash_playbook`.

Normaliza o texto de um playbook e devolve o SHA-256 do resultado, para que
dois arquivos sejam considerados "iguais" mesmo que difiram apenas em:
  - quebra de linha (CRLF x LF)
  - espaços/tabs no fim das linhas
  - linhas em branco no fim do arquivo
  - BOM no início

Qualquer outra diferença (conteúdo, ordem, indentação, comentários, linhas em
branco no meio) torna os arquivos diferentes.

Devolver só o hash (e não o texto normalizado) é proposital: o conteúdo dos
playbooks tem expressões Jinja ({{ ... }}) e, se ficasse guardado em uma
variável do Ansible, seria interpretado como template na próxima leitura.
"""
import hashlib


def _normalizar(texto):
    if isinstance(texto, bytes):
        texto = texto.decode("utf-8")
    texto = str(texto).lstrip("﻿")
    texto = texto.replace("\r\n", "\n").replace("\r", "\n")
    linhas = [linha.rstrip() for linha in texto.split("\n")]
    return "\n".join(linhas).rstrip("\n")


def hash_playbook(texto):
    return hashlib.sha256(_normalizar(texto).encode("utf-8")).hexdigest()


class FilterModule(object):
    def filters(self):
        return {"hash_playbook": hash_playbook}
